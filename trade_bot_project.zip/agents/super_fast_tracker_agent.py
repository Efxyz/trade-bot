"""
SÜPER FAST Counterfactual Tracker Agent - Saniyelik Mikro-Scalp Pozisyon & Merdiven Kâr Takip Motoru
Tracks open super fast positions in real-time with sub-second WebSocket ticks and micro step-ladder locks.
"""
from typing import Dict, List, Optional
from datetime import datetime
import time

from super_fast_config import (
    SUPER_FAST_LADDER_STEPS,
    SUPER_FAST_DYNAMIC_CHANNEL_PCT,
    SUPER_FAST_MAX_HOLD_MINUTES,
    SUPER_FAST_EARLY_INVALIDATION_ENABLED,
    SUPER_FAST_EARLY_INVALIDATION_MINUTES,
    SUPER_FAST_EARLY_INVALIDATION_LOSS_PCT,
    BINANCE_ROUNDTRIP_FEE_PCT
)
from core.database import (
    get_super_fast_active_and_pending_signals,
    update_super_fast_signal_status,
    add_super_fast_scanner_log_db
)
from core.binance_streamer import get_live_price, add_stream_symbol

class SuperFastCounterfactualTrackerAgent:
    def __init__(self, client, notifier=None):
        self.client = client
        self.notifier = notifier

    def update_open_trades(self) -> List[Dict]:
        """Açık Süper FAST işlemlerin anlık fiyatlarını kontrol eder ve mikro merdiven kârlarını yönetir."""
        active_signals = get_super_fast_active_and_pending_signals()
        if not active_signals:
            return []

        # Lazy REST Fallback: Sadece WebSocket verisi gelmeyen semboller için ihtiyaç halinde çekilir
        cached_tickers = None
        resolved_signals = []
        now = datetime.now()

        for sig in active_signals:
            sig_id = sig["id"]
            symbol = sig["symbol"]
            direction = sig["direction"]
            entry_price = float(sig.get("actual_entry_price") or sig["entry_min"])
            stop_loss = float(sig["stop_loss"])
            tp1 = float(sig["take_profit_1"])
            tp2 = float(sig.get("take_profit_2") or (tp1 * 1.006 if direction == "LONG" else tp1 * 0.994))
            leverage = int(sig.get("leverage") or 10)
            allocated_margin = float(sig.get("allocated_margin_usdt") or 35.0)
            partial_tp_taken = int(sig.get("partial_tp_taken") or 0)

            # 1. Anlık Fiyat (Önce WebSocket, yoksa lazy 24hr ticker, yoksa tekil REST API)
            live_price = None
            try:
                add_stream_symbol(symbol)
                live_price = get_live_price(symbol)
            except Exception:
                live_price = None

            if not live_price or live_price <= 0:
                if cached_tickers is None:
                    try:
                        cached_tickers = self.client.get_24hr_tickers() or {}
                    except Exception:
                        cached_tickers = {}
                ticker_data = cached_tickers.get(symbol, {})
                live_price = ticker_data.get("lastPrice")

            if not live_price or live_price <= 0:
                try:
                    price_info = self.client.get_ticker_price(symbol)
                    if price_info and "price" in price_info:
                        live_price = float(price_info["price"])
                except Exception:
                    pass

            if not live_price or live_price <= 0:
                continue

            highest_price = max(float(sig.get("highest_price") or entry_price), live_price)
            lowest_price = min(float(sig.get("lowest_price") or entry_price), live_price)

            entered_at_str = sig.get("entered_at") or sig.get("created_at")
            minutes_open = 0
            if entered_at_str:
                try:
                    entered_dt = datetime.strptime(str(entered_at_str)[:19], "%Y-%m-%d %H:%M:%S")
                    minutes_open = (now - entered_dt).total_seconds() / 60.0
                except Exception:
                    minutes_open = 0

            ladder_step = int(sig.get("ladder_step") or 0)
            trailing_stop = float(sig.get("trailing_stop") or stop_loss)
            current_sl = max(trailing_stop, stop_loss) if direction == "LONG" else min(trailing_stop, stop_loss)
            ladder_name = sig.get("ladder_name") or ""

            # 2. SANİYELİK MİKRO MERDİVEN KÂR KİLİTLERİ (STEP-LADDER)
            if direction == "LONG":
                peak_gain_pct = ((highest_price - entry_price) / entry_price) * 100.0
                for step in SUPER_FAST_LADDER_STEPS:
                    if peak_gain_pct >= step["trigger_raw_pct"] and step["step"] > ladder_step:
                        locked_sl = entry_price * (1.0 + step["lock_raw_pct"] / 100.0)
                        if locked_sl > current_sl:
                            current_sl = locked_sl
                            ladder_step = step["step"]
                            ladder_name = step["name"]

                # Dinamik Takip Kanalı
                if peak_gain_pct >= 0.28:
                    ch_sl = highest_price * (1.0 - SUPER_FAST_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > current_sl:
                        current_sl = ch_sl
            else: # SHORT
                peak_gain_pct = ((entry_price - lowest_price) / entry_price) * 100.0
                for step in SUPER_FAST_LADDER_STEPS:
                    if peak_gain_pct >= step["trigger_raw_pct"] and step["step"] > ladder_step:
                        locked_sl = entry_price * (1.0 - step["lock_raw_pct"] / 100.0)
                        if locked_sl < current_sl:
                            current_sl = locked_sl
                            ladder_step = step["step"]
                            ladder_name = step["name"]

                if peak_gain_pct >= 0.28:
                    ch_sl = lowest_price * (1.0 + SUPER_FAST_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < current_sl:
                        current_sl = ch_sl

            # 3. ÇIKIŞ KONTROLLERİ (TP, SL, LADDER, TIMEOUT)
            is_closed = False
            exit_price = live_price
            exit_status = ""

            if direction == "LONG":
                # Saniyelik TP1 Parçalı Kâr Alma (Free-Trade Runner)
                if live_price >= tp1 and partial_tp_taken == 0:
                    partial_raw = ((tp1 - entry_price) / entry_price) * 100.0
                    partial_net = (partial_raw * leverage) - (BINANCE_ROUNDTRIP_FEE_PCT * leverage)
                    half_margin = allocated_margin * 0.5
                    realized_usd = round(half_margin * (partial_net / 100.0), 2)
                    current_sl = entry_price * 1.0002
                    ladder_step = max(ladder_step, 2)
                    ladder_name = f"🎯 TP1 %50 Kilit (+${realized_usd}) | Runner"
                    update_super_fast_signal_status(sig_id, {
                        "partial_tp_taken": 1,
                        "realized_pnl_usd": realized_usd,
                        "stop_loss": current_sl,
                        "allocated_margin_usdt": half_margin,
                        "status": "ACTIVE_PARTIAL_TP1",
                        "ladder_step": ladder_step,
                        "ladder_name": ladder_name
                    })
                    partial_tp_taken = 1
                    allocated_margin = half_margin
                    print(f"🎯 [SÜPER FAST {symbol}] TP1 Vuruldu! %50 Kâr Alındı (+${realized_usd}). Stop girişte, Runner devrede!")

                elif partial_tp_taken == 1 and live_price >= tp2:
                    is_closed = True
                    exit_price = tp2
                    exit_status = "HIT_TP2_RUNNER"

                elif live_price <= current_sl:
                    is_closed = True
                    exit_price = current_sl
                    if partial_tp_taken == 1:
                        exit_status = "RUNNER_BE_EXIT"
                    elif ladder_step >= 2:
                        exit_status = f"LADDER_STEP_{ladder_step}_LOCK"
                    elif ladder_step == 1:
                        exit_status = "CLOSED_BE"
                    else:
                        exit_status = "HIT_SL"
                elif live_price >= tp1 and partial_tp_taken == 0:
                    is_closed = True
                    exit_price = tp1
                    exit_status = "HIT_TP"
                elif SUPER_FAST_EARLY_INVALIDATION_ENABLED and ladder_step == 0 and minutes_open >= SUPER_FAST_EARLY_INVALIDATION_MINUTES:
                    raw_diff = (live_price - entry_price) / entry_price
                    if raw_diff <= -(SUPER_FAST_EARLY_INVALIDATION_LOSS_PCT / 100.0):
                        is_closed = True
                        exit_price = live_price
                        exit_status = "EARLY_INVALIDATION_EXIT"
                elif minutes_open >= SUPER_FAST_MAX_HOLD_MINUTES:
                    raw_diff = (live_price - entry_price) / entry_price
                    is_closed = True
                    exit_price = live_price
                    exit_status = "TIMEOUT_PROFIT_EXIT" if raw_diff > 0.0005 else "TIMEOUT_EXIT"

            else: # SHORT
                if live_price <= tp1 and partial_tp_taken == 0:
                    partial_raw = ((entry_price - tp1) / entry_price) * 100.0
                    partial_net = (partial_raw * leverage) - (BINANCE_ROUNDTRIP_FEE_PCT * leverage)
                    half_margin = allocated_margin * 0.5
                    realized_usd = round(half_margin * (partial_net / 100.0), 2)
                    current_sl = entry_price * 0.9998
                    ladder_step = max(ladder_step, 2)
                    ladder_name = f"🎯 TP1 %50 Kilit (+${realized_usd}) | Runner"
                    update_super_fast_signal_status(sig_id, {
                        "partial_tp_taken": 1,
                        "realized_pnl_usd": realized_usd,
                        "stop_loss": current_sl,
                        "allocated_margin_usdt": half_margin,
                        "status": "ACTIVE_PARTIAL_TP1",
                        "ladder_step": ladder_step,
                        "ladder_name": ladder_name
                    })
                    partial_tp_taken = 1
                    allocated_margin = half_margin
                    print(f"🎯 [SÜPER FAST {symbol}] TP1 Vuruldu! %50 Kâr Alındı (+${realized_usd}). Stop girişte, Runner devrede!")

                elif partial_tp_taken == 1 and live_price <= tp2:
                    is_closed = True
                    exit_price = tp2
                    exit_status = "HIT_TP2_RUNNER"

                elif live_price >= current_sl:
                    is_closed = True
                    exit_price = current_sl
                    if partial_tp_taken == 1:
                        exit_status = "RUNNER_BE_EXIT"
                    elif ladder_step >= 2:
                        exit_status = f"LADDER_STEP_{ladder_step}_LOCK"
                    elif ladder_step == 1:
                        exit_status = "CLOSED_BE"
                    else:
                        exit_status = "HIT_SL"
                elif live_price <= tp1 and partial_tp_taken == 0:
                    is_closed = True
                    exit_price = tp1
                    exit_status = "HIT_TP"
                elif SUPER_FAST_EARLY_INVALIDATION_ENABLED and ladder_step == 0 and minutes_open >= SUPER_FAST_EARLY_INVALIDATION_MINUTES:
                    raw_diff = (entry_price - live_price) / entry_price
                    if raw_diff <= -(SUPER_FAST_EARLY_INVALIDATION_LOSS_PCT / 100.0):
                        is_closed = True
                        exit_price = live_price
                        exit_status = "EARLY_INVALIDATION_EXIT"
                elif minutes_open >= SUPER_FAST_MAX_HOLD_MINUTES:
                    raw_diff = (entry_price - live_price) / entry_price
                    is_closed = True
                    exit_price = live_price
                    exit_status = "TIMEOUT_PROFIT_EXIT" if raw_diff > 0.0005 else "TIMEOUT_EXIT"

            # 4. VERİTABANI GÜNCELLEMESİ
            if is_closed:
                raw_gain_pct = ((exit_price - entry_price) / entry_price) * 100.0 if direction == "LONG" else ((entry_price - exit_price) / entry_price) * 100.0
                gross_margin = raw_gain_pct * leverage
                fee_pct = BINANCE_ROUNDTRIP_FEE_PCT * leverage
                net_margin = gross_margin - fee_pct

                prev_realized_usd = float(sig.get("realized_pnl_usd") or 0.0)
                if partial_tp_taken == 1:
                    runner_usd = allocated_margin * (net_margin / 100.0)
                    total_dollar_pnl = prev_realized_usd + runner_usd
                    orig_margin = allocated_margin * 2.0
                    net_margin = (total_dollar_pnl / orig_margin) * 100.0
                    gross_margin = net_margin + fee_pct
                    dollar_pnl = round(total_dollar_pnl, 2)
                else:
                    dollar_pnl = round(allocated_margin * (net_margin / 100.0), 2)

                closed_time = now.strftime("%Y-%m-%d %H:%M:%S")
                update_super_fast_signal_status(sig_id, {
                    "status": exit_status,
                    "closed_at": closed_time,
                    "exit_price": exit_price,
                    "highest_price": highest_price,
                    "lowest_price": lowest_price,
                    "gross_pnl_pct": round(gross_margin, 2),
                    "fee_pct": round(fee_pct, 2),
                    "simulated_pnl_pct": round(net_margin, 2),
                    "trailing_stop": current_sl,
                    "ladder_step": ladder_step,
                    "ladder_name": ladder_name
                })

                dollar_pnl = round(allocated_margin * (net_margin / 100.0), 2)
                resolved_signals.append({
                    "id": sig_id,
                    "symbol": symbol,
                    "direction": direction,
                    "exit_status": exit_status,
                    "net_pnl_pct": round(net_margin, 2),
                    "dollar_gain": dollar_pnl
                })

                # Süper FAST Günlüğüne işle (Panelde görünür, Telegram'a tekil mesaj atılmaz)
                pnl_sign = "+" if net_margin >= 0 else ""
                pnl_emoji = "🟢" if net_margin > 0 else ("🔴" if net_margin < 0 else "⚪")
                add_super_fast_scanner_log_db(
                    symbol,
                    "CLOSED",
                    f"{pnl_emoji} {symbol} {direction} {exit_status}! Net: {pnl_sign}%{net_margin:.2f} ({pnl_sign}${dollar_pnl:.2f})",
                    f"Giriş: {entry_price} ➔ Çıkış: {exit_price}"
                )
            else:
                # Canlı tepe/dip ve trailing stop seviyesini güncelle
                update_super_fast_signal_status(sig_id, {
                    "highest_price": highest_price,
                    "lowest_price": lowest_price,
                    "trailing_stop": current_sl,
                    "ladder_step": ladder_step,
                    "ladder_name": ladder_name,
                    "status": "ACTIVE_LADDER" if ladder_step >= 2 else ("ACTIVE_BE" if ladder_step == 1 else "ACTIVE")
                })

        return resolved_signals

