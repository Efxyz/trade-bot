"""
Risk & Strategy Officer Agent (Dynamic 10x and 20x Specialist)
Enforces strict margin risk caps, validates BTC Market Shield, and assigns
Risk Profile Grades & Dynamic Position Sizing (Fixed 2% Risk Rule):
- Grade A+ : 20x Sniper (Ultra Dar Stop, Yüksek Kar Marjı)
- Grade A  : 10x Düşük Risk / İstikrarlı Kar Marjı
- Grade B  : 10x Orta Risk / Dengeli Fırsat
- Grade C  : 10x Spekülatif / Yüksek Volatilite
"""
from typing import Dict, Tuple, Optional, List
from datetime import datetime, timezone
from config import (
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    PORTFOLIO_EQUITY_USDT,
    RISK_PER_TRADE_PCT,
    MAX_ALLOCATED_MARGIN_PER_TRADE,
    BINANCE_ROUNDTRIP_FEE_PCT,
    MIN_RR_RATIO,
    MAX_ORDERBOOK_SPREAD_PCT,
    MAX_ALLOWED_FUNDING_RATE,
    MAX_POSITIONS_PER_DIRECTION,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
    SIDE_STOPLOSS_COOLDOWN_MINUTES
)

class RiskOfficerAgent:
    def __init__(self):
        pass

    def evaluate(
        self,
        ta_setup: Dict,
        news_analysis: Dict,
        ticker: Dict,
        btc_regime: Optional[Dict] = None,
        funding_data: Optional[Dict] = None,
        book_ticker: Optional[Dict] = None,
        active_signals: Optional[List[Dict]] = None,
        current_equity: Optional[float] = None
    ) -> Tuple[bool, Dict]:
        """
        Setup'ı dinamik kaldıraç (10x veya 20x), komisyon hesabı, slippage (spread),
        fonlama oranı, dinamik bileşik kasa (exponential compounding) ve sabit %2 risk kurallarına göre denetler.
        """
        leverage = ta_setup.get("leverage", 10)
        direction = ta_setup["direction"]
        symbol = ta_setup["symbol"]
        sl_pct = ta_setup["sl_pct"]
        tp1_pct = ta_setup.get("tp1_pct", sl_pct * 1.5)
        tp2_pct = ta_setup.get("tp2_pct", tp1_pct * 1.5)
        rr = ta_setup.get("risk_reward", round(tp1_pct / sl_pct, 2) if sl_pct > 0 else 1.8)
        is_empty_move = news_analysis.get("is_empty_move", False) if news_analysis else False

        # 1. KRİTİK FİLTRE: BTC PİYASA ÇÖKÜŞ VE RALLİ KALKANI (BTC Market Shield)
        if btc_regime and btc_regime.get("block_longs", False) and direction == "LONG":
            return False, {
                "decision": "REJECT",
                "reason": (
                    f"📌 <strong>Mevcut Durum:</strong> BTC Rejimi: {btc_regime.get('status', 'RISK')} ({btc_regime.get('summary', '')}).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Bitcoin düşüş veya ölü testere eğilimindeyken altcoinlerde LONG açmak sermayeyi yüksek riske atar.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> Bitcoin'in yeniden Boğa (BULLISH) trendine dönmesi."
                )
            }
        if btc_regime and btc_regime.get("block_shorts", False) and direction == "SHORT":
            return False, {
                "decision": "REJECT",
                "reason": (
                    f"📌 <strong>Mevcut Durum:</strong> BTC Güçlü Yükseliş Rallisinde (+%{btc_regime.get('change_3h_pct', 0.0)}).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Bitcoin sert ralli yaparken altcoinlerde SHORT açmak tasfiye (likidasyon) riski taşır.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> Rallinin durulması veya sağlıklı düzeltme vermesi."
                )
            }

        # 1.1. HABER KARARLANDIRMA KONSEYİ VETO KALKANI (News Intelligence Veto)
        if news_analysis and news_analysis.get("is_vetoed"):
            return False, {
                "decision": "REJECT",
                "reason": news_analysis.get("veto_reason", "Haber Kararlandırma Konseyi Veto Etti")
            }

        # 1.1 FREQTRADE YÖN BAZLI STOPLOSS GUARD (SIDE-SPECIFIC SERİ ZARAR KALKANI)
        if SIDE_STOPLOSS_GUARD_ENABLED:
            try:
                from core.database import check_side_stoploss_guard
                is_side_locked, lock_reason = check_side_stoploss_guard(
                    direction=direction,
                    max_consecutive_losses=SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
                    cooldown_minutes=SIDE_STOPLOSS_COOLDOWN_MINUTES
                )
                if is_side_locked:
                    opp_side = "LONG" if direction == "SHORT" else "SHORT"
                    return False, {
                        "decision": "REJECT",
                        "reason": (
                            f"📌 <strong>Mevcut Durum:</strong> {direction} Yönünde Seri Kayıp Koruması Devrede.<br>"
                            f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> {lock_reason}<br>"
                            f"🎯 <strong>Beklenen Şart:</strong> Soğuma süresinin tamamlanması veya kârlı yönde ({opp_side}) işlem aranması."
                        )
                    }
            except Exception as e:
                pass

        # 1.5 LİKİDİTE & SLIPPAGE (ORDER BOOK SPREAD) KALKANI
        if book_ticker:
            spread_pct = book_ticker.get("spread_pct", 0.0)
            if spread_pct > MAX_ORDERBOOK_SPREAD_PCT:
                return False, {
                    "decision": "REJECT",
                    "reason": (
                        f"📌 <strong>Mevcut Durum:</strong> Tahtada Alış-Satış Makası: %{spread_pct:.3f} (Maksimum İzin: %{MAX_ORDERBOOK_SPREAD_PCT}).<br>"
                        f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Slippage (Fiyat Kayması) Tuzağı! Makas açık olduğu için emir girildiği an pozisyon doğrudan zararla başlar.<br>"
                        f"🎯 <strong>Beklenen Şart:</strong> Tahtaya likidite girip makasın %{MAX_ORDERBOOK_SPREAD_PCT} altına daralması."
                    )
                }

        # 1.6 8 SAATLİK FONLAMA ORANI & PENCERE KAÇIŞ KALKANI
        if funding_data:
            fr = funding_data.get("lastFundingRate", 0.0)
            now_utc = datetime.now(timezone.utc)
            # 8 saatlik döngü pencereleri: 00:00, 08:00, 16:00 UTC
            hour_mod = now_utc.hour % 8
            minutes_to_settlement = (8 - hour_mod) * 60 - now_utc.minute
            if minutes_to_settlement >= 480:
                minutes_to_settlement = 0

            # Kural A: Genel Zehirli Fonlama Oranı Tavanı
            if direction == "LONG" and fr > MAX_ALLOWED_FUNDING_RATE:
                return False, {
                    "decision": "REJECT",
                    "reason": (
                        f"📌 <strong>Mevcut Durum:</strong> LONG Fonlama Oranı: %{fr*100:.3f} (Tavan: %{MAX_ALLOWED_FUNDING_RATE*100:.2f}).<br>"
                        f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Aşırı fonlama maliyeti! Borsa her 8 saatte bir yüksek komisyon keserek kârınızı eritir.<br>"
                        f"🎯 <strong>Beklenen Şart:</strong> Fonlama oranının %{MAX_ALLOWED_FUNDING_RATE*100:.2f} altına çekilmesi."
                    )
                }
            elif direction == "SHORT" and fr < -MAX_ALLOWED_FUNDING_RATE:
                return False, {
                    "decision": "REJECT",
                    "reason": (
                        f"📌 <strong>Mevcut Durum:</strong> SHORT Fonlama Oranı: %{fr*100:.3f} (Taban: -%{MAX_ALLOWED_FUNDING_RATE*100:.2f}).<br>"
                        f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Aşırı negatif fonlama maliyeti! Borsa SHORT pozisyondan yüksek prim keser.<br>"
                        f"🎯 <strong>Beklenen Şart:</strong> Fonlama oranının normale dönmesi."
                    )
                }

            # Kural B: 8 Saatlik Fonlama Penceresi Kaçış Kalkanı (Settlement'a 30 dk kala fonlama aleyhte ise engelle)
            if minutes_to_settlement <= 30:
                if direction == "LONG" and fr > 0.00015:
                    return False, {
                        "decision": "REJECT",
                        "reason": (
                            f"📌 <strong>Mevcut Durum:</strong> Fonlama Kesintisine {minutes_to_settlement} dk kaldı (Aleyhte: +%{fr*100:.3f}).<br>"
                            f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> 8 saatlik pencere kapanışında ters fonlama ödememek için işlem donduruldu.<br>"
                            f"🎯 <strong>Beklenen Şart:</strong> Fonlama saatinin geçmesi."
                        )
                    }
                elif direction == "SHORT" and fr < -0.00015:
                    return False, {
                        "decision": "REJECT",
                        "reason": (
                            f"📌 <strong>Mevcut Durum:</strong> Fonlama Kesintisine {minutes_to_settlement} dk kaldı (Aleyhte: %{fr*100:.3f}).<br>"
                            f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> 8 saatlik pencere kapanışında ters fonlama ödememek için işlem donduruldu.<br>"
                            f"🎯 <strong>Beklenen Şart:</strong> Fonlama saatinin geçmesi."
                        )
                    }

        # 1.7 SEKTÖR VE AYNI COİN TEKRAR KORUMASI (DIVERSIFICATION GUARD)
        if active_signals:
            for act in active_signals:
                if act.get("symbol") == symbol:
                    return False, {
                        "decision": "REJECT",
                        "reason": f"📌 <strong>Mevcut Durum:</strong> {symbol} paritesinde zaten açık bir işlem var.<br>⛔ <strong>Giriş Yapılmama Nedeni:</strong> Çift risk almayı engelleme kuralı.<br>🎯 <strong>Beklenen Şart:</strong> Mevcut pozisyonun kâr veya stopla kapanması."
                    }

            # 1.8 TEK YÖNE YIĞILMA KALKANI (KORELASYON VE HEDGE KORUMASI - MAKS 3)
            same_dir_count = sum(1 for s in active_signals if s.get("direction") == direction)
            if same_dir_count >= MAX_POSITIONS_PER_DIRECTION:
                opp_dir = "SHORT" if direction == "LONG" else "LONG"
                return False, {
                    "decision": "REJECT",
                    "reason": (
                        f"📌 <strong>Mevcut Durum:</strong> Radarda halihazırda {same_dir_count} adet {direction} pozisyonu açık.<br>"
                        f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Tek Yöne Yığılma Kalkanı (Maksimum {MAX_POSITIONS_PER_DIRECTION} {direction} kotası dolu).<br>"
                        f"🎯 <strong>Beklenen Şart:</strong> Portföy dengesi için zıt yönde ({opp_dir}) işlem bulunması veya bir {direction} pozisyonunun kapanması."
                    )
                }

        # Vadeye Göre Dinamik Stop-Loss Tavanı (15m Kısa / 30m Orta / 1h Uzun)
        timeframe = ta_setup.get("timeframe") or ("1h" if "1h" in str(ta_setup.get("trade_horizon")) else ("30m" if "30m" in str(ta_setup.get("trade_horizon")) else "15m"))
        if timeframe == "1h":
            effective_max_sl_10x = 2.90
            effective_max_sl_20x = 1.80
        elif timeframe == "30m":
            effective_max_sl_10x = 1.85
            effective_max_sl_20x = 1.40
        else:
            effective_max_sl_10x = MAX_SL_PCT_10X
            effective_max_sl_20x = MAX_SL_PCT_20X

        # 2. KALDIRAÇ VE SL UYGUNLUK DENETİMİ
        if leverage == 20:
            if sl_pct > effective_max_sl_20x:
                leverage = 10
                ta_setup["leverage"] = 10
                ta_setup["setup_type"] = "10x STANDART TREND"

        if leverage == 10:
            if sl_pct > effective_max_sl_10x:
                return False, {
                    "decision": "REJECT",
                    "reason": (
                        f"📌 <strong>Mevcut Durum:</strong> Stop Mesafesi: %{sl_pct:.2f} ({timeframe} 10x Sınırı: %{effective_max_sl_10x:.2f}).<br>"
                        f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Stop mesafesi {timeframe} 10x için fazla geniş.<br>"
                        f"🎯 <strong>Beklenen Şart:</strong> Daha dar stoplu (%{effective_max_sl_10x:.2f} altı) güvenli bir formasyon oluşması."
                    )
                }

        # 3. RİSK / ÖDÜL DENETİMİ (En az MIN_RR_RATIO = 1.4)
        if rr < MIN_RR_RATIO:
            return False, {
                "decision": "REJECT",
                "reason": (
                    f"📌 <strong>Mevcut Durum:</strong> Risk/Ödül Oranı 1:{rr:.2f} (Minimum Baraj: 1:{MIN_RR_RATIO}).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Olası kâr, göze alınan riski karşılamıyor.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> En az 1:{MIN_RR_RATIO} getiri vadeden bir kurulum bulunması."
                )
            }

        # 4. GERÇEKÇİ BORSA KOMİSYONU & MARJİN NET HESAPLAMALARI
        # Binance Futures Taker: Giriş %0.05 + Çıkış %0.05 = %0.10 raw price
        fee_drag_pct = round(BINANCE_ROUNDTRIP_FEE_PCT * leverage, 2)  # 10x'te %1.0, 20x'te %2.0 marjin komisyonu
        
        gross_margin_risk_pct = round(sl_pct * leverage, 1)
        net_margin_risk_pct = round(gross_margin_risk_pct + fee_drag_pct, 1)

        gross_tp1_margin_pct = round(tp1_pct * leverage, 1)
        net_tp1_margin_pct = round(gross_tp1_margin_pct - fee_drag_pct, 1)

        gross_tp2_margin_pct = round(tp2_pct * leverage, 1)
        net_tp2_margin_pct = round(gross_tp2_margin_pct - fee_drag_pct, 1)

        # 5. DİNAMİK BİLEŞİK KASA VE POZİSYON BOYUTLANDIRMA (EXPONENTIAL COMPOUNDING & %2 RİSK KURALI)
        # Kasa arttıkça pozisyon büyüklüğü eşzamanlı katlanır (bileşik faiz); düşüşte ise kayıp frenlenir.
        active_equity = float(current_equity) if current_equity and current_equity > 50.0 else PORTFOLIO_EQUITY_USDT
        target_risk_usd = round(active_equity * (RISK_PER_TRADE_PCT / 100.0), 2)
        total_sl_loss_fraction = (sl_pct * leverage + fee_drag_pct) / 100.0
        
        calculated_margin = target_risk_usd / total_sl_loss_fraction if total_sl_loss_fraction > 0 else (active_equity * 0.15)
        
        # Dinamik marjin tavanı: 5 pozisyon için kasanın en fazla %20'si tek bir işleme ayrılabilir
        dynamic_max_margin = round(active_equity * 0.20, 1)
        allocated_margin = round(max(30.0, min(dynamic_max_margin, calculated_margin)), 1)

        # 5.1. Haber Kararlandırma Konseyi Pozisyon Büyüklüğü & Yüzdelik Kararı (News Council Multiplier)
        news_multiplier = float(news_analysis.get("pos_multiplier", 1.0)) if news_analysis else 1.0
        if news_multiplier > 0 and news_multiplier != 1.0:
            allocated_margin = round(max(25.0, min(dynamic_max_margin * 1.25, allocated_margin * news_multiplier)), 1)

        actual_risk_usd = round(allocated_margin * total_sl_loss_fraction, 2)

        # 6. RİSK SINIFLANDIRMASI (GRADE A+, A, B, C)
        if leverage == 20 and sl_pct <= MAX_SL_PCT_20X and not is_empty_move:
            risk_grade = "Grade A+ (20x Sniper / Ultra Dar Stop)"
            risk_desc = (
                f"Süper dar stop (%{sl_pct}), net SMC kırılımı. "
                f"20x kaldıraç ile TP'de net +%{net_tp1_margin_pct} kâr."
            )
        elif leverage == 10 and sl_pct <= MAX_SL_PCT_10X and not is_empty_move:
            risk_grade = "Grade A (10x Düşük Risk / İstikrarlı Scalp)"
            risk_desc = f"Sağlam trend desteği, düşük marjin riski (net -%{net_margin_risk_pct}) ve güvenli haber akışı."
        elif is_empty_move and direction == "LONG":
            risk_grade = "Grade C (10x Yüksek Risk / Spekülatif Şişme)"
            risk_desc = "Haber akışı zayıf veya likidite avı şüphesi var. Sermaye düşük tutulmalı."
            allocated_margin = max(30.0, round(allocated_margin * 0.6, 1))
        else:
            risk_grade = "Grade B (10x Orta Risk / Standart Fırsat)"
            risk_desc = "Trend yönünde dengeli kurulum. Standart volatilite."

        risk_report = {
            "decision": "APPROVED",
            "leverage": leverage,
            "risk_grade": risk_grade,
            "risk_desc": risk_desc,
            "portfolio_equity_usdt": active_equity,
            "allocated_margin_usdt": allocated_margin,
            "risk_usd": actual_risk_usd,
            "fee_drag_pct": fee_drag_pct,
            "margin_risk_pct": net_margin_risk_pct,
            "margin_tp1_pct": net_tp1_margin_pct,
            "margin_tp2_pct": net_tp2_margin_pct,
            "recommendation": (
                f"{leverage}x Kaldıraç | Tahsis Marjin: ${allocated_margin} (Risk: ${actual_risk_usd} / %{RISK_PER_TRADE_PCT} Kasa). "
                f"Net SL: -%{net_margin_risk_pct} (Komisyon dahil), Net TP: +%{net_tp1_margin_pct}."
            )
        }
        return True, risk_report
