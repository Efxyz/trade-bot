with open("agents/ta_agent.py", "r", encoding="utf-8") as f:
    text = f.read()

old_long_prem = '''            # 1. SMC Discount Kalkanı: Tepeden Alımı Kesinlikle Engelle
            # Fiyat dalganın üst %55'inde (Primli/Premium bölgede) ise ve aktif FVG/OB desteği test edilmiyorsa elenir!
            if SMC_PREMIUM_DISCOUNT_FILTER and zone_pct > 55.0 and fvg["current_in_fvg"] != "BULLISH_TEST" and ob["current_at_ob"] != "BULLISH_OB_RETEST":
                return None, (
                    f"📌 <strong>Mevcut Durum:</strong> Fiyat Primli / Premium Bölgede (%{zone_pct:.1f} / Denge: %50.0).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Yükseliş dalgasının tepesinde alım (long) açmak kurumsal kar realizasyonu tuzağına çeker.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> Fiyatın İndirimli (Discount < %50) bölgeye veya Bullish FVG/OB desteğine geri çekilmesi (pullback)."
                )'''

new_long_prem = '''            # 1. SMC Discount Kalkanı: Aşırı Şişkinlik / Tepe Alımını Engelle
            # Sadece aşırı tepe bölgesinde (%88 üzeri) ve taze FVG/OB desteği veya Squeeze kırılımı YOKSA engellenir!
            has_fresh_support = (
                fvg.get("current_in_fvg") == "BULLISH_TEST" or
                ob.get("current_at_ob") == "BULLISH_OB_RETEST" or
                (fvg.get("bullish_fvg") and fvg["bullish_fvg"].get("age_candles", 10) <= 3) or
                (squeeze.get("squeeze_fired") and squeeze.get("momentum") > 0)
            )
            if SMC_PREMIUM_DISCOUNT_FILTER and zone_pct > 88.0 and not has_fresh_support:
                return None, (
                    f"📌 <strong>Mevcut Durum:</strong> Fiyat Aşırı Primli Bölgede (%{zone_pct:.1f} / Denge: %50.0).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Yükseliş dalgasının aşırı tepesinde alım (long) açmak kurumsal kar realizasyonu tuzağına çeker.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> Fiyatın konsolide olup desteğe gevşemesi."
                )'''

old_short_prem = '''            # 1. SMC Premium Kalkanı: Dipten Satışı Kesinlikle Engelle
            # Fiyat dalganın alt %45'inde (İndirimli/Discount bölgede) ise ve aktif FVG/OB direnci test edilmiyorsa elenir!
            if SMC_PREMIUM_DISCOUNT_FILTER and zone_pct < 45.0 and fvg["current_in_fvg"] != "BEARISH_TEST" and ob["current_at_ob"] != "BEARISH_OB_RETEST":
                return None, (
                    f"📌 <strong>Mevcut Durum:</strong> Fiyat İndirimli / Discount Bölgede (%{zone_pct:.1f} / Denge: %50.0).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Düşüş dalgasının dip seviyesinde satış (short) açmak kurumsal dip avı (V-dip) tuzağına çeker.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> Fiyatın Primli (Premium > %50) bölgeye veya Bearish FVG/OB direncine retest yapması."
                )'''

new_short_prem = '''            # 1. SMC Premium Kalkanı: Aşırı Dipte Satışı Engelle
            has_fresh_resistance = (
                fvg.get("current_in_fvg") == "BEARISH_TEST" or
                ob.get("current_at_ob") == "BEARISH_OB_RETEST" or
                (fvg.get("bearish_fvg") and fvg["bearish_fvg"].get("age_candles", 10) <= 3) or
                (squeeze.get("squeeze_fired") and squeeze.get("momentum") < 0)
            )
            if SMC_PREMIUM_DISCOUNT_FILTER and zone_pct < 12.0 and not has_fresh_resistance:
                return None, (
                    f"📌 <strong>Mevcut Durum:</strong> Fiyat Aşırı Dip Bölgede (%{zone_pct:.1f} / Denge: %50.0).<br>"
                    f"⛔ <strong>Giriş Yapılmama Nedeni:</strong> Düşüş dalgasının aşırı dibinde satış (short) açmak kurumsal dip alımı tuzağına çeker.<br>"
                    f"🎯 <strong>Beklenen Şart:</strong> Fiyatın tepki verip dirence yükselmesi."
                )'''

assert old_long_prem in text, "old_long_prem not found"
assert old_short_prem in text, "old_short_prem not found"

text = text.replace(old_long_prem, new_long_prem)
text = text.replace(old_short_prem, new_short_prem)

with open("agents/ta_agent.py", "w", encoding="utf-8") as f:
    f.write(text)
print("Updated premium/discount filter in agents/ta_agent.py!")
