import sys
import os
import requests

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from dotenv import load_dotenv
load_dotenv(os.path.join(WORKSPACE_DIR, ".env"), override=True)

bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
chat_id = os.getenv("TELEGRAM_CHAT_ID")

print(f"Token (masked): {bot_token[:10]}...{bot_token[-6:]}")
print(f"Chat ID: {chat_id}")

# 1. getMe testi
url_me = f"https://api.telegram.org/bot{bot_token}/getMe"
resp_me = requests.get(url_me, timeout=10).json()
print("getMe Sonucu:", resp_me)

# 2. Test Bildirimi Gönder
if resp_me.get("ok"):
    url_msg = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": "🛡️ *Güvenlik Bildirimi: Telegram Bot Token'ı Başarıyla Yenilendi!*\n\nPatronum, yeni token'ınız sisteme tanımlandı ve doğrulandı. Eski token geçersiz kılındı. Botunuz tam güvenlik altında aktiftir! 🚀",
        "parse_mode": "Markdown"
    }
    resp_msg = requests.get(url_msg, params=payload, timeout=10).json()
    print("Mesaj Gönderim Sonucu:", resp_msg)
