import os

for folder in ['agents', 'core', 'data', 'scratch']:
    if os.path.exists(folder):
        print(f"\n===============================")
        print(f"FOLDER: {folder}/")
        print(f"===============================")
        for root, dirs, files in os.walk(folder):
            rel_dir = os.path.relpath(root, folder)
            indent = "  " if rel_dir != "." else ""
            if rel_dir != ".":
                print(f"📁 {rel_dir}/")
            for f in sorted(files):
                if f.endswith('.pyc') or '__pycache__' in root:
                    continue
                fp = os.path.join(root, f)
                sz = os.path.getsize(fp)
                sz_str = f"{sz/1024:.1f} KB" if sz > 1024 else f"{sz} B"
                print(f"{indent}📄 {f:<30} {sz_str:>10}")

