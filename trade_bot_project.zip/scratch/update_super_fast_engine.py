with open("super_fast_engine.py", "r", encoding="utf-8") as f:
    text = f.read()

# Import new constants
old_imp = """    SUPER_FAST_CIRCUIT_BREAKER_ENABLED,
    SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT,"""

new_imp = """    SUPER_FAST_CIRCUIT_BREAKER_ENABLED,
    SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT,
    SUPER_FAST_MAX_DAILY_TRADES,
    SUPER_FAST_MAX_DAILY_FEE_USDT,"""

text = text.replace(old_imp, new_imp)

# In run_cycle:
old_cycle = """        # 2. Günlük Devre Kesici (Circuit Breaker) Kontrolü
        if SUPER_FAST_CIRCUIT_BREAKER_ENABLED:
            stats = get_super_fast_performance_stats() or {}
            today_dollar_gain = float(stats.get("today_dollar_gain") or 0.0)
            if today_dollar_gain <= -SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT:
                add_super_fast_scanner_log_db(
                    "CIRCUIT_BREAKER",
                    "STOPPED",
                    f"Süper FAST Günlük Maksimum Zarar Sınırına (-${SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT}) Ulaşıldı."
                )
                return"""

new_cycle = """        # 2. Günlük Devre Kesici & Sert İşlem/Komisyon Kotası (Anti-Overtrading Guard)
        stats = get_super_fast_performance_stats() or {}
        today_trades = int(stats.get("today_trades") or 0)
        today_dollar_gain = float(stats.get("today_dollar_gain") or 0.0)
        today_fee_pct = float(stats.get("today_fee_pct") or 0.0)
        today_fee_usd = (today_fee_pct / 100.0) * SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE

        # A) Sert Günlük İşlem Kotası (Maks 25 İşlem)
        if today_trades >= SUPER_FAST_MAX_DAILY_TRADES:
            add_super_fast_scanner_log_db(
                "CIRCUIT_BREAKER",
                "STOPPED",
                f"⚡⚡ Süper FAST Günlük İşlem Kotası ({today_trades}/{SUPER_FAST_MAX_DAILY_TRADES}) Doldu. Komisyon Koruma Kilidi Aktif."
            )
            return

        # B) Günlük Komisyon Tavanı (Maks $20)
        if today_fee_usd >= SUPER_FAST_MAX_DAILY_FEE_USDT:
            add_super_fast_scanner_log_db(
                "CIRCUIT_BREAKER",
                "STOPPED",
                f"⚡⚡ Süper FAST Günlük Komisyon Tavanı (${today_fee_usd:.2f} >= ${SUPER_FAST_MAX_DAILY_FEE_USDT}) Aşıldı. Komisyon Kilidi."
            )
            return

        # C) Günlük Zarar Limiti Devre Kesici
        if SUPER_FAST_CIRCUIT_BREAKER_ENABLED and today_dollar_gain <= -SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT:
            add_super_fast_scanner_log_db(
                "CIRCUIT_BREAKER",
                "STOPPED",
                f"Süper FAST Günlük Maksimum Zarar Sınırına (-${SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT}) Ulaşıldı."
            )
            return"""

assert old_imp in text, "old_imp not found"
assert old_cycle in text, "old_cycle not found"

text = text.replace(old_imp, new_imp)
text = text.replace(old_cycle, new_cycle)

with open("super_fast_engine.py", "w", encoding="utf-8") as f:
    f.write(text)
print("super_fast_engine.py updated successfully!")

