import zipfile
import os

repos_dir = os.path.join(os.getcwd(), "github repoları")
extract_root = os.path.join(os.getcwd(), "scratch", "extracted_repos")
os.makedirs(extract_root, exist_ok=True)

zip_files = [f for f in os.listdir(repos_dir) if f.endswith(".zip")]
print(f"Found {len(zip_files)} zip files to extract:")

for zname in sorted(zip_files):
    zpath = os.path.join(repos_dir, zname)
    target_folder = os.path.join(extract_root, zname.replace(".zip", ""))
    print(f"\nExtracting {zname} -> {target_folder}...")
    if not os.path.exists(target_folder):
        os.makedirs(target_folder, exist_ok=True)
        try:
            with zipfile.ZipFile(zpath, 'r') as zip_ref:
                zip_ref.extractall(target_folder)
            print(f"Successfully extracted {zname}")
        except Exception as e:
            print(f"Error extracting {zname}: {e}")
    else:
        print(f"Already extracted {zname}")

print("\nSummary of extracted folders:")
for item in os.listdir(extract_root):
    subpath = os.path.join(extract_root, item)
    if os.path.isdir(subpath):
        sub_items = os.listdir(subpath)
        print(f" - {item}: {len(sub_items)} top-level items ({sub_items[:5]}...)")

