import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent

client = BinanceFuturesClient()

# Check volume burst with 0.60
for sym in ["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT"]:
    c15m = client.get_klines(sym, interval="15m", limit=30)
    prior = [c["volume"] for c in c15m[-12:-2]]
    avg_v = sum(prior) / len(prior)
    prev_v = c15m[-2]["volume"]
    ratio = prev_v / avg_v if avg_v > 0 else 0
    passes_060 = ratio >= 0.60
    print(f"{sym}: prev_vol={prev_v:.1f}, avg={avg_v:.1f}, ratio={ratio:.2f} -> Passes 0.60: {passes_060}")
