import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from dashboard import app

client = app.test_client()

print("=" * 80)
print("🧪 DASHBOARD ADMIN GÜVENLİK PIN TESTİ")
print("=" * 80)

# 1. PIN'siz İstek (Yetkisiz Saldırgan Senaryosu)
res1 = client.post("/api/close-all-positions")
print(f"1. PIN'siz POST İsteği Sonucu: HTTP {res1.status_code}")
print(f"   Yanıt: {res1.get_json()}")
assert res1.status_code == 401, "HATA: PIN'siz istek 401 dönmedi!"

# 2. Hatalı PIN ile İstek
res2 = client.post("/api/close-all-positions", headers={"X-Admin-Pin": "0000"})
print(f"\n2. Hatalı PIN ('0000') ile İstek: HTTP {res2.status_code}")
assert res2.status_code == 401, "HATA: Hatalı PIN engellenmedi!"

# 3. Doğru PIN ('1923') ile İstek
res3 = client.post("/api/close-all-positions", headers={"X-Admin-Pin": "1923"})
print(f"\n3. Doğru PIN ('1923') ile İstek: HTTP {res3.status_code}")
print(f"   Yanıt: {res3.get_json()}")
assert res3.status_code == 200, "HATA: Doğru PIN ile istek başarılı olmadı!"

print("\n" + "=" * 80)
print("✅ TÜM GÜVENLİK TESTLERİ BAŞARIYLA GEÇTİ!")
print("=" * 80)
