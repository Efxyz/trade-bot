import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

import json
import urllib.request
from sync_to_github import get_token, REPO_OWNER, REPO_NAME, BRANCH

token = get_token()
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github.v3+json",
    "User-Agent": "Antigravity-SecurityAudit"
}

# Check all commits for .env
url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/commits?path=.env"
req = urllib.request.Request(url, headers=headers, method="GET")
with urllib.request.urlopen(req) as resp:
    commits = json.loads(resp.read().decode("utf-8"))
    print(f"Total commits touching .env: {len(commits)}")
    for c in commits:
        sha = c["sha"]
        c_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/commits/{sha}"
        c_req = urllib.request.Request(c_url, headers=headers, method="GET")
        with urllib.request.urlopen(c_req) as c_resp:
            c_data = json.loads(c_resp.read().decode("utf-8"))
            for f in c_data.get("files", []):
                if f["filename"] == ".env":
                    patch = f.get("patch", "")
                    print(f"Commit {sha[:7]} by {c_data['commit']['author']['name']}:")
                    for line in patch.splitlines():
                        if "TOKEN" in line or "KEY" in line or "SECRET" in line:
                            # mask line
                            print("   ", line[:15] + "..." + line[-8:] if len(line) > 23 else line)
