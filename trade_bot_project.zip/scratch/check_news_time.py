with open("agents/news_agent.py", "r", encoding="utf-8") as f:
    lines = f.readlines()
for i, l in enumerate(lines):
    if "time" in l and ("strftime" in l or "now" in l or "entry" in l or "format" in l or "dict" in l):
        print(f"L{i+1}: {l.strip()[:100]}")
