import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "AI-Trader-main", "AI-Trader-main")

print("=== AI TRADER SCAN ===")
for root, dirs, files in os.walk(base):
    for f in files:
        if "agent" in f.lower() or "debate" in f.lower() or "prompt" in f.lower() or "strategy" in f.lower():
            p = os.path.join(root, f)
            print(os.path.relpath(p, base))

