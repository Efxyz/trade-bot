import json

with open(r'C:\Users\isiks\.gemini\antigravity\brain\a2f493b1-6bd2-4f3b-a3f9-f21e7725bbd5\.system_generated\logs\transcript_full.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        if '"step_index":5489' in line and '"name":"write_file"' in line:
            obj = json.loads(line)
            for c in obj.get('tool_calls', []):
                full_c = c.get('args', {}).get('Content', '')
                with open(r'scratch\recovered_bu_haliyle.py', 'w', encoding='utf-8') as out:
                    out.write(full_c)
                print("Written recovered_bu_haliyle.py, len:", len(full_c))
            break
