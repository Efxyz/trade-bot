import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

coins = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "NEARUSDT", "XRPUSDT", "DOGEUSDT", "BNBUSDT", "FETUSDT"]

print(f"{'SYMBOL':<10} | {'SETUP':<5} | {'DIR':<5} | {'SCORE':<5} | {'RR':<4} | {'TA REASON'}")
print("=" * 80)

for sym in coins:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    setup, reason = agent.analyze_setup(sym, c15m, c1h)
    
    if setup:
        print(f"{sym:<10} | True  | {setup['direction']:<5} | {setup['confluence_score']:<5} | {setup['risk_reward']:<4} | {setup['ta_reasons'][:50]}...")
    else:
        print(f"{sym:<10} | False | {'-':<5} | {'-':<5} | {'-':<4} | {reason[:50]}...")

