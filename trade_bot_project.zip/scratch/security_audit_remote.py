import sys
import os
import json
import urllib.request
import urllib.error
from pathlib import Path

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from sync_to_github import get_token, REPO_OWNER, REPO_NAME, BRANCH

def audit_github_repo():
    token = get_token()
    if not token:
        print("❌ GITHUB_TOKEN bulunamadı.")
        return

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Antigravity-SecurityAudit"
    }

    print("=" * 80)
    print("🔒 GİTHUB REPO GÜVENLİK VE GİZLİLİK DENETİMİ (Efxyz/trade-bot)")
    print("=" * 80)

    # 1. Reponun Gizlilik (Visibility) Durumu: Public mi Private mı?
    repo_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}"
    try:
        req = urllib.request.Request(repo_url, headers=headers, method="GET")
        with urllib.request.urlopen(req) as resp:
            repo_info = json.loads(resp.read().decode("utf-8"))
            is_private = repo_info.get("private", False)
            visibility = "🔒 PRIVATE (Gizli)" if is_private else "⚠️ PUBLIC (Herkese Açık!)"
            print(f"\n1. REPO GÖRÜNÜRLÜĞÜ: {visibility}")
            print(f"   Açıklama: Repo {'yalnızca size özel' if is_private else 'TÜM DÜNYAYA AÇIK, HERKES GÖREBİLİR!'}")
    except Exception as e:
        print(f"❌ Repo bilgisi alınamadı: {e}")
        is_private = None

    # 2. Ağaçtaki Tüm Dosyaları Tara (Recursive Tree)
    tree_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/trees/{BRANCH}?recursive=1"
    try:
        req = urllib.request.Request(tree_url, headers=headers, method="GET")
        with urllib.request.urlopen(req) as resp:
            tree_data = json.loads(resp.read().decode("utf-8"))
            files = [item["path"] for item in tree_data.get("tree", []) if item["type"] == "blob"]
            print(f"\n2. TOPLAM DOSYA SAYISI: {len(files)} adet dosya mevcut.")

            # Şüpheli dosya isimleri kontrolü
            sensitive_patterns = [".env", ".key", ".pem", "secret", "password", ".db", "token", "credentials", "id_rsa"]
            leaked_files = []
            for f in files:
                f_lower = f.lower()
                for pat in sensitive_patterns:
                    if pat in f_lower and not f_lower.endswith(".example") and not f_lower.endswith(".md"):
                        leaked_files.append((f, pat))
                        break

            if leaked_files:
                print("   🚨 DİKKAT: Repoda potansiyel hassas / sızma riski taşıyan dosyalar bulundu:")
                for lf, p in leaked_files:
                    print(f"      - {lf} (Eşleşen desen: {p})")
            else:
                print("   ✅ Temiz: .env veya doğrudan hassas isimli bir anahtar dosyası repoda bulunamadı.")

    except Exception as e:
        print(f"❌ Dosya ağacı alınamadı: {e}")

    # 3. Son Commit Mesajlarını İncele
    commits_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/commits?per_page=15"
    try:
        req = urllib.request.Request(commits_url, headers=headers, method="GET")
        with urllib.request.urlopen(req) as resp:
            commits = json.loads(resp.read().decode("utf-8"))
            print(f"\n3. SON {len(commits)} COMMİT GEÇMİŞİ:")
            for c in commits[:8]:
                sha = c["sha"][:7]
                author = c.get("commit", {}).get("author", {}).get("name", "Bilinmeyen")
                msg = c.get("commit", {}).get("message", "").split("\n")[0]
                date = c.get("commit", {}).get("author", {}).get("date", "")
                print(f"   [{sha}] {date[:10]} | {author}: {msg[:60]}")
    except Exception as e:
        print(f"❌ Commit geçmişi alınamadı: {e}")

if __name__ == "__main__":
    audit_github_repo()
