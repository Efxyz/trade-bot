import sys, os
sys.path.insert(0, os.getcwd())
import sqlite3
from config import DB_PATH

print(f"Connecting to {DB_PATH}...")
conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

cursor.execute("SELECT id, symbol, direction, actual_entry_price, exit_price, status, simulated_pnl_pct, gross_pnl_pct, entered_at, closed_at, ta_reasons, news_summary FROM signals ORDER BY id DESC LIMIT 5")
rows = cursor.fetchall()

print(f"Found {len(rows)} recent signals:")
for r in rows:
    print(dict(r))

# Check github repolari folder
repo_dir = os.path.join(os.getcwd(), "github repoları")
print("\nChecking repo_dir:", repo_dir, "exists?", os.path.exists(repo_dir))
if os.path.exists(repo_dir):
    items = os.listdir(repo_dir)
    print(f"Found {len(items)} items in {repo_dir}:")
    for item in items:
        full = os.path.join(repo_dir, item)
        is_dir = os.path.isdir(full)
        print(f" - {'[DIR]' if is_dir else '[FILE]'} {item} ({os.path.getsize(full) if not is_dir else 'dir'})")
