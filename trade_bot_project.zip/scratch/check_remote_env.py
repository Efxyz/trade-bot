import sys
import os
import json
import base64
import urllib.request
from pathlib import Path

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from sync_to_github import get_token, REPO_OWNER, REPO_NAME, BRANCH

token = get_token()
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github.v3+json",
    "User-Agent": "Antigravity-SecurityAudit"
}

url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/.env?ref={BRANCH}"
try:
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        content_b64 = data.get("content", "")
        raw_bytes = base64.b64decode(content_b64)
        content_str = raw_bytes.decode("utf-8", errors="ignore")
        print("--- GITHUB'DAKİ .env DOSYASININ İÇERİĞİ (SATIR BAŞLARI VE DEĞER UZUNLUKLARI) ---")
        for line in content_str.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip()
                masked = v[:4] + "..." + v[-4:] if len(v) > 8 else "***"
                print(f"Key: {k} | Value: {masked} | Length: {len(v)}")
except Exception as e:
    print(f"Hata: {e}")
