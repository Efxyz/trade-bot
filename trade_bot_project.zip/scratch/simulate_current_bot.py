import json
import os
import sys
import time
from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
os.chdir(str(project_root))

from config import (
    BINANCE_ROUNDTRIP_FEE_PCT,
    BONUS_TRADES_PER_STEP,
    DAILY_BASE_MAX_TRADES,
    DAILY_MAX_DRAWDOWN_USDT,
    DAILY_TRAILING_PROFIT_LOCK_ENABLED,
    EARLY_INVALIDATION_ENABLED,
    EARLY_INVALIDATION_LOSS_PCT,
    EARLY_INVALIDATION_MINUTES,
    EXCLUDED_SYMBOLS_BLACKLIST,
    LADDER_DYNAMIC_CHANNEL_PCT,
    LADDER_STEPS,
    LEVERAGE_HIGH,
    LEVERAGE_STANDARD,
    MAX_CONCURRENT_TRADES,
    MAX_HOLD_MINUTES,
    MAX_POSITIONS_PER_DIRECTION,
    MAX_SCALP_SL_PCT,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_RR_RATIO,
    MIN_SCALP_SL_PCT,
    PORTFOLIO_EQUITY_USDT,
    POST_LOSS_COOLDOWN_MINUTES,
    PROFIT_STEP_FOR_BONUS_TRADES,
    RISK_PER_TRADE_PCT,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
)
from agents.ta_agent import TechnicalAnalysisAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

def build_full_1h_candles(candles_15m):
    candles_1h = []
    bucket = []
    current_hour = None
    for c in candles_15m:
        hour_ts = (c['timestamp'] // (3600 * 1000)) * (3600 * 1000)
        if current_hour is None:
            current_hour = hour_ts
        if hour_ts != current_hour and bucket:
            candles_1h.append({
                'timestamp': current_hour,
                'open': bucket[0]['open'],
                'high': max(b['high'] for b in bucket),
                'low': min(b['low'] for b in bucket),
                'close': bucket[-1]['close'],
                'volume': sum(b['volume'] for b in bucket)
            })
            bucket = [c]
            current_hour = hour_ts
        else:
            bucket.append(c)
    if bucket:
        candles_1h.append({
            'timestamp': current_hour,
            'open': bucket[0]['open'],
            'high': max(b['high'] for b in bucket),
            'low': min(b['low'] for b in bucket),
            'close': bucket[-1]['close'],
            'volume': sum(b['volume'] for b in bucket)
        })
    return candles_1h

print("1. 30 Günlük Veriler Yükleniyor...", flush=True)
coin_data = {}
all_ts = set()
for sym, c_list in raw_cache.items():
    if sym in EXCLUDED_SYMBOLS_BLACKLIST:
        continue
    c_1h = build_full_1h_candles(c_list)
    h_close_ts = [c['timestamp'] + 3600*1000 for c in c_1h]
    coin_data[sym] = {
        'list_15m': c_list,
        'by_ts': {x['timestamp']: x for x in c_list},
        'idx_by_ts': {x['timestamp']: i for i, x in enumerate(c_list)},
        'list_1h': c_1h,
        'h_close_ts': h_close_ts
    }
    all_ts.update(x['timestamp'] for x in c_list)

sorted_ts = sorted(list(all_ts))

print("2. Sinyaller Önceden Taranıyor...", flush=True)
ta_agent = TechnicalAnalysisAgent()
signals_by_ts = {ts: [] for ts in sorted_ts}

for sym, d in coin_data.items():
    c15 = d['list_15m']
    c1h = d['list_1h']
    h_close_ts = d['h_close_ts']
    for idx, c in enumerate(c15):
        if idx < 45:
            continue
        ts = c['timestamp']
        win_15m = c15[max(0, idx-59) : idx+1]
        h_end_idx = bisect_right(h_close_ts, ts)
        win_1h = c1h[max(0, h_end_idx-35) : h_end_idx] if h_end_idx >= 15 else None
        
        setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
        if setup:
            signals_by_ts[ts].append((sym, setup))

def run_backtest(
    name: str,
    early_inv_enabled: bool = True,
    early_inv_mins: int = 20,
    early_inv_pct: float = 0.35,
    side_guard_enabled: bool = True,
    ladder_steps = LADDER_STEPS
):
    initial_equity = 1000.0
    equity = initial_equity
    max_concurrent = 5
    max_per_dir = 3
    target_risk_usd = 20.0

    active_trades = []
    completed_trades = []
    cooldown_until = {}
    side_consecutive_losses = {"LONG": 0, "SHORT": 0}
    side_locked_until = {"LONG": 0, "SHORT": 0}

    current_day_str = None
    daily_trades_count = 0
    daily_net_dollar = 0.0
    daily_loss_sum = 0.0
    daily_circuit_breaker = False
    daily_profit_locked = False
    daily_peak_pnl = 0.0
    daily_history = []
    equity_curve = []

    for ts in sorted_ts:
        dt = datetime.fromtimestamp(ts / 1000, tz=timezone.utc)
        day_str = dt.strftime("%Y-%m-%d")
        current_time_str = dt.strftime("%Y-%m-%d %H:%M")

        if current_day_str != day_str:
            if current_day_str is not None:
                daily_history.append({
                    'day': current_day_str,
                    'trades': daily_trades_count,
                    'net_pnl': round(daily_net_dollar, 2),
                    'equity': round(equity, 2),
                    'breaker': daily_circuit_breaker,
                    'profit_locked': daily_profit_locked
                })
            current_day_str = day_str
            daily_trades_count = 0
            daily_net_dollar = 0.0
            daily_loss_sum = 0.0
            daily_circuit_breaker = False
            daily_profit_locked = False
            daily_peak_pnl = 0.0

        # Pozisyon Takibi
        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            c_info = coin_data.get(sym, {}).get('by_ts', {}).get(ts)
            if not c_info:
                still_active.append(trade)
                continue

            high_p = c_info['high']
            low_p = c_info['low']
            close_p = c_info['close']

            direction = trade['direction']
            entry_p = trade['entry_price']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            lev = trade['leverage']

            trade['bars_held'] += 1
            bars_held = trade['bars_held']
            minutes_open = bars_held * 15

            trade['highest_price'] = max(trade.get('highest_price', entry_p), high_p)
            trade['lowest_price'] = min(trade.get('lowest_price', entry_p), low_p)

            closed = False
            exit_price = entry_p
            exit_reason = ""

            if direction == "LONG":
                peak_gain_pct = ((trade['highest_price'] - entry_p) / entry_p) * 100.0

                for step in ladder_steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['highest_price'] * (1.0 - LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif early_inv_enabled and trade['ladder_level'] == 0 and minutes_open >= early_inv_mins:
                    raw_c = (close_p - entry_p) / entry_p
                    if raw_c <= -(early_inv_pct / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (close_p - entry_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            else: # SHORT
                peak_gain_pct = ((entry_p - trade['lowest_price']) / entry_p) * 100.0

                for step in ladder_steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['lowest_price'] * (1.0 + LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif early_inv_enabled and trade['ladder_level'] == 0 and minutes_open >= early_inv_mins:
                    raw_c = (entry_p - close_p) / entry_p
                    if raw_c <= -(early_inv_pct / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (entry_p - close_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = BINANCE_ROUNDTRIP_FEE_PCT * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                equity_curve.append((current_time_str, round(equity, 2)))
                completed_trades.append({
                    'symbol': sym,
                    'direction': direction,
                    'leverage': lev,
                    'margin': round(trade['margin'], 2),
                    'entry_price': entry_p,
                    'exit_price': round(exit_price, 6),
                    'entry_time': trade['entry_time_str'],
                    'exit_time': current_time_str,
                    'bars_held': bars_held,
                    'minutes_held': minutes_open,
                    'raw_gain_pct': round(raw_gain_pct, 2),
                    'net_margin_pct': round(net_margin, 2),
                    'dollar_gain': round(dollar_gain, 2),
                    'status': exit_reason,
                    'ladder_level': trade['ladder_level']
                })
                cooldown_until[sym] = ts + (POST_LOSS_COOLDOWN_MINUTES * 60 * 1000)

                if dollar_gain < 0:
                    side_consecutive_losses[direction] += 1
                    if side_guard_enabled and side_consecutive_losses[direction] >= SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES:
                        side_locked_until[direction] = ts + (SIDE_STOPLOSS_COOLDOWN_MINUTES * 60 * 1000)
                else:
                    side_consecutive_losses[direction] = 0

                daily_net_dollar += dollar_gain
                if dollar_gain < 0:
                    daily_loss_sum += abs(dollar_gain)
                    if daily_loss_sum >= DAILY_MAX_DRAWDOWN_USDT:
                        daily_circuit_breaker = True
                daily_peak_pnl = max(daily_peak_pnl, daily_net_dollar)
                if DAILY_TRAILING_PROFIT_LOCK_ENABLED and daily_peak_pnl >= 30.0:
                    floor = 15.0 if daily_peak_pnl < 50.0 else (35.0 if daily_peak_pnl < 75.0 else 55.0)
                    if daily_net_dollar <= floor:
                        daily_profit_locked = True
            else:
                still_active.append(trade)

        active_trades = still_active

        if len(active_trades) >= max_concurrent or daily_circuit_breaker or daily_profit_locked:
            continue

        bonus_slots = 0
        if daily_net_dollar > 0 and PROFIT_STEP_FOR_BONUS_TRADES > 0:
            bonus_slots = int(daily_net_dollar // PROFIT_STEP_FOR_BONUS_TRADES) * BONUS_TRADES_PER_STEP
        effective_max_trades = DAILY_BASE_MAX_TRADES + bonus_slots

        if daily_trades_count >= effective_max_trades:
            continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        for sym, setup in signals_by_ts.get(ts, []):
            if len(active_trades) >= max_concurrent or daily_trades_count >= effective_max_trades:
                break
            if sym in active_syms or ts < cooldown_until.get(sym, 0):
                continue

            direction = setup['direction']

            if side_guard_enabled and ts < side_locked_until.get(direction, 0):
                continue
            if direction == 'LONG' and long_count >= max_per_dir:
                continue
            if direction == 'SHORT' and short_count >= max_per_dir:
                continue

            sl_pct = setup['sl_pct']
            tp_pct = setup['tp1_pct']
            score = setup['confluence_score']

            is_sniper = (score >= 85 and sl_pct <= MAX_SL_PCT_20X)
            leverage = 20 if is_sniper else 10
            max_sl_allowed = MAX_SL_PCT_20X if leverage == 20 else MAX_SL_PCT_10X

            if sl_pct > max_sl_allowed or sl_pct <= 0:
                continue

            rr = tp_pct / sl_pct if sl_pct > 0 else 0
            if rr < MIN_RR_RATIO:
                continue

            allocated_margin = min(target_risk_usd / (sl_pct / 100.0 * leverage), 200.0)
            allocated_margin = max(allocated_margin, 50.0)

            active_trades.append({
                'symbol': sym,
                'direction': direction,
                'leverage': leverage,
                'risk_grade': setup['risk_grade'],
                'entry_time_ts': ts,
                'entry_time_str': current_time_str,
                'entry_price': setup['current_price'],
                'current_sl': setup['stop_loss'],
                'take_profit': setup['take_profit_1'],
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'margin': allocated_margin,
                'ladder_level': 0,
                'bars_held': 0,
                'highest_price': setup['current_price'],
                'lowest_price': setup['current_price']
            })
            daily_trades_count += 1
            if direction == 'LONG':
                long_count += 1
            else:
                short_count += 1

    # Raporlama Metrikleri
    wins = [t for t in completed_trades if t['dollar_gain'] > 0]
    losses = [t for t in completed_trades if t['dollar_gain'] < 0]
    bes = [t for t in completed_trades if t['dollar_gain'] == 0]
    total_trades = len(completed_trades)
    win_rate = len(wins) / total_trades * 100 if total_trades > 0 else 0
    net_pnl = sum(t['dollar_gain'] for t in completed_trades)
    total_won = sum(t['dollar_gain'] for t in wins)
    total_lost = abs(sum(t['dollar_gain'] for t in losses))
    profit_factor = total_won / total_lost if total_lost > 0 else 999.0
    
    long_trades = [t for t in completed_trades if t['direction'] == 'LONG']
    short_trades = [t for t in completed_trades if t['direction'] == 'SHORT']
    long_wins = [t for t in long_trades if t['dollar_gain'] > 0]
    short_wins = [t for t in short_trades if t['dollar_gain'] > 0]
    long_net = sum(t['dollar_gain'] for t in long_trades)
    short_net = sum(t['dollar_gain'] for t in short_trades)
    
    exits = Counter(t['status'] for t in completed_trades)

    # Max Drawdown
    peak = initial_equity
    max_dd = 0.0
    for _, eq in equity_curve:
        if eq > peak:
            peak = eq
        dd = (peak - eq)
        if dd > max_dd:
            max_dd = dd

    print(f"\n=======================================================")
    print(f"📊 SENARYO: {name}")
    print(f"=======================================================")
    print(f"💰 Başlangıç Bakiyesi: ${initial_equity:.2f} | Bitiş Bakiyesi: ${equity:.2f}")
    print(f"📈 Net Kâr / Zarar:   ${net_pnl:+.2f} ({net_pnl / initial_equity * 100:+.2f}%)")
    print(f"🎯 Toplam İşlem:       {total_trades} (Kazanılan: {len(wins)}, Kaybedilen: {len(losses)}, BE: {len(bes)})")
    print(f"🔥 Win Rate:           %{win_rate:.2f} | Profit Factor: {profit_factor:.2f}")
    print(f"📉 Maksimum Drawdown:  ${max_dd:.2f} (%{max_dd / initial_equity * 100:.2f})")
    print(f"🟢 LONG Performansı:   {len(long_trades)} işlem | %{len(long_wins)/len(long_trades)*100 if long_trades else 0:.1f} Win | Net: ${long_net:+.2f}")
    print(f"🔴 SHORT Performansı:  {len(short_trades)} işlem | %{len(short_wins)/len(short_trades)*100 if short_trades else 0:.1f} Win | Net: ${short_net:+.2f}")
    print(f"🚪 Çıkış Dağılımı:")
    for k, v in sorted(exits.items(), key=lambda x: -x[1]):
        print(f"   • {k:<25}: {v} adet")
    print(f"=======================================================\n")

    return {
        'name': name,
        'equity': equity,
        'net_pnl': net_pnl,
        'win_rate': win_rate,
        'profit_factor': profit_factor,
        'total_trades': total_trades,
        'wins': len(wins),
        'losses': len(losses),
        'max_dd': max_dd,
        'long_trades': len(long_trades),
        'long_win_rate': len(long_wins)/len(long_trades)*100 if long_trades else 0,
        'long_net': long_net,
        'short_trades': len(short_trades),
        'short_win_rate': len(short_wins)/len(short_trades)*100 if short_trades else 0,
        'short_net': short_net,
        'exits': dict(exits),
        'trades': completed_trades,
        'daily_history': daily_history,
        'equity_curve': equity_curve
    }

# 3 Kritik Senaryoyu Karşılaştır
print("\n--- SİMÜLASYON TESTLERİ BAŞLIYOR ---\n", flush=True)

# 1. Tam Mevcut Bot (20 dk / %-0.35 Erken İptal + Freqtrade Guard + Merdiven BE+)
res_current = run_backtest(
    name="1. Tam Mevcut Bot (20m Erken Kes + Freqtrade Guard + BE+ Merdiven)",
    early_inv_enabled=True,
    early_inv_mins=20,
    early_inv_pct=0.35,
    side_guard_enabled=True
)

# 2. Kalibre Edilmiş Nefes Alan Erken İptal (45 dk / %-0.65 Erken Kes)
res_tuned = run_backtest(
    name="2. Kalibre Edilmiş Erken İptal (45m / -%0.65 + Freqtrade Guard + BE+ Merdiven)",
    early_inv_enabled=True,
    early_inv_mins=45,
    early_inv_pct=0.65,
    side_guard_enabled=True
)

# 3. Korumasız Eski Bot (Freqtrade Side Guard YOK, Eski Gevşek Merdiven)
old_ladder = [
    {"step": 1, "trigger_raw_pct": 0.60, "lock_raw_pct": 0.15, "name": "Eski Basamak 1"},
    {"step": 2, "trigger_raw_pct": 1.00, "lock_raw_pct": 0.50, "name": "Eski Basamak 2"}
]
res_old = run_backtest(
    name="3. Eski Bot (Freqtrade Kalkanı YOK, Eski Geç Kilit)",
    early_inv_enabled=False,
    side_guard_enabled=False,
    ladder_steps=old_ladder
)

# Sonuçları JSON olarak kaydet
out_file = Path(project_root) / "data" / "simulations" / "sim_current_bot_30d_results.json"
out_file.parent.mkdir(parents=True, exist_ok=True)
with open(out_file, "w", encoding="utf-8") as f:
    json.dump({
        'res_current': {k: v for k, v in res_current.items() if k not in ['trades', 'equity_curve']},
        'res_tuned': {k: v for k, v in res_tuned.items() if k not in ['trades', 'equity_curve']},
        'res_old': {k: v for k, v in res_old.items() if k not in ['trades', 'equity_curve']},
        'tuned_trades_sample': res_tuned['trades']
    }, f, indent=2, ensure_ascii=False)

print(f"✓ Simülasyon sonuçları başarıyla kaydedildi: {out_file}", flush=True)

