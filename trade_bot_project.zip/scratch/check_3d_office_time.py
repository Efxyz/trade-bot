with open("dashboard.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i in range(5000, 5200):
    l = lines[i]
    if "time" in l.lower() or "clock" in l.lower() or "saat" in l.lower() or "date" in l.lower():
        print(f"L{i+1}: {l.strip()[:100]}")
