"""
Create a clean, secure .zip archive of the trade_bot project for sharing.
Excludes sensitive keys (.env), databases (*.db), caches, and temporary files.
Includes clean .env.example with instructions.
"""
import os
import zipfile
from pathlib import Path

root_dir = Path(".").resolve()
zip_name = "trade_bot_project.zip"
zip_path = root_dir / zip_name

# Exclusion lists
EXCLUDE_DIRS = {
    "__pycache__", ".git", ".venv", "venv", "env",
    ".pytest_cache", ".mypy_cache", "scratch", ".gemini"
}
EXCLUDE_EXTS = {".pyc", ".pyo", ".pyd", ".db", ".sqlite", ".log", ".zip"}
EXCLUDE_FILES = {".env", zip_name}

added_files = []

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Prune excluded directories in-place
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if fname in EXCLUDE_FILES or ext in EXCLUDE_EXTS:
                continue
            
            # Security safety check: never add any .env variant except .env.example
            if fname.startswith(".env") and fname != ".env.example":
                continue
            
            full_path = Path(dirpath) / fname
            rel_path = full_path.relative_to(root_dir)
            
            # Safety check: exclude if inside any excluded directory
            if any(part in EXCLUDE_DIRS for part in rel_path.parts):
                continue
                
            zf.write(full_path, rel_path)
            added_files.append(str(rel_path))

size_kb = os.path.getsize(zip_path) / 1024
print(f"Zip successfully created: {zip_path}")
print(f"Total files packed: {len(added_files)}")
print(f"Archive size: {size_kb:.2f} KB ({size_kb/1024:.2f} MB)")

# Audit check
with zipfile.ZipFile(zip_path, "r") as zf:
    namelist = zf.namelist()
    has_env = any(".env" in name and name != ".env.example" for name in namelist)
    has_db = any(name.endswith(".db") for name in namelist)
    has_example = ".env.example" in namelist
    
    print("\n--- SECURITY AUDIT ---")
    print(f"Contains live .env: {has_env} (Expected: False)")
    print(f"Contains database (.db): {has_db} (Expected: False)")
    print(f"Contains .env.example: {has_example} (Expected: True)")
    
    assert not has_env, "CRITICAL: Live .env found in archive!"
    assert not has_db, "CRITICAL: Live database found in archive!"
    assert has_example, "Missing .env.example template!"
    print("ALL SECURITY CHECKS PASSED: SAFE TO SHARE WITH FRIEND!")
