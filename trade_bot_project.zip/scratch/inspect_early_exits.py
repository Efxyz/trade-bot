import json
import os

with open(r'data\simulations\sim_current_bot_30d_results.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

trades = data.get('trades', [])
early_exits = [t for t in trades if t['status'] == 'EARLY_INVALIDATION_EXIT']

print(f"Total early invalidation exits: {len(early_exits)}")
for t in early_exits[:8]:
    print(f"{t['symbol']} {t['direction']} entry: {t['entry_price']} exit: {t['exit_price']} held: {t['bars_held']} bars ({t['bars_held']*15} min) raw: {t['raw_pnl_pct']}% dollar: ${t['dollar_gain']}")

