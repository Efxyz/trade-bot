import json
import os
import sys
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
sys.path.insert(0, r"C:\Users\isiks\.gemini\antigravity\brain\a2f493b1-6bd2-4f3b-a3f9-f21e7725bbd5\scratch")
os.chdir(str(project_root))

from collections import Counter
from datetime import datetime, timezone
from typing import List, Dict, Tuple

from config import (
    LADDER_STEPS,
    LADDER_DYNAMIC_CHANNEL_PCT,
    MIN_CONFLUENCE_SCORE,
    MIN_CONFLUENCE_SCORE_SHORT,
    LEVERAGE_STANDARD,
    LEVERAGE_HIGH,
    BINANCE_ROUNDTRIP_FEE_PCT,
    MAX_HOLD_MINUTES,
    MAX_SCALP_SL_PCT,
    MIN_SCALP_SL_PCT,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_RR_RATIO,
    DAILY_BASE_MAX_TRADES,
    PROFIT_STEP_FOR_BONUS_TRADES,
    BONUS_TRADES_PER_STEP,
    DAILY_MAX_DRAWDOWN_USDT,
    DAILY_TRAILING_PROFIT_LOCK_ENABLED,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    EXCLUDED_SYMBOLS_BLACKLIST,
    SMC_PREMIUM_DISCOUNT_FILTER,
    MAX_VWAP_DISTANCE_PCT
)
from agents.ta_agent import TechnicalAnalysisAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

coin_data = {}
all_timestamps = set()
for sym, c in raw_cache.items():
    if sym in EXCLUDED_SYMBOLS_BLACKLIST:
        continue
    coin_data[sym] = {'_list': c, 'by_ts': {x['timestamp']: x for x in c}}
    all_timestamps.update(x['timestamp'] for x in c)

sorted_ts = sorted(list(all_timestamps))
btc_candles = coin_data.get("BTCUSDT", {}).get('_list', [])
btc_ts_to_idx = {c['timestamp']: idx for idx, c in enumerate(btc_candles)}
coin_indices = {sym: {c['timestamp']: i for i, c in enumerate(d['_list'])} for sym, d in coin_data.items()}

ta_agent = TechnicalAnalysisAgent()

def run_test(early_inv_mins=40, early_inv_pct=0.65):
    initial_equity = 1000.0
    equity = initial_equity
    max_concurrent = 5
    max_per_dir = 3
    target_risk_usd = 20.0

    active_trades = []
    completed_trades = []
    cooldown_until = {}
    side_consecutive_losses = {"LONG": 0, "SHORT": 0}
    side_locked_until = {"LONG": 0, "SHORT": 0}

    current_day_str = None
    daily_trades_count = 0
    daily_net_dollar = 0.0
    daily_loss_sum = 0.0
    daily_circuit_breaker = False
    daily_profit_locked = False
    daily_peak_pnl = 0.0

    for ts in sorted_ts:
        dt = datetime.fromtimestamp(ts / 1000, tz=timezone.utc)
        day_str = dt.strftime("%Y-%m-%d")
        current_time_str = dt.strftime("%Y-%m-%d %H:%M")

        if current_day_str != day_str:
            current_day_str = day_str
            daily_trades_count = 0
            daily_net_dollar = 0.0
            daily_loss_sum = 0.0
            daily_circuit_breaker = False
            daily_profit_locked = False
            daily_peak_pnl = 0.0

        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            c_info = coin_data.get(sym, {}).get('by_ts', {}).get(ts)
            if not c_info:
                still_active.append(trade)
                continue

            high_p = c_info['high']
            low_p = c_info['low']
            close_p = c_info['close']

            direction = trade['direction']
            entry_p = trade['entry_price']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            lev = trade['leverage']

            trade['bars_held'] += 1
            bars_held = trade['bars_held']
            minutes_open = bars_held * 15

            trade['highest_price'] = max(trade.get('highest_price', entry_p), high_p)
            trade['lowest_price'] = min(trade.get('lowest_price', entry_p), low_p)

            closed = False
            exit_price = entry_p
            exit_reason = ""

            if direction == "LONG":
                peak_gain_pct = ((trade['highest_price'] - entry_p) / entry_p) * 100.0

                for step in LADDER_STEPS:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['highest_price'] * (1.0 - LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif trade['ladder_level'] == 0 and minutes_open >= early_inv_mins:
                    raw_c = (close_p - entry_p) / entry_p
                    if raw_c <= -(early_inv_pct / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (close_p - entry_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            else: # SHORT
                peak_gain_pct = ((entry_p - trade['lowest_price']) / entry_p) * 100.0

                for step in LADDER_STEPS:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['lowest_price'] * (1.0 + LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif trade['ladder_level'] == 0 and minutes_open >= early_inv_mins:
                    raw_c = (entry_p - close_p) / entry_p
                    if raw_c <= -(early_inv_pct / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (entry_p - close_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = BINANCE_ROUNDTRIP_FEE_PCT * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                completed_trades.append({
                    'symbol': sym,
                    'direction': direction,
                    'dollar_gain': round(dollar_gain, 2),
                    'status': exit_reason
                })
                cooldown_until[sym] = ts + (45 * 60 * 1000)

                if dollar_gain < 0:
                    side_consecutive_losses[direction] += 1
                    if SIDE_STOPLOSS_GUARD_ENABLED and side_consecutive_losses[direction] >= SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES:
                        side_locked_until[direction] = ts + (SIDE_STOPLOSS_COOLDOWN_MINUTES * 60 * 1000)
                else:
                    side_consecutive_losses[direction] = 0

                daily_net_dollar += dollar_gain
                if dollar_gain < 0:
                    daily_loss_sum += abs(dollar_gain)
                    if daily_loss_sum >= DAILY_MAX_DRAWDOWN_USDT:
                        daily_circuit_breaker = True
                daily_peak_pnl = max(daily_peak_pnl, daily_net_dollar)
                if DAILY_TRAILING_PROFIT_LOCK_ENABLED and daily_peak_pnl >= 30.0:
                    floor = 15.0 if daily_peak_pnl < 50.0 else (35.0 if daily_peak_pnl < 75.0 else 55.0)
                    if daily_net_dollar <= floor:
                        daily_profit_locked = True
            else:
                still_active.append(trade)

        active_trades = still_active

        if len(active_trades) >= max_concurrent or daily_circuit_breaker or daily_profit_locked:
            continue

        bonus_slots = 0
        if daily_net_dollar > 0 and PROFIT_STEP_FOR_BONUS_TRADES > 0:
            bonus_slots = int(daily_net_dollar // PROFIT_STEP_FOR_BONUS_TRADES) * BONUS_TRADES_PER_STEP
        effective_max_trades = DAILY_BASE_MAX_TRADES + bonus_slots

        if daily_trades_count >= effective_max_trades:
            continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        from run_current_bot_30d_simulation import build_1h_candles_from_15m

        for sym in coin_data.keys():
            if len(active_trades) >= max_concurrent or daily_trades_count >= effective_max_trades:
                break
            if sym in active_syms or ts < cooldown_until.get(sym, 0):
                continue

            c_idx = coin_indices.get(sym, {}).get(ts)
            if c_idx is None or c_idx < 40:
                continue

            candles_sub = coin_data[sym]['_list'][:c_idx+1]
            win_15m = candles_sub[-60:] if len(candles_sub) >= 60 else candles_sub
            c_1h_all = build_1h_candles_from_15m(candles_sub)
            win_1h = c_1h_all[-35:] if len(c_1h_all) >= 20 else None

            setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
            if not setup:
                continue

            direction = setup['direction']

            if SIDE_STOPLOSS_GUARD_ENABLED and ts < side_locked_until.get(direction, 0):
                continue
            if direction == 'LONG' and long_count >= max_per_dir:
                continue
            if direction == 'SHORT' and short_count >= max_per_dir:
                continue

            sl_pct = setup['sl_pct']
            tp_pct = setup['tp1_pct']
            score = setup['confluence_score']

            is_sniper = (score >= 85 and sl_pct <= MAX_SL_PCT_20X)
            leverage = 20 if is_sniper else 10
            max_sl_allowed = MAX_SL_PCT_20X if leverage == 20 else MAX_SL_PCT_10X

            if sl_pct > max_sl_allowed or sl_pct <= 0:
                continue

            rr = tp_pct / sl_pct if sl_pct > 0 else 0
            if rr < MIN_RR_RATIO:
                continue

            allocated_margin = min(target_risk_usd / (sl_pct / 100.0 * leverage), 200.0)
            allocated_margin = max(allocated_margin, 50.0)

            active_trades.append({
                'symbol': sym,
                'direction': direction,
                'leverage': leverage,
                'risk_grade': setup['risk_grade'],
                'entry_time_ts': ts,
                'entry_time_str': current_time_str,
                'entry_price': setup['current_price'],
                'current_sl': setup['stop_loss'],
                'take_profit': setup['take_profit_1'],
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'margin': allocated_margin,
                'ladder_level': 0,
                'bars_held': 0,
                'highest_price': setup['current_price'],
                'lowest_price': setup['current_price']
            })
            daily_trades_count += 1
            if direction == 'LONG':
                long_count += 1
            else:
                short_count += 1

    wins = [t for t in completed_trades if t['dollar_gain'] > 0]
    losses = [t for t in completed_trades if t['dollar_gain'] < 0]
    bes = [t for t in completed_trades if t['dollar_gain'] == 0]
    total = len(completed_trades)
    win_rate = len(wins) / total * 100 if total > 0 else 0
    net_pnl = sum(t['dollar_gain'] for t in completed_trades)
    exits = Counter(t['status'] for t in completed_trades)

    print(f"\n--- PARAMS: early_inv_mins={early_inv_mins}, early_inv_pct={early_inv_pct}% ---")
    print(f"Final Equity: ${equity:.2f} | Net: ${net_pnl:+.2f} ({net_pnl/1000*100:+.2f}%)")
    print(f"Trades: {total} (Wins: {len(wins)}, Losses: {len(losses)}, BE: {len(bes)}) | WinRate: {win_rate:.1f}%")
    print(f"Exits: {dict(exits)}")

for m in [35, 45, 60]:
    for p in [0.55, 0.70]:
        run_test(early_inv_mins=m, early_inv_pct=p)

