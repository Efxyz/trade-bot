import os
import shutil

root = os.getcwd()

# 1. Delete 0-byte ghost database files in root
ghost_dbs = ["trades.db", "trading_bot.db"]
for g in ghost_dbs:
    p = os.path.join(root, g)
    if os.path.exists(p) and os.path.getsize(p) == 0:
        os.remove(p)
        print(f"✅ Deleted 0-byte ghost file: {g}")
    elif os.path.exists(p):
        print(f"⚠️ Warning: {g} is not 0 bytes ({os.path.getsize(p)} bytes), skipping deletion.")

# 2. Create data/simulations/ and move simulation JSONs
sim_dir = os.path.join(root, "data", "simulations")
os.makedirs(sim_dir, exist_ok=True)
print(f"📁 Created or verified folder: {sim_dir}")

sim_files = [
    "bu_haliyle_30d_sim_results.json",
    "sim_1month_results.json",
    "sim_90d_results.json",
    "sim_realistic_1month.json",
    "sim_updated_month_report.json"
]

for sf in sim_files:
    src = os.path.join(root, sf)
    dst = os.path.join(sim_dir, sf)
    if os.path.exists(src):
        shutil.move(src, dst)
        print(f"📦 Moved {sf} -> data/simulations/{sf}")

# 3. Move one-off scripts to scratch/
scratch_dir = os.path.join(root, "scratch")
os.makedirs(scratch_dir, exist_ok=True)

scripts_to_move = [
    "calculate_concrete_metrics.py",
    "check_history_details.py"
]

for sm in scripts_to_move:
    src = os.path.join(root, sm)
    dst = os.path.join(scratch_dir, sm)
    if os.path.exists(src):
        shutil.move(src, dst)
        print(f"📦 Moved {sm} -> scratch/{sm}")

# 4. Move office_3d_engine.js to data/tools/
tools_dir = os.path.join(root, "data", "tools")
os.makedirs(tools_dir, exist_ok=True)

js_file = "office_3d_engine.js"
src_js = os.path.join(root, js_file)
dst_js = os.path.join(tools_dir, js_file)
if os.path.exists(src_js):
    shutil.move(src_js, dst_js)
    print(f"📦 Moved {js_file} -> data/tools/{js_file}")

print("\nReorganization script completed successfully!")

