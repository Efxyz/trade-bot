import re

with open("dashboard.py", "r", encoding="utf-8") as f:
    content = f.read()

# Let's search for datetime occurrences in python part
print("--- Python Datetime Usages in dashboard.py ---")
for i, line in enumerate(content.splitlines()):
    if "datetime" in line or "created_at" in line or "time" in line.lower():
        if i > 5500 or i < 100:  # Python code parts (before or after HTML_OFFICE_TEMPLATE)
            print(f"L{i+1}: {line.strip()[:100]}")

# Let's search inside the HTML/JS template for date/time formatting functions or patterns
print("\n--- JavaScript Time / Date Patterns in HTML_OFFICE_TEMPLATE ---")
matches = re.findall(r"(.{0,40}(?:toLocaleTimeString|toLocaleDateString|formatDate|formatTime|slice\(11|toISOString|getTime|getHours|created_at|timestamp|saat|date).{0,40})", content, re.IGNORECASE)
print(f"Found {len(matches)} matches in template. Showing first 30:")
for m in matches[:30]:
    clean = m.strip().replace("\n", " ")
    print(f"  {clean}")
