import urllib.request
import json
import time

time.sleep(3)
url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        d = json.loads(resp.read().decode())
        logs = d.get("scanner_logs", [])[:10]
        active = d.get("active_signals", [])
        trades = d.get("trades", [])
        print(f"Active Signals: {len(active)}")
        for a in active:
            print("  Active:", a.get("symbol"), a.get("direction"), a.get("entry_price"))
        print("\nRecent 10 Scanner Logs:")
        for l in logs:
            t = l.get("time")
            s = l.get("symbol")
            st = l.get("status")
            r = l.get("reason", "")
            print(f"[{t}] {s} | {st} | {r}")
except Exception as e:
    print("Error:", e)
