import sys
from pathlib import Path
sys.path.insert(0, r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.risk_agent import RiskOfficerAgent
from agents.quant_simulation_agent import QuantSimulationAgent
from agents.ai_analyst_agent import AIAnalystAgent

client = BinanceFuturesClient()
ta_agent = TechnicalAnalysisAgent()
risk_agent = RiskOfficerAgent()
quant_agent = QuantSimulationAgent(win_threshold_pct=48.0)
ai_agent = AIAnalystAgent()

symbol = "ETHUSDT"
btc_regime = client.get_btc_regime()
ticker = client.get_24hr_tickers().get(symbol, {})
funding_data = client.get_funding_rate(symbol)
book_ticker = client.get_book_ticker(symbol)

c15m = client.get_klines(symbol, interval="15m", limit=80)
c1h = client.get_klines(symbol, interval="1h", limit=50)

print("1. TA Analizi...")
setup, reason = ta_agent.analyze_setup(symbol, c15m, c1h)
print(f"   TA Onay: {bool(setup)} | Yön: {setup.get('direction')} | Skor: {setup.get('confluence_score')}/100")
print(f"   Giriş: {setup.get('actual_entry_price')} | SL: {setup.get('stop_loss')} (-%{setup.get('sl_pct')}) | TP: {setup.get('take_profit_1')} (+%{setup.get('tp1_pct')})")
print(f"   Gerekçeler: {setup.get('ta_reasons')}")

print("\n2. Risk Masası Analizi...")
is_approved, risk_report = risk_agent.evaluate(
    setup, {}, ticker, btc_regime,
    funding_data=funding_data,
    book_ticker=book_ticker,
    active_signals=[],
    current_equity=1057.24
)
print(f"   Risk Onayı: {is_approved} ({risk_report.get('reason', 'OK')})")

print("\n3. Kuant Monte Carlo Simülasyonu (10,000 Fiyat Yolu)...")
sim = quant_agent.simulate_setup(symbol, setup, c15m, num_simulations=10000)
print(f"   Win Prob: %{sim.get('win_probability_pct')} | Expected R: {sim.get('expected_return_r')}R | Approved: {sim.get('is_approved')}")

print("\n4. AI Yatırım Komitesi Tartışması...")
ai_verdict = ai_agent.evaluate_setup(
    setup, risk_report, {}, btc_regime, ticker, funding_data, quant_sim=sim
)
print(f"   AI Onayı: {ai_verdict.get('ai_approved')} | Güven Skoru: {ai_verdict.get('ai_confidence')}/10")
print(f"   Karar: {ai_verdict.get('summary')}")

print("\n🎉 YENİ GELİŞMİŞ TA VE TÜM BORU HATTI (PIPELINE) %100 BAŞARILI!")
