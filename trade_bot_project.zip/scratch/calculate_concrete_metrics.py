import urllib.request
import json
import math
from collections import defaultdict

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Antigravity"})

with urllib.request.urlopen(req, timeout=12) as resp:
    data = json.loads(resp.read().decode("utf-8"))

trades = data.get("trade_history", [])
stats = data.get("stats", {})

print("=== 1. Live Production Statistics (Railway) ===")
for k, v in stats.items():
    print(f"  {k}: {v}")

print(f"\nTotal trades in history: {len(trades)}")

# Let's inspect individual trades
pnls = []
dollar_pnls = []
outcomes = defaultdict(int)

current_streak = 0
max_win_streak = 0
max_loss_streak = 0
prev_was_win = None

running_equity = 1000.0
peak_equity = 1000.0
drawdowns = []

for t in trades:
    pnl = float(t.get("pnl_pct") or 0.0)
    status = t.get("status", "UNKNOWN")
    outcomes[status] += 1
    pnls.append(pnl)
    
    # Calculate dollar pnl based on allocated margin or risk
    # On 10x with $20 risk, a 16% ROE is +$32, -10% is -$20
    dollar_pnl = t.get("realized_pnl_usd")
    if dollar_pnl is None:
        # Estimate: average win is +$8.52, average loss is -$11.90 from live stats
        dollar_pnl = 8.52 if pnl > 0 else -11.90
    dollar_pnls.append(dollar_pnl)
    
    running_equity += dollar_pnl
    if running_equity > peak_equity:
        peak_equity = running_equity
    dd = (peak_equity - running_equity) / peak_equity * 100.0
    drawdowns.append(dd)
    
    is_win = pnl > 0
    if prev_was_win is None:
        current_streak = 1
    elif is_win == prev_was_win:
        current_streak += 1
    else:
        current_streak = 1
    prev_was_win = is_win
    
    if is_win:
        max_win_streak = max(max_win_streak, current_streak)
    else:
        max_loss_streak = max(max_loss_streak, current_streak)

print("\n=== 2. Forensic Breakdown of Out-Comes ===")
for st, cnt in outcomes.items():
    print(f"  {st:<22}: {cnt} ({cnt/len(trades)*100:.1f}%)")

print("\n=== 3. Streak & Drawdown Metrics ===")
print(f"  Max Consecutive Wins   : {max_win_streak}")
print(f"  Max Consecutive Losses : {max_loss_streak}")
print(f"  Max Drawdown Observed  : %{max(drawdowns):.2f}")

# Expectancy Calculation
p_win = stats.get("win_rate", 73.91) / 100.0
p_loss = 1.0 - p_win
avg_win = stats.get("sum_wins", 144.89) / stats.get("win_count", 17)
avg_loss = stats.get("sum_losses", 71.44) / stats.get("loss_count", 6)
expectancy = (p_win * avg_win) - (p_loss * avg_loss)
print(f"\n=== 4. Mathematical Expectancy (E) ===")
print(f"  P(Win)                 : %{p_win*100:.2f}")
print(f"  P(Loss)                : %{p_loss*100:.2f}")
print(f"  Average Win ($)        : +${avg_win:.2f}")
print(f"  Average Loss ($)       : -${avg_loss:.2f}")
print(f"  Mathematical Expectancy: +${expectancy:.2f} per trade")
print(f"  (Her açılan işlemde matematiksel olarak ortalama +${expectancy:.2f} kâr üretiliyor!)")

