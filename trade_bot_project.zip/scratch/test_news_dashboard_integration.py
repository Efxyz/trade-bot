"""
Test news council dashboard integration locally:
- Tests Flask test client for /api/data, /api/news/coin-investigations, and /api/news/investigate
- Verifies that coin-specific news investigations appear in data payload
- Verifies that Kara Kuğu (KAVA hack) is properly analyzed and saved
- Verifies that dashboard HTML contains the new interactive Council UI
"""
import sys, os
sys.path.insert(0, os.path.abspath("."))
import json
from dashboard import app

client = app.test_client()

print("1. Testing GET /api/data ...")
res = client.get("/api/data")
assert res.status_code == 200, f"Expected 200, got {res.status_code}"
data = res.get_json()
assert "coin_news_investigations" in data, "coin_news_investigations key missing in /api/data"
assert "news_feed" in data, "news_feed key missing in /api/data"
print(f"   [OK] /api/data contains {len(data['coin_news_investigations'])} coin investigations and {len(data['news_feed'])} RSS news items.")

print("2. Testing GET /api/news/coin-investigations ...")
res_inv = client.get("/api/news/coin-investigations")
assert res_inv.status_code == 200
inv_list = res_inv.get_json()
print(f"   [OK] /api/news/coin-investigations returned {len(inv_list)} items.")

print("3. Testing POST /api/news/investigate with ETH LONG ...")
res_eth = client.post("/api/news/investigate", json={"symbol": "ETH", "direction": "LONG"})
assert res_eth.status_code == 200
eth_data = res_eth.get_json()
assert eth_data["success"] is True
eth_inv = eth_data["data"]
print(f"   [OK] ETH Investigation: Symbol={eth_inv['symbol']}, Verdict={eth_inv['verdict']}, Multiplier={eth_inv['pos_multiplier']}x, Score={eth_inv['news_score']}/100")
print(f"        Debate lines: {len(eth_inv['council_debate'])}")

print("4. Testing POST /api/news/investigate with KAVA LONG (Expecting Hack/Black Swan Veto) ...")
res_kava = client.post("/api/news/investigate", json={"symbol": "KAVA", "direction": "LONG"})
assert res_kava.status_code == 200
kava_data = res_kava.get_json()
assert kava_data["success"] is True
kava_inv = kava_data["data"]
print(f"   [OK] KAVA Investigation: Symbol={kava_inv['symbol']}, Verdict={kava_inv['verdict']}, Multiplier={kava_inv['pos_multiplier']}x, Is Vetoed={kava_inv['is_vetoed']}")
assert kava_inv["is_vetoed"] is True, "Expected KAVA to be vetoed due to hack news"
assert kava_inv["pos_multiplier"] == 0.0, "Expected 0.0x multiplier on veto"
print(f"        Veto Reason: {kava_inv['veto_reason']}")

print("5. Verifying updated /api/data after investigations ...")
res_updated = client.get("/api/data")
data_updated = res_updated.get_json()
symbols_in_cache = [c["symbol"] for c in data_updated["coin_news_investigations"]]
print(f"   [OK] Symbols currently in cache: {symbols_in_cache[:5]}")
assert "ETHUSDT" in symbols_in_cache or "ETH" in symbols_in_cache
assert "KAVAUSDT" in symbols_in_cache or "KAVA" in symbols_in_cache

print("6. Verifying Dashboard HTML contains new UI elements ...")
res_html = client.get("/")
assert res_html.status_code == 200
html_text = res_html.get_data(as_text=True)
assert "newsContainer" in html_text, "Missing #newsContainer in HTML"
assert "councilReportList" in html_text, "Missing #councilReportList in HTML"
assert "btnSubCouncil" in html_text, "Missing #btnSubCouncil in HTML"
assert "btnSubRss" in html_text, "Missing #btnSubRss in HTML"
assert "coinNewsInput" in html_text, "Missing #coinNewsInput in HTML"
assert "triggerManualNewsInvestigation" in html_text, "Missing triggerManualNewsInvestigation in HTML"
print("   [OK] All UI elements, sub-tabs, search box and event handlers present in HTML!")

print("\n>>> ALL TESTS PASSED SUCCESSFULLY! <<<")
