import urllib.request
import json
import time

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})

try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        print(f"WS Connected: {data.get('ws_connected')}")
        print(f"BTC Regime: {data.get('btc_regime')}")
        scanner_logs = data.get("scanner_logs", [])
        print(f"Scanner Logs Count: {len(scanner_logs)}")
        if scanner_logs:
            print("Latest 3 Scanner Logs:")
            for log in scanner_logs[:3]:
                print(f"  [{log.get('symbol')}] {log.get('status')}: {log.get('reason')} - {log.get('details')}")
except Exception as e:
    print(f"Error: {e}")
