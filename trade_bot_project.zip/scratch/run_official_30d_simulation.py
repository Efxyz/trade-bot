import json
import os
import sys
import time
from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
os.chdir(str(project_root))

from config import (
    BINANCE_ROUNDTRIP_FEE_PCT,
    BONUS_TRADES_PER_STEP,
    DAILY_BASE_MAX_TRADES,
    DAILY_MAX_DRAWDOWN_USDT,
    DAILY_TRAILING_PROFIT_LOCK_ENABLED,
    EXCLUDED_SYMBOLS_BLACKLIST,
    LADDER_DYNAMIC_CHANNEL_PCT,
    LADDER_STEPS,
    LEVERAGE_HIGH,
    LEVERAGE_STANDARD,
    MAX_CONCURRENT_TRADES,
    MAX_HOLD_MINUTES,
    MAX_POSITIONS_PER_DIRECTION,
    MAX_SCALP_SL_PCT,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_CONFLUENCE_SCORE,
    MIN_RR_RATIO,
    PORTFOLIO_EQUITY_USDT,
    POST_LOSS_COOLDOWN_MINUTES,
    PROFIT_STEP_FOR_BONUS_TRADES,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
)
from agents.ta_agent import TechnicalAnalysisAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

from benchmark_precompute import build_full_1h_candles

print("=" * 75)
print("🏛️ RESMİ 30 GÜNLÜK GEÇMİŞ PİYASA SİMÜLASYONU (GÜNCEL BOT vs ESKİ BOT)")
print("=" * 75)
print("1. 30 Günlük 15m Binance Mumları Yükleniyor...")

coin_data = {}
all_ts = set()
for sym, c_list in raw_cache.items():
    c_1h = build_full_1h_candles(c_list)
    h_close_ts = [c['timestamp'] + 3600*1000 for c in c_1h]
    coin_data[sym] = {
        'list_15m': c_list,
        'by_ts': {x['timestamp']: x for x in c_list},
        'idx_by_ts': {x['timestamp']: i for i, x in enumerate(c_list)},
        'list_1h': c_1h,
        'h_close_ts': h_close_ts
    }
    all_ts.update(x['timestamp'] for x in c_list)

sorted_ts = sorted(list(all_ts))
print(f"✓ {len(coin_data)} parite ve {len(sorted_ts)} periyot (30 tam gün) hazırlandı.")

# BTC Çöküş Kalkanı
btc_candles = coin_data.get("BTCUSDT", {}).get('list_15m', [])
def check_btc_shield(ts):
    c_info = coin_data.get("BTCUSDT", {}).get('by_ts', {}).get(ts)
    if not c_info:
        return True
    idx = coin_data["BTCUSDT"]['idx_by_ts'].get(ts)
    if idx is None or idx < 20:
        return True
    c_sub = btc_candles[:idx+1]
    curr_p = c_sub[-1]['close']
    p_3h_ago = c_sub[-12]['close'] if len(c_sub) >= 12 else c_sub[0]['close']
    drop_pct = ((curr_p - p_3h_ago) / p_3h_ago) * 100.0
    return drop_pct > -2.5

print("2. Kurumsal TA Confluence Sinyalleri Taranıyor...")
ta_agent = TechnicalAnalysisAgent()
signals_by_ts = {ts: [] for ts in sorted_ts}

for sym, d in coin_data.items():
    c15 = d['list_15m']
    c1h = d['list_1h']
    h_close_ts = d['h_close_ts']
    for idx, c in enumerate(c15):
        if idx < 45:
            continue
        ts = c['timestamp']
        win_15m = c15[max(0, idx-59) : idx+1]
        h_end_idx = bisect_right(h_close_ts, ts)
        win_1h = c1h[max(0, h_end_idx-35) : h_end_idx] if h_end_idx >= 15 else None
        
        setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
        if setup:
            signals_by_ts[ts].append((sym, setup))

print("✓ Sinyal haritası başarıyla çıkarıldı.")

def run_simulation(
    name: str,
    use_blacklist: bool,
    use_side_guard: bool,
    ladder_steps: list,
    use_early_inval: bool,
    early_mins: int = 45,
    early_loss_pct: float = 0.65
):
    initial_equity = 1000.0
    equity = initial_equity
    max_concurrent = 5
    max_per_dir = 3
    target_risk_usd = 20.0

    active_trades = []
    completed_trades = []
    cooldown_until = {}
    side_consecutive_losses = {"LONG": 0, "SHORT": 0}
    side_locked_until = {"LONG": 0, "SHORT": 0}

    current_day_str = None
    daily_trades_count = 0
    daily_net_dollar = 0.0
    daily_loss_sum = 0.0
    daily_circuit_breaker = False
    daily_profit_locked = False
    daily_peak_pnl = 0.0
    daily_history = []
    equity_curve = []

    for ts in sorted_ts:
        dt = datetime.fromtimestamp(ts / 1000, tz=timezone.utc)
        day_str = dt.strftime("%Y-%m-%d")
        current_time_str = dt.strftime("%Y-%m-%d %H:%M")

        if current_day_str != day_str:
            if current_day_str is not None:
                daily_history.append({
                    'day': current_day_str,
                    'trades': daily_trades_count,
                    'net_pnl': round(daily_net_dollar, 2),
                    'equity': round(equity, 2),
                    'breaker': daily_circuit_breaker,
                    'profit_locked': daily_profit_locked
                })
            current_day_str = day_str
            daily_trades_count = 0
            daily_net_dollar = 0.0
            daily_loss_sum = 0.0
            daily_circuit_breaker = False
            daily_profit_locked = False
            daily_peak_pnl = 0.0

        # Pozisyon Takibi
        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            c_info = coin_data.get(sym, {}).get('by_ts', {}).get(ts)
            if not c_info:
                still_active.append(trade)
                continue

            high_p = c_info['high']
            low_p = c_info['low']
            close_p = c_info['close']

            direction = trade['direction']
            entry_p = trade['entry_price']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            lev = trade['leverage']

            trade['bars_held'] += 1
            bars_held = trade['bars_held']
            minutes_open = bars_held * 15

            trade['highest_price'] = max(trade.get('highest_price', entry_p), high_p)
            trade['lowest_price'] = min(trade.get('lowest_price', entry_p), low_p)

            closed = False
            exit_price = entry_p
            exit_reason = ""

            if direction == "LONG":
                peak_gain_pct = ((trade['highest_price'] - entry_p) / entry_p) * 100.0

                for step in ladder_steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['highest_price'] * (1.0 - LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif use_early_inval and trade['ladder_level'] == 0 and minutes_open >= early_mins:
                    raw_c = (close_p - entry_p) / entry_p
                    if raw_c <= -(early_loss_pct / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (close_p - entry_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            else: # SHORT
                peak_gain_pct = ((entry_p - trade['lowest_price']) / entry_p) * 100.0

                for step in ladder_steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['lowest_price'] * (1.0 + LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif use_early_inval and trade['ladder_level'] == 0 and minutes_open >= early_mins:
                    raw_c = (entry_p - close_p) / entry_p
                    if raw_c <= -(early_loss_pct / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (entry_p - close_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = BINANCE_ROUNDTRIP_FEE_PCT * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                equity_curve.append((current_time_str, round(equity, 2)))
                completed_trades.append({
                    'symbol': sym,
                    'direction': direction,
                    'leverage': lev,
                    'margin': round(trade['margin'], 2),
                    'entry_price': entry_p,
                    'exit_price': round(exit_price, 6),
                    'entry_time': trade['entry_time_str'],
                    'exit_time': current_time_str,
                    'bars_held': bars_held,
                    'minutes_held': minutes_open,
                    'raw_gain_pct': round(raw_gain_pct, 2),
                    'net_margin_pct': round(net_margin, 2),
                    'dollar_gain': round(dollar_gain, 2),
                    'status': exit_reason,
                    'ladder_level': trade['ladder_level']
                })
                cooldown_until[sym] = ts + (POST_LOSS_COOLDOWN_MINUTES * 60 * 1000)

                if dollar_gain < 0:
                    side_consecutive_losses[direction] += 1
                    if use_side_guard and side_consecutive_losses[direction] >= SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES:
                        side_locked_until[direction] = ts + (SIDE_STOPLOSS_COOLDOWN_MINUTES * 60 * 1000)
                else:
                    side_consecutive_losses[direction] = 0

                daily_net_dollar += dollar_gain
                if dollar_gain < 0:
                    daily_loss_sum += abs(dollar_gain)
                    if daily_loss_sum >= DAILY_MAX_DRAWDOWN_USDT:
                        daily_circuit_breaker = True
                daily_peak_pnl = max(daily_peak_pnl, daily_net_dollar)
                if DAILY_TRAILING_PROFIT_LOCK_ENABLED and daily_peak_pnl >= 30.0:
                    floor = 15.0 if daily_peak_pnl < 50.0 else (35.0 if daily_peak_pnl < 75.0 else 55.0)
                    if daily_net_dollar <= floor:
                        daily_profit_locked = True
            else:
                still_active.append(trade)

        active_trades = still_active

        if len(active_trades) >= max_concurrent or daily_circuit_breaker or daily_profit_locked:
            continue

        if not check_btc_shield(ts):
            continue

        bonus_slots = 0
        if daily_net_dollar > 0 and PROFIT_STEP_FOR_BONUS_TRADES > 0:
            bonus_slots = int(daily_net_dollar // PROFIT_STEP_FOR_BONUS_TRADES) * BONUS_TRADES_PER_STEP
        effective_max_trades = DAILY_BASE_MAX_TRADES + bonus_slots

        if daily_trades_count >= effective_max_trades:
            continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        for sym, setup in signals_by_ts.get(ts, []):
            if len(active_trades) >= max_concurrent or daily_trades_count >= effective_max_trades:
                break
            if sym in active_syms or ts < cooldown_until.get(sym, 0):
                continue
            if use_blacklist and sym in EXCLUDED_SYMBOLS_BLACKLIST:
                continue

            direction = setup['direction']

            if use_side_guard and ts < side_locked_until.get(direction, 0):
                continue
            if direction == 'LONG' and long_count >= max_per_dir:
                continue
            if direction == 'SHORT' and short_count >= max_per_dir:
                continue

            sl_pct = setup['sl_pct']
            tp_pct = setup['tp1_pct']
            score = setup['confluence_score']

            is_sniper = (score >= 85 and sl_pct <= MAX_SL_PCT_20X)
            leverage = 20 if is_sniper else 10
            max_sl_allowed = MAX_SL_PCT_20X if leverage == 20 else MAX_SL_PCT_10X

            if sl_pct > max_sl_allowed or sl_pct <= 0:
                continue

            rr = tp_pct / sl_pct if sl_pct > 0 else 0
            if rr < MIN_RR_RATIO:
                continue

            allocated_margin = min(target_risk_usd / (sl_pct / 100.0 * leverage), 200.0)
            allocated_margin = max(allocated_margin, 50.0)

            active_trades.append({
                'symbol': sym,
                'direction': direction,
                'leverage': leverage,
                'risk_grade': setup['risk_grade'],
                'entry_time_ts': ts,
                'entry_time_str': current_time_str,
                'entry_price': setup['current_price'],
                'current_sl': setup['stop_loss'],
                'take_profit': setup['take_profit_1'],
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'margin': allocated_margin,
                'ladder_level': 0,
                'bars_held': 0,
                'highest_price': setup['current_price'],
                'lowest_price': setup['current_price']
            })
            daily_trades_count += 1
            if direction == 'LONG':
                long_count += 1
            else:
                short_count += 1

    wins = [t for t in completed_trades if t['dollar_gain'] > 0]
    losses = [t for t in completed_trades if t['dollar_gain'] < 0]
    bes = [t for t in completed_trades if t['dollar_gain'] == 0]
    total_trades = len(completed_trades)
    win_rate = len(wins) / total_trades * 100 if total_trades > 0 else 0
    net_pnl = sum(t['dollar_gain'] for t in completed_trades)
    total_won = sum(t['dollar_gain'] for t in wins)
    total_lost = abs(sum(t['dollar_gain'] for t in losses))
    profit_factor = total_won / total_lost if total_lost > 0 else 999.0

    long_trades = [t for t in completed_trades if t['direction'] == 'LONG']
    short_trades = [t for t in completed_trades if t['direction'] == 'SHORT']
    long_wins = [t for t in long_trades if t['dollar_gain'] > 0]
    short_wins = [t for t in short_trades if t['dollar_gain'] > 0]
    long_net = sum(t['dollar_gain'] for t in long_trades)
    short_net = sum(t['dollar_gain'] for t in short_trades)

    exits = Counter(t['status'] for t in completed_trades)

    peak = initial_equity
    max_dd = 0.0
    for _, eq in equity_curve:
        if eq > peak:
            peak = eq
        dd = (peak - eq)
        if dd > max_dd:
            max_dd = dd

    print(f"\n=======================================================")
    print(f"📊 {name}")
    print(f"=======================================================")
    print(f"💰 Başlangıç Kasası: ${initial_equity:.2f} | Bitiş Kasası: ${equity:.2f}")
    print(f"📈 Net Kâr/Zarar:    ${net_pnl:+.2f} ({net_pnl / initial_equity * 100:+.2f}%)")
    print(f"🎯 Toplam İşlem:     {total_trades} (Win: {len(wins)}, Loss: {len(losses)}, BE: {len(bes)}) | WinRate: %{win_rate:.1f}")
    print(f"🔥 Profit Factor:    {profit_factor:.2f} | Max Drawdown: ${max_dd:.2f} (%{max_dd/10:.1f})")
    print(f"🟢 LONG:  {len(long_trades)} işlem | %{len(long_wins)/len(long_trades)*100 if long_trades else 0:.1f} Win | Net: ${long_net:+.2f}")
    print(f"🔴 SHORT: {len(short_trades)} işlem | %{len(short_wins)/len(short_trades)*100 if short_trades else 0:.1f} Win | Net: ${short_net:+.2f}")
    print(f"🚪 Çıkış Dağılımı:")
    for k, v in sorted(exits.items(), key=lambda x: -x[1]):
        print(f"   • {k:<25}: {v} adet")

    return {
        'name': name,
        'initial_equity': initial_equity,
        'final_equity': round(equity, 2),
        'net_pnl': round(net_pnl, 2),
        'return_pct': round(net_pnl / initial_equity * 100, 2),
        'total_trades': total_trades,
        'wins': len(wins),
        'losses': len(losses),
        'bes': len(bes),
        'win_rate': round(win_rate, 2),
        'profit_factor': round(profit_factor, 2),
        'max_dd': round(max_dd, 2),
        'max_dd_pct': round(max_dd / initial_equity * 100, 2),
        'long_trades': len(long_trades),
        'long_win_rate': round(len(long_wins)/len(long_trades)*100 if long_trades else 0, 2),
        'long_net': round(long_net, 2),
        'short_trades': len(short_trades),
        'short_win_rate': round(len(short_wins)/len(short_trades)*100 if short_trades else 0, 2),
        'short_net': round(short_net, 2),
        'exits': dict(exits),
        'trades': completed_trades,
        'daily_history': daily_history
    }

old_ladder = [
    {"step": 1, "trigger_raw_pct": 0.60, "lock_raw_pct": 0.15, "name": "Eski Basamak 1"},
    {"step": 2, "trigger_raw_pct": 1.00, "lock_raw_pct": 0.50, "name": "Eski Basamak 2"}
]

# 1. Eski Bot (Kalkanlar Yok, Kara Liste Yok)
sim_old = run_simulation(
    name="1. ESKİ BOT (Korumasız, Kara Liste Yok, Freqtrade Yok)",
    use_blacklist=False,
    use_side_guard=False,
    ladder_steps=old_ladder,
    use_early_inval=False
)

# 2. ŞU ANKİ GÜNCEL BOTUMUZ (Freqtrade Side Guard + Yeni Merdiven Kalkanı + Kara Liste)
sim_current = run_simulation(
    name="2. GÜNCEL BOTUMUZ (Freqtrade Kalkanı + Dual-Tier BE+ + Kara Liste)",
    use_blacklist=True,
    use_side_guard=True,
    ladder_steps=LADDER_STEPS,
    use_early_inval=False # Hold time and stop ladder resolve
)

# 3. GÜNCEL BOT + HASSAS ERKEN İPTAL (45 dk / -%0.65)
sim_tuned = run_simulation(
    name="3. GÜNCEL BOT + 45dk ERKEN İPTAL KALKANI",
    use_blacklist=True,
    use_side_guard=True,
    ladder_steps=LADDER_STEPS,
    use_early_inval=True,
    early_mins=45,
    early_loss_pct=0.65
)

# JSON Kaydet
out_path = Path(project_root) / "data" / "simulations" / "sim_official_30d_comparison.json"
with open(out_path, "w", encoding="utf-8") as f:
    json.dump({
        'sim_old': {k: v for k, v in sim_old.items() if k not in ['trades']},
        'sim_current': {k: v for k, v in sim_current.items() if k not in ['trades']},
        'sim_tuned': {k: v for k, v in sim_tuned.items() if k not in ['trades']},
        'current_bot_trades_sample': sim_current['trades'][-15:]
    }, f, indent=2, ensure_ascii=False)

print(f"\n✓ Resmi karşılaştırmalı simülasyon tamamlandı ve kaydedildi: {out_path}")

