import sys
from pathlib import Path
import math
from typing import List, Dict, Tuple, Optional

sys.path.insert(0, r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
from core.binance_client import BinanceFuturesClient

client = BinanceFuturesClient()
candles_15m = client.get_klines("ETHUSDT", interval="15m", limit=80)

# ==========================================
# 4. RSI & MACD REGULAR / HIDDEN DIVERGENCE
# ==========================================
def calculate_rsi_series(closes: List[float], period: int = 14) -> List[float]:
    if len(closes) <= period:
        return [50.0] * len(closes)
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [max(0.0, d) for d in deltas]
    losses = [max(0.0, -d) for d in deltas]
    
    rsi = [50.0] * period
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    rsi.append(100.0 if avg_loss == 0 else (100.0 - (100.0 / (1.0 + (avg_gain / avg_loss)))))
    
    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        rsi.append(100.0 if avg_loss == 0 else (100.0 - (100.0 / (1.0 + (avg_gain / avg_loss)))))
    return rsi

def detect_rsi_divergence(candles: List[Dict], lookback: int = 40, order: int = 3) -> Dict:
    """
    Algoritmik RSI Diverjans Tespit Motoru:
    - Düzenli Boğa Diverjansı (Regular Bullish): Fiyat Yeni Dip (LL) yaparken RSI Yüksek Dip (HL) yapar -> Güçlü Dönüş!
    - Gizli Boğa Diverjansı (Hidden Bullish): Fiyat Yüksek Dip (HL) yaparken RSI Yeni Dip (LL) yapar -> Trend Devamı!
    - Düzenli Ayı Diverjansı (Regular Bearish): Fiyat Yeni Tepe (HH) yaparken RSI Düşük Tepe (LH) yapar -> Tepe Dönüşü!
    - Gizli Ayı Diverjansı (Hidden Bearish): Fiyat Düşük Tepe (LH) yaparken RSI Yeni Tepe (HH) yapar -> Ayı Trendi Devamı!
    """
    if len(candles) < lookback:
        return {"divergence": "NONE", "score_bonus": 0, "description": "Yetersiz Veri"}
        
    recent = candles[-lookback:]
    closes = [float(c["close"]) for c in recent]
    lows = [float(c["low"]) for c in recent]
    highs = [float(c["high"]) for c in recent]
    
    rsi = calculate_rsi_series(closes, period=14)
    n = len(closes)
    
    # 1. Swing Highs & Swing Lows (Order=3 pencere ile tepe ve dip noktalarını bul)
    swing_lows = []
    swing_highs = []
    
    for i in range(order, n - order):
        # Swing Low: i etrafındaki barlardan daha düşük
        if all(lows[i] <= lows[i - k] for k in range(1, order + 1)) and all(lows[i] <= lows[i + k] for k in range(1, order + 1)):
            swing_lows.append(i)
        # Swing High: i etrafındaki barlardan daha yüksek
        if all(highs[i] >= highs[i - k] for k in range(1, order + 1)) and all(highs[i] >= highs[i + k] for k in range(1, order + 1)):
            swing_highs.append(i)
            
    # Güncel barı da dahil et (eğer son barda dönüş varsa)
    curr_low = lows[-1]
    curr_high = highs[-1]
    curr_rsi = rsi[-1]
    
    divergence = "NONE"
    desc = "Diverjans Yok"
    bullish_divergence = None
    bearish_divergence = None
    
    # Boğa Diverjansı Kontrolü (Swing Lows)
    if len(swing_lows) >= 1:
        prev_idx = swing_lows[-1]
        prev_p = lows[prev_idx]
        prev_r = rsi[prev_idx]
        
        # Son 1-2 bardaki en düşük dip
        recent_p = min(lows[-3:])
        recent_p_idx = -3 + lows[-3:].index(recent_p) + n
        recent_r = rsi[recent_p_idx]
        
        if (n - 1 - prev_idx) >= 4: # En az 4 bar aralık olsun
            # A) Regular Bullish: Price LL, RSI HL
            if recent_p < prev_p and recent_r > prev_r + 1.5:
                bullish_divergence = "REGULAR_BULLISH"
                desc = f"Düzenli Boğa Diverjansı (Fiyat Dip: ${recent_p:.2f} < ${prev_p:.2f} | RSI: {recent_r:.1f} > {prev_r:.1f})"
            # B) Hidden Bullish: Price HL, RSI LL
            elif recent_p > prev_p and recent_r < prev_r - 1.5:
                bullish_divergence = "HIDDEN_BULLISH"
                desc = f"Gizli Boğa Diverjansı (Trend Devamı: Fiyat ${recent_p:.2f} > ${prev_p:.2f} | RSI: {recent_r:.1f} < {prev_r:.1f})"

    # Ayı Diverjansı Kontrolü (Swing Highs)
    if len(swing_highs) >= 1:
        prev_idx = swing_highs[-1]
        prev_p = highs[prev_idx]
        prev_r = rsi[prev_idx]
        
        recent_p = max(highs[-3:])
        recent_p_idx = -3 + highs[-3:].index(recent_p) + n
        recent_r = rsi[recent_p_idx]
        
        if (n - 1 - prev_idx) >= 4:
            # A) Regular Bearish: Price HH, RSI LH
            if recent_p > prev_p and recent_r < prev_r - 1.5:
                bearish_divergence = "REGULAR_BEARISH"
                desc = f"Düzenli Ayı Diverjansı (Fiyat Tepe: ${recent_p:.2f} > ${prev_p:.2f} | RSI: {recent_r:.1f} < {prev_r:.1f})"
            # B) Hidden Bearish: Price LH, RSI HH
            elif recent_p < prev_p and recent_r > prev_r + 1.5:
                bearish_divergence = "HIDDEN_BEARISH"
                desc = f"Gizli Ayı Diverjansı (Ayı Trendi Devamı: Fiyat ${recent_p:.2f} < ${prev_p:.2f} | RSI: {recent_r:.1f} > {prev_r:.1f})"

    return {
        "bullish_divergence": bullish_divergence,
        "bearish_divergence": bearish_divergence,
        "description": desc,
        "current_rsi": round(curr_rsi, 1)
    }

div_res = detect_rsi_divergence(candles_15m)
print("4. RSI Divergence Result:")
print("  ", div_res)

# ==========================================
# 5. ADX (AVERAGE DIRECTIONAL INDEX)
# ==========================================
def calculate_adx(candles: List[Dict], period: int = 14) -> Dict:
    """
    Welles Wilder ADX Trend Gücü & Kararlılık Motoru
    - ADX >= 25: Çok Güçlü Trend (Kırılımlar %80+ güvenilir)
    - ADX 20 - 25: Gelişen Sağlıklı Trend
    - ADX < 20: Testere / Yatay Piyasa (Kırılımların çoğu tuzaktır)
    """
    if len(candles) < period * 2:
        return {"adx": 20.0, "pdi": 20.0, "mdi": 20.0, "trend_strength": "NEUTRAL"}
        
    highs = [float(c["high"]) for c in candles]
    lows = [float(c["low"]) for c in candles]
    closes = [float(c["close"]) for c in candles]
    n = len(candles)
    
    tr_list = []
    pdm_list = [] # +DM
    mdm_list = [] # -DM
    
    for i in range(1, n):
        h = highs[i]
        l = lows[i]
        prev_h = highs[i - 1]
        prev_l = lows[i - 1]
        prev_c = closes[i - 1]
        
        tr = max(h - l, abs(h - prev_c), abs(l - prev_c))
        tr_list.append(tr)
        
        up_move = h - prev_h
        down_move = prev_l - l
        
        if up_move > down_move and up_move > 0:
            pdm_list.append(up_move)
        else:
            pdm_list.append(0.0)
            
        if down_move > up_move and down_move > 0:
            mdm_list.append(down_move)
        else:
            mdm_list.append(0.0)
            
    # Wilder's Smoothing
    tr_smooth = sum(tr_list[:period])
    pdm_smooth = sum(pdm_list[:period])
    mdm_smooth = sum(mdm_list[:period])
    
    dx_list = []
    
    for i in range(period, len(tr_list)):
        tr_smooth = tr_smooth - (tr_smooth / period) + tr_list[i]
        pdm_smooth = pdm_smooth - (pdm_smooth / period) + pdm_list[i]
        mdm_smooth = mdm_smooth - (mdm_smooth / period) + mdm_list[i]
        
        pdi = (100.0 * pdm_smooth / tr_smooth) if tr_smooth > 0 else 0.0
        mdi = (100.0 * mdm_smooth / tr_smooth) if tr_smooth > 0 else 0.0
        
        di_sum = pdi + mdi
        dx = (100.0 * abs(pdi - mdi) / di_sum) if di_sum > 0 else 0.0
        dx_list.append((dx, pdi, mdi))
        
    if len(dx_list) < period:
        return {"adx": 20.0, "pdi": 20.0, "mdi": 20.0, "trend_strength": "NEUTRAL"}
        
    # ADX is smoothed DX
    adx = sum(d[0] for d in dx_list[:period]) / period
    for d in dx_list[period:]:
        adx = (adx * (period - 1) + d[0]) / period
        
    last_pdi = dx_list[-1][1]
    last_mdi = dx_list[-1][2]
    
    if adx >= 28.0:
        strength = "VERY_STRONG_TREND"
    elif adx >= 22.0:
        strength = "STRONG_TREND"
    elif adx >= 17.0:
        strength = "MODERATE_TREND"
    else:
        strength = "WEAK_CHOP"
        
    return {
        "adx": round(adx, 1),
        "pdi": round(last_pdi, 1),
        "mdi": round(last_mdi, 1),
        "trend_strength": strength,
        "is_bullish_dominance": last_pdi > last_mdi,
        "is_bearish_dominance": last_mdi > last_pdi,
        "is_strong_trend": adx >= 22.0
    }

adx_res = calculate_adx(candles_15m)
print("\n5. ADX Result:")
print("  ", adx_res)
