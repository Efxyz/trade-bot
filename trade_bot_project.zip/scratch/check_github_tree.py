import sys, os
sys.path.insert(0, os.getcwd())
import urllib.request, json
from sync_to_github import get_token, REPO_OWNER, REPO_NAME

token = get_token()
url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/trees/main?recursive=1"
req = urllib.request.Request(url, headers={'Authorization': f'Bearer {token}', 'User-Agent': 'Monitor'})

with urllib.request.urlopen(req) as resp:
    data = json.loads(resp.read().decode('utf-8'))

tree = data.get('tree', [])
print(f"Total items in GitHub repo: {len(tree)}")
for item in sorted(tree, key=lambda x: x['path']):
    if item['type'] == 'blob':
        print(f"📄 {item['path']}")
    else:
        print(f"📁 {item['path']}/")
