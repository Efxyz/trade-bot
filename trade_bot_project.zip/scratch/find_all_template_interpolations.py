import re

with open("dashboard.py", "r", encoding="utf-8") as f:
    html = f.read()

# Find all expressions like ${...} in the template
exprs = re.findall(r"\$\{[^}]+\}", html)
time_exprs = [e for e in exprs if any(k in e.lower() for k in ["time", "date", "created", "closed", "entered", "calibrat"])]

print("All time-related template interpolations in dashboard.py:")
for e in set(time_exprs):
    print(" ", e)
