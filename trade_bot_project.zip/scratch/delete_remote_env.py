import sys
import os
import json
import urllib.request
import urllib.error

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from sync_to_github import get_token, REPO_OWNER, REPO_NAME, BRANCH

def delete_remote_env():
    token = get_token()
    if not token:
        print("❌ GITHUB_TOKEN bulunamadı.")
        return False

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Antigravity-SecurityPatch",
        "Content-Type": "application/json"
    }

    api_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/.env"

    # 1. Mevcut dosyanın SHA'sını al
    try:
        req = urllib.request.Request(f"{api_url}?ref={BRANCH}", headers=headers, method="GET")
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            sha = data.get("sha")
            print(f"📄 Bulunan .env dosyasının SHA'sı: {sha}")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print("✅ .env dosyası zaten GitHub'da bulunmuyor.")
            return True
        print(f"❌ SHA sorgu hatası: {e}")
        return False

    # 2. DELETE isteği gönder
    payload = {
        "message": "security: remove leaked .env file from repository",
        "sha": sha,
        "branch": BRANCH
    }

    try:
        req = urllib.request.Request(api_url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="DELETE")
        with urllib.request.urlopen(req) as resp:
            print("✅ BAŞARILI: .env dosyası GitHub reposundan kalıcı olarak silindi!")
            return True
    except Exception as e:
        print(f"❌ Silme hatası: {e}")
        return False

if __name__ == "__main__":
    print("🚀 .env Dosyasını GitHub'dan Silme Operasyonu...")
    delete_remote_env()
