import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

for sym in ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "NEARUSDT", "SUIUSDT"]:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    
    current_price = c15m[-1]["close"]
    closes_15m = [c["close"] for c in c15m]

    fvg = TechnicalAnalysisAgent.detect_fvg(c15m)
    ob = TechnicalAnalysisAgent.detect_order_blocks(c15m)
    sweeps = TechnicalAnalysisAgent.detect_liquidity_sweep(c15m)
    squeeze = TechnicalAnalysisAgent.calculate_ttm_squeeze(c15m)
    ema20 = TechnicalAnalysisAgent.calculate_ema(closes_15m, 20)
    ema50 = TechnicalAnalysisAgent.calculate_ema(closes_15m, 50)
    rsi = TechnicalAnalysisAgent.calculate_rsi(closes_15m, 14)
    vwap = TechnicalAnalysisAgent.calculate_vwap(c15m)

    curr_ema20 = ema20[-1] if ema20 else 0
    curr_ema50 = ema50[-1] if ema50 else 0
    curr_rsi = rsi[-1] if rsi else 50
    curr_vwap = vwap[-1] if vwap else current_price

    print(f"\n=================== {sym} ===================")
    print(f"Price: {current_price}, VWAP: {curr_vwap:.4f}, EMA20: {curr_ema20:.4f}, EMA50: {curr_ema50:.4f}, RSI: {curr_rsi:.1f}")
    print(f"FVG: in_fvg={fvg.get('current_in_fvg')}, bullish={fvg.get('bullish_fvg')}, bearish={fvg.get('bearish_fvg')}")
    print(f"OB: at_ob={ob.get('current_at_ob')}, bullish={ob.get('bullish_ob')}, bearish={ob.get('bearish_ob')}")
    print(f"Sweeps: bull={sweeps.get('bullish_sweep')}, bear={sweeps.get('bearish_sweep')}")
    print(f"Squeeze: fired={squeeze.get('squeeze_fired')}, on={squeeze.get('squeeze_on')}, mom={squeeze.get('momentum'):.4f}")
    
    recent_vol = c15m[-1]["volume"]
    avg_v = sum(c["volume"] for c in c15m[-11:-1]) / 10
    print(f"Volume: recent={recent_vol:.2f}, avg={avg_v:.2f}, ratio={recent_vol/avg_v if avg_v>0 else 0:.2f}")

    setup, reason = agent.analyze_setup(sym, c15m, c1h)
    print("Analyze result setup:", bool(setup), "\nReason:", reason)
