import os

# Update fast_config.py
with open("fast_config.py", "r", encoding="utf-8") as f:
    text = f.read()

text = text.replace(
    'FAST_TARGET_PROFIT_PCT = 0.70           # Hedef Kâr: Fiyatta +%0.70 (10x\'te +%7.0 Marjin Kârı)\n'
    'FAST_STOP_LOSS_PCT = 0.35               # Stop Loss: Fiyatta -%0.35 (10x\'te -%3.5 Marjin Kaybı)\n'
    'FAST_MIN_CONFLUENCE_SCORE = 70          # Hızlı Giriş Eşiği (70+ puan ile kaliteli filtrelenmiş kurulumlar)\n'
    'FAST_MIN_RR_RATIO = 1.5                 # Minimum 1:1.5 Risk/Ödül oranı\n'
    'FAST_MAX_HOLD_MINUTES = 15              # Maksimum Pozisyon Süresi: 15 Dakika (Hareketsizse Çık!)\n\n'
    '# Erken İptal (Hızlı Zarar Freni)\n'
    'FAST_EARLY_INVALIDATION_ENABLED = True\n'
    'FAST_EARLY_INVALIDATION_MINUTES = 4     # 4. dakikada negatifse (-%0.22) oyalanmadan çık\n'
    'FAST_EARLY_INVALIDATION_LOSS_PCT = 0.22\n\n'
    '# Günlük Devre Kesici & Karantina (FAST Kasa Kalkanı)\n'
    'FAST_CIRCUIT_BREAKER_ENABLED = False     # Patron Talimatı: Devre kesici kapatıldı (Bugün işlemler izleniyor)\n'
    'FAST_DAILY_MAX_DRAWDOWN_USDT = 35.0     # Günlük -$35 net zararda FAST taramayı o günlüğüne durdur\n'
    'FAST_POST_LOSS_COOLDOWN_MINUTES = 15    # Zararlı paritede 15 dk mola (testere tuzağına son)\n'
    'FAST_BLOCK_DEAD_CHOP = False            # Hızlı scalping için piyasa dondurması kapalı (LONG koruması aktif kalır)',

    'FAST_TARGET_PROFIT_PCT = 0.95           # Hedef Kâr: Fiyatta +%0.95 (10x\'te +%9.5 Marjin Kârı - Komisyonun 9.5 katı!)\n'
    'FAST_STOP_LOSS_PCT = 0.45               # Stop Loss: Fiyatta -%0.45 (10x\'te -%4.5 Marjin Kaybı)\n'
    'FAST_MIN_CONFLUENCE_SCORE = 72          # Hızlı Giriş Eşiği (72+ puan ile kaliteli filtrelenmiş kurulumlar)\n'
    'FAST_MIN_RR_RATIO = 1.8                 # Minimum 1:1.8 Risk/Ödül oranı\n'
    'FAST_MAX_HOLD_MINUTES = 20              # Maksimum Pozisyon Süresi: 20 Dakika (Hareketsizse Çık!)\n\n'
    '# Erken İptal (Hızlı Zarar Freni)\n'
    'FAST_EARLY_INVALIDATION_ENABLED = True\n'
    'FAST_EARLY_INVALIDATION_MINUTES = 5     # 5. dakikada negatifse (-%0.25) oyalanmadan çık\n'
    'FAST_EARLY_INVALIDATION_LOSS_PCT = 0.25\n\n'
    '# Günlük Devre Kesici & Kasa Koruma Kotası (FAST Kasa Kalkanı - 14 Kasım Komisyon Dersi)\n'
    'FAST_CIRCUIT_BREAKER_ENABLED = True     # Kasa Sigortası: Aktif!\n'
    'FAST_DAILY_MAX_DRAWDOWN_USDT = 35.0     # Günlük -$35 net zararda FAST taramayı o günlüğüne durdur\n'
    'FAST_MAX_DAILY_TRADES = 15              # Sert Günlük İşlem Kotası: Günde Maksimum 15 Kaliteli İşlem (Overtrading Kilidi)\n'
    'FAST_MAX_DAILY_FEE_USDT = 15.0          # Komisyon Tavanı: Günlük komisyon $15\'i aşarsa o günkü taramayı dondur\n'
    'FAST_POST_LOSS_COOLDOWN_MINUTES = 15    # Zararlı paritede 15 dk mola (testere tuzağına son)\n'
    'FAST_BLOCK_DEAD_CHOP = False            # Hızlı scalping için piyasa dondurması kapalı (LONG koruması aktif kalır)'
)

with open("fast_config.py", "w", encoding="utf-8") as f:
    f.write(text)
print("fast_config.py updated!")

# Update super_fast_config.py
with open("super_fast_config.py", "r", encoding="utf-8") as f:
    sf_text = f.read()

sf_text = sf_text.replace(
    'SUPER_FAST_TARGET_PROFIT_PCT = 0.50          # Hedef Kâr: Fiyatta +%0.50 (10x\'te +%5.0 Marjin Kârı)\n'
    'SUPER_FAST_STOP_LOSS_PCT = 0.25              # Stop Loss: Fiyatta -%0.25 (10x\'te -%2.5 Marjin Kaybı)\n'
    'SUPER_FAST_MAX_HOLD_MINUTES = 6              # 6 Dakika içinde kâra gitmeyen mikro scalpten çık (Hızlı Rotasyon)\n\n'
    '# Erken Geçersizlik (Early Invalidation)\n'
    'SUPER_FAST_EARLY_INVALIDATION_ENABLED = True\n'
    'SUPER_FAST_EARLY_INVALIDATION_MINUTES = 2    # 2 dakika içinde tersine -%0.16 giderse erken kes\n'
    'SUPER_FAST_EARLY_INVALIDATION_LOSS_PCT = 0.16\n\n'
    '# Güvenlik Kalkanı\n'
    'SUPER_FAST_CIRCUIT_BREAKER_ENABLED = False  # Patron Talimatı: Devre kesici kapatıldı (Bugün işlemler izleniyor)\n'
    'SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT = 40.0    # Günlük $40 kümülatif zararda yeni mikro işlemleri durdur\n'
    'SUPER_FAST_POST_LOSS_COOLDOWN_MINUTES = 12   # Zararlı kapanan pariteye 12 dakika dinlenme (intikam işlemine son)\n'
    'SUPER_FAST_BLOCK_DEAD_CHOP = False           # Saniyelik scalping için piyasa dondurması kapalı (LONG koruması aktif kalır)',

    'SUPER_FAST_TARGET_PROFIT_PCT = 0.75          # Hedef Kâr: Fiyatta +%0.75 (10x\'te +%7.5 Marjin Kârı - Komisyonun 7.5 katı!)\n'
    'SUPER_FAST_STOP_LOSS_PCT = 0.35              # Stop Loss: Fiyatta -%0.35 (10x\'te -%3.5 Marjin Kaybı)\n'
    'SUPER_FAST_MAX_HOLD_MINUTES = 8              # 8 Dakika içinde kâra gitmeyen mikro scalpten çık (Hızlı Rotasyon)\n\n'
    '# Erken Geçersizlik (Early Invalidation)\n'
    'SUPER_FAST_EARLY_INVALIDATION_ENABLED = True\n'
    'SUPER_FAST_EARLY_INVALIDATION_MINUTES = 3    # 3 dakika içinde tersine -%0.20 giderse erken kes\n'
    'SUPER_FAST_EARLY_INVALIDATION_LOSS_PCT = 0.20\n\n'
    '# Güvenlik Kalkanı & Kasa Koruma Kotası (Süper FAST Kasa Kalkanı - 14 Kasım Komisyon Dersi)\n'
    'SUPER_FAST_CIRCUIT_BREAKER_ENABLED = True   # Kasa Sigortası: Aktif!\n'
    'SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT = 40.0    # Günlük $40 kümülatif zararda yeni mikro işlemleri durdur\n'
    'SUPER_FAST_MAX_DAILY_TRADES = 25             # Sert Günlük İşlem Kotası: Günde Maksimum 25 İşlem (Overtrading Kilidi)\n'
    'SUPER_FAST_MAX_DAILY_FEE_USDT = 20.0         # Komisyon Tavanı: Günlük komisyon $20\'yi aşarsa o günkü taramayı dondur\n'
    'SUPER_FAST_POST_LOSS_COOLDOWN_MINUTES = 12   # Zararlı kapanan pariteye 12 dakika dinlenme (intikam işlemine son)\n'
    'SUPER_FAST_BLOCK_DEAD_CHOP = False           # Saniyelik scalping için piyasa dondurması kapalı (LONG koruması aktif kalır)'
)

with open("super_fast_config.py", "w", encoding="utf-8") as f:
    f.write(sf_text)
print("super_fast_config.py updated!")

