"""
End-to-End Integration Test for Autonomous Self-Training Engine
Verifies:
1. Multi-source trade aggregation (15m, 1m FAST, SÜPER FAST)
2. Causal loss attribution and market regime diagnosis
3. Auto-approval and adaptive config persistence
4. Database storage in autonomous_learning_reports
5. Post-trade reflection automatic self-training trigger
6. Dashboard Flask endpoints /api/data, /api/tuning/reports, /api/tuning/run-autonomous
7. Frontend HTML & JS elements
"""
import sys, os
sys.path.insert(0, os.path.abspath("."))
import json
from core.self_tuning_engine import SelfTuningEngine
from core.database import get_learning_reports_db, get_latest_learning_report_db
from core.reflection import ReflectorEngine
from dashboard import app

print("=== 1. Testing SelfTuningEngine Autonomous Training Cycle ===")
res = SelfTuningEngine.run_autonomous_training_cycle(auto_commit=True)
assert res["status"] in ("AUTO_APPROVED", "OPTIMAL_NO_CHANGE"), f"Unexpected status: {res['status']}"
assert res["trades_analyzed"] >= 10, f"Expected at least 10 trades, got {res['trades_analyzed']}"
assert "regime_diagnosis" in res, "Missing regime_diagnosis"
assert len(res.get("hypotheses", [])) > 0, "Hypotheses should not be empty"
print(f"   [OK] Epoch #{res['epoch_num']}: Status={res['status']}, Trades={res['trades_analyzed']}, WR=%{res['win_rate']}, E={res['expectancy']}%, PF={res['profit_factor']}")
print(f"        Regime: {res['regime_diagnosis'][:60]}...")
print(f"        Hypotheses: {len(res['hypotheses'])} generated")
print(f"        Deltas: {len(res.get('parameter_deltas', []))} applied")

print("=== 2. Testing Database Persistence ===")
reports = get_learning_reports_db(limit=5)
assert len(reports) > 0, "No learning reports found in database"
latest = reports[0]
assert latest["epoch_num"] == res["epoch_num"], "Epoch mismatch in DB"
print(f"   [OK] DB contains {len(reports)} learning reports. Latest Epoch: #{latest['epoch_num']}")

print("=== 3. Testing Post-Trade Reflection Auto-Trigger ===")
test_trade = {
    "signal_id": 99999,
    "symbol": "BTCUSDT",
    "direction": "LONG",
    "status": "HIT_TP",
    "pnl_pct": 5.2,
    "gross_pnl_pct": 5.4,
    "fee_pct": 0.2,
    "leverage": 10,
    "minutes_open": 25
}
refl = ReflectorEngine.reflect_on_trade(test_trade)
assert refl["outcome_type"] == "WIN"
reports_after = get_learning_reports_db(limit=5)
print(f"   [OK] ReflectorEngine processed trade and auto-triggered training cycle! Total reports in DB: {len(reports_after)}")

print("=== 4. Testing Dashboard Flask Test Client ===")
client = app.test_client()

# /api/data
res_data = client.get("/api/data")
assert res_data.status_code == 200
data_json = res_data.get_json()
assert "learning_reports" in data_json, "learning_reports missing in /api/data"
assert "tuning_info" in data_json, "tuning_info missing in /api/data"
print(f"   [OK] /api/data contains {len(data_json['learning_reports'])} learning reports in cache.")

# /api/tuning/reports
res_reps = client.get("/api/tuning/reports")
assert res_reps.status_code == 200
reps_json = res_reps.get_json()
assert len(reps_json) > 0, "Empty reports from /api/tuning/reports"
print(f"   [OK] /api/tuning/reports returned {len(reps_json)} reports.")

# /api/tuning/run-autonomous
res_auto = client.post("/api/tuning/run-autonomous")
assert res_auto.status_code == 200
auto_json = res_auto.get_json()
assert auto_json["success"] is True
print(f"   [OK] /api/tuning/run-autonomous executed successfully without PIN! Epoch #{auto_json['data']['epoch_num']}")

# Dashboard HTML verification
res_html = client.get("/")
assert res_html.status_code == 200
html = res_html.get_data(as_text=True)
assert "runAutonomousTrainingNow" in html, "Missing runAutonomousTrainingNow in HTML JS"
assert "btnAutoTrain" in html, "Missing btnAutoTrain in HTML"
assert "OTONOM AKTİF" in html, "Missing OTONOM AKTİF in HTML"
print("   [OK] Dashboard HTML & JS contains all autonomous training elements!")

print("\n>>> ALL AUTONOMOUS LEARNING TESTS PASSED! <<<")
