import json
import os
import sys
import time
from bisect import bisect_right
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
os.chdir(str(project_root))

from config import (
    BINANCE_ROUNDTRIP_FEE_PCT,
    ESTIMATED_SLIPPAGE_PCT,
    EXCLUDED_SYMBOLS_BLACKLIST,
    LADDER_DYNAMIC_CHANNEL_PCT,
    LEVERAGE_HIGH,
    LEVERAGE_STANDARD,
    MAX_CONCURRENT_TRADES,
    MAX_POSITIONS_PER_DIRECTION,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_RR_RATIO,
    POST_LOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
)
from agents.ta_agent import TechnicalAnalysisAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

from benchmark_precompute import build_full_1h_candles

coin_data = {}
all_ts = set()
for sym, c_list in raw_cache.items():
    if sym in EXCLUDED_SYMBOLS_BLACKLIST:
        continue
    c_1h = build_full_1h_candles(c_list)
    h_close_ts = [c['timestamp'] + 3600*1000 for c in c_1h]
    coin_data[sym] = {
        'list_15m': c_list,
        'by_ts': {x['timestamp']: x for x in c_list},
        'idx_by_ts': {x['timestamp']: i for i, x in enumerate(c_list)},
        'list_1h': c_1h,
        'h_close_ts': h_close_ts
    }
    all_ts.update(x['timestamp'] for x in c_list)

sorted_ts = sorted(list(all_ts))
ta_agent = TechnicalAnalysisAgent()

signals_by_ts = {ts: [] for ts in sorted_ts}
for sym, d in coin_data.items():
    c15 = d['list_15m']
    c1h = d['list_1h']
    h_close_ts = d['h_close_ts']
    for idx, c in enumerate(c15):
        if idx < 45:
            continue
        ts = c['timestamp']
        win_15m = c15[max(0, idx-59) : idx+1]
        h_end_idx = bisect_right(h_close_ts, ts)
        win_1h = c1h[max(0, h_end_idx-35) : h_end_idx] if h_end_idx >= 15 else None
        
        setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
        if setup:
            signals_by_ts[ts].append((sym, setup))

steps = [
    {"step": 1, "trigger_raw_pct": 0.40, "lock_raw_pct": 0.15, "name": "Basamak 1 (BE+)"},
    {"step": 2, "trigger_raw_pct": 0.70, "lock_raw_pct": 0.35, "name": "Basamak 2"},
    {"step": 3, "trigger_raw_pct": 1.15, "lock_raw_pct": 0.75, "name": "Basamak 3"},
    {"step": 4, "trigger_raw_pct": 1.65, "lock_raw_pct": 1.30, "name": "Basamak 4"}
]

def test_hold_time(max_hold_mins: int):
    equity = 1000.0
    active_trades = []
    completed_trades = []
    cooldown_until = {}
    side_consecutive_losses = {"LONG": 0, "SHORT": 0}
    side_locked_until = {"LONG": 0, "SHORT": 0}

    for ts in sorted_ts:
        c_time = datetime.fromtimestamp(ts/1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            c_info = coin_data.get(sym, {}).get('by_ts', {}).get(ts)
            if not c_info:
                still_active.append(trade)
                continue

            high_p = c_info['high']
            low_p = c_info['low']
            close_p = c_info['close']

            direction = trade['direction']
            entry_p = trade['entry_price']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            lev = trade['leverage']

            trade['bars_held'] += 1
            bars_held = trade['bars_held']

            trade['highest_price'] = max(trade.get('highest_price', entry_p), high_p)
            trade['lowest_price'] = min(trade.get('lowest_price', entry_p), low_p)

            closed = False
            exit_price = entry_p
            exit_reason = ""

            if direction == "LONG":
                peak_gain_pct = ((trade['highest_price'] - entry_p) / entry_p) * 100.0
                for step in steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['highest_price'] * (1.0 - LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    exit_reason = f"LADDER_{trade['ladder_level']}" if trade['ladder_level'] > 0 else "SL"
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "TP"
                elif bars_held >= (max_hold_mins // 15):
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT"

            else: # SHORT
                peak_gain_pct = ((entry_p - trade['lowest_price']) / entry_p) * 100.0
                for step in steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['lowest_price'] * (1.0 + LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    exit_reason = f"LADDER_{trade['ladder_level']}" if trade['ladder_level'] > 0 else "SL"
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "TP"
                elif bars_held >= (max_hold_mins // 15):
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = (BINANCE_ROUNDTRIP_FEE_PCT + ESTIMATED_SLIPPAGE_PCT) * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                completed_trades.append({
                    'dollar_gain': dollar_gain,
                    'status': exit_reason
                })
                cooldown_until[sym] = ts + (POST_LOSS_COOLDOWN_MINUTES * 60 * 1000)

                if dollar_gain < 0:
                    side_consecutive_losses[direction] += 1
                    if SIDE_STOPLOSS_GUARD_ENABLED and side_consecutive_losses[direction] >= SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES:
                        side_locked_until[direction] = ts + (SIDE_STOPLOSS_COOLDOWN_MINUTES * 60 * 1000)
                else:
                    side_consecutive_losses[direction] = 0
            else:
                still_active.append(trade)

        active_trades = still_active

        if len(active_trades) >= 5:
            continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        for sym, setup in signals_by_ts.get(ts, []):
            if len(active_trades) >= 5:
                break
            if sym in active_syms or ts < cooldown_until.get(sym, 0):
                continue

            direction = setup['direction']
            if ts < side_locked_until.get(direction, 0):
                continue
            if direction == 'LONG' and long_count >= 3:
                continue
            if direction == 'SHORT' and short_count >= 3:
                continue

            sl_pct = setup['sl_pct']
            tp_pct = setup['tp1_pct']
            score = setup['confluence_score']

            is_sniper = (score >= 85 and sl_pct <= MAX_SL_PCT_20X)
            leverage = 20 if is_sniper else 10
            max_sl_allowed = MAX_SL_PCT_20X if leverage == 20 else MAX_SL_PCT_10X

            if sl_pct > max_sl_allowed or sl_pct <= 0:
                continue
            if tp_pct / sl_pct < MIN_RR_RATIO:
                continue

            allocated_margin = min(20.0 / (sl_pct / 100.0 * leverage), 200.0)
            allocated_margin = max(allocated_margin, 50.0)

            active_trades.append({
                'symbol': sym,
                'direction': direction,
                'leverage': leverage,
                'entry_price': setup['current_price'],
                'current_sl': setup['stop_loss'],
                'take_profit': setup['take_profit_1'],
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'margin': allocated_margin,
                'ladder_level': 0,
                'bars_held': 0,
                'highest_price': setup['current_price'],
                'lowest_price': setup['current_price']
            })
            if direction == 'LONG':
                long_count += 1
            else:
                short_count += 1

    wins = [t for t in completed_trades if t['dollar_gain'] > 0]
    losses = [t for t in completed_trades if t['dollar_gain'] < 0]
    net_pnl = sum(t['dollar_gain'] for t in completed_trades)
    exits = Counter(t['status'] for t in completed_trades)
    wr = len(wins) / len(completed_trades) * 100 if completed_trades else 0
    print(f"Hold {max_hold_mins}m -> Equity: ${equity:.2f} | Net: ${net_pnl:+.2f} | Trades: {len(completed_trades)} | WR: %{wr:.1f} | Exits: {dict(exits)}")

for h in [60, 90, 180, 240, 360, 480]:
    test_hold_time(h)

