import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.scanner_agent import MarketScannerAgent
from agents.ta_agent import TechnicalAnalysisAgent
from config import MIN_CONFLUENCE_SCORE, MIN_CONFLUENCE_SCORE_SHORT, BTC_CHOP_MIN_RANGE_4H_PCT

client = BinanceFuturesClient()
scanner = MarketScannerAgent(client)
ta = TechnicalAnalysisAgent()

print('=== CALIBRATED CONFIG ===')
print('MIN_CONFLUENCE_SCORE:', MIN_CONFLUENCE_SCORE)
print('MIN_CONFLUENCE_SCORE_SHORT:', MIN_CONFLUENCE_SCORE_SHORT)
print('BTC_CHOP_MIN_RANGE_4H_PCT:', BTC_CHOP_MIN_RANGE_4H_PCT)

candidates = scanner.scan_opportunities(limit=18)
syms = [c['symbol'] for c in candidates]
print('\nTaranan Adaylar:', syms)

btc_regime = client.get_btc_regime()
print('\nBTC Regime:', btc_regime.get('status'), '| Summary:', btc_regime.get('summary'))

print('\n=== DETAYLI PARITE ANALIZI ===')
for c in candidates:
    sym = c['symbol']
    k15 = client.get_klines(sym, interval='15m', limit=100)
    k1h = client.get_klines(sym, interval='1h', limit=40)
    burst = ta.check_volume_burst(k15)
    setup, reason = ta.analyze_setup(sym, k15, k1h)
    status_str = 'APPROVED' if setup else 'REJECTED'
    score_str = f"Skor: {setup.get('confluence_score')}" if setup else ""
    print(f"  {sym:12} | Burst: {str(burst):5} | {status_str:8} {score_str:10} | {reason[:60]}")
