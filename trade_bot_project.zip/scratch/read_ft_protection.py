import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "freqtrade-develop", "freqtrade-develop", "freqtrade")

# Read stoploss_guard.py
sl_guard_path = os.path.join(base, "plugins", "protections", "stoploss_guard.py")
if os.path.exists(sl_guard_path):
    print("=== STOPLOSS GUARD ===")
    with open(sl_guard_path, 'r', encoding='utf-8') as f:
        print(f.read()[:2000])

# Search for trailing stop logic in freqtrade
strat_interface = os.path.join(base, "strategy", "interface.py")
if os.path.exists(strat_interface):
    print("\n=== STRATEGY INTERFACE TRAILING STOP LOGIC ===")
    with open(strat_interface, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for i, l in enumerate(lines):
            if "trailing_stop" in l or "custom_stoploss" in l or "stoploss_on_exchange" in l:
                print(f"L{i}: {l.strip()}")

