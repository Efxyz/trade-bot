import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

# Let's test coin name mapping and news fetching
SYMBOL_MAP = {
    "BTC": "Bitcoin", "ETH": "Ethereum", "SOL": "Solana", "DOGE": "Dogecoin",
    "AVAX": "Avalanche", "XRP": "XRP Ripple", "ADA": "Cardano", "BNB": "Binance Coin",
    "LINK": "Chainlink", "SUI": "Sui Network", "NEAR": "NEAR Protocol", "PEPE": "Pepe memecoin",
    "SHIB": "Shiba Inu", "APT": "Aptos", "INJ": "Injective", "TIA": "Celestia",
    "KAVA": "Kava", "AR": "Arweave", "SEI": "Sei Network", "WIF": "dogwifhat"
}

def get_coin_names(symbol: str):
    clean = symbol.replace("USDT", "").replace("USDC", "").replace(".P", "")
    full_name = SYMBOL_MAP.get(clean, clean)
    return clean, full_name

print("SOL:", get_coin_names("SOLUSDT"))
print("ETH:", get_coin_names("ETHUSDT"))
print("KAVA:", get_coin_names("KAVAUSDT"))
