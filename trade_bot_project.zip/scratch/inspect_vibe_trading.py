import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "Vibe-Trading-main", "Vibe-Trading-main")

print("=== VIBE TRADING SCAN ===")
# List top level folders
for item in os.listdir(base):
    p = os.path.join(base, item)
    if os.path.isdir(p):
        print(f"Dir: {item} -> {len(os.listdir(p))} items")
    else:
        print(f"File: {item}")

# Read README.md or AGENT_CONTRIBUTOR_GUIDE.md
readme_path = os.path.join(base, "README.md")
if os.path.exists(readme_path):
    with open(readme_path, 'r', encoding='utf-8', errors='ignore') as f:
        print("\n--- README PREVIEW ---")
        print(f.read()[:1500])

# Inspect agent folder
agent_dir = os.path.join(base, "agent")
if os.path.exists(agent_dir):
    print("\n--- AGENT DIR CONTENTS ---")
    print(os.listdir(agent_dir))

