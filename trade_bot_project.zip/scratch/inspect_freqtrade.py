import os
import glob

base = os.path.join(os.getcwd(), "scratch", "extracted_repos")

def inspect_freqtrade():
    print("=== FREQTRADE ANALYSIS ===")
    ft_dir = os.path.join(base, "freqtrade-develop", "freqtrade-develop", "freqtrade")
    
    # 1. Protections
    prot_dir = os.path.join(ft_dir, "plugins", "pairlist")
    print("Pairlist plugins:", os.listdir(prot_dir) if os.path.exists(prot_dir) else "N/A")
    
    protection_dir = os.path.join(ft_dir, "plugins", "protection")
    print("Protection plugins:", os.listdir(protection_dir) if os.path.exists(protection_dir) else "N/A")
    
    # 2. Look for trailing stop and exit logic
    for root, dirs, files in os.walk(ft_dir):
        for f in files:
            if "edge" in f or "trailing" in f or "protection" in f or "stoploss" in f:
                print("Relevant FT file:", os.path.join(root, f))

inspect_freqtrade()

