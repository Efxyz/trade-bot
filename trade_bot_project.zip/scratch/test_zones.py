import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

# Temporarily test with zone_pct ceiling at 85% or fresh FVG allowed
for sym in ["BTCUSDT", "ETHUSDT", "NEARUSDT", "XRPUSDT", "BNBUSDT", "FETUSDT"]:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    
    # Calculate zone_pct
    lookback = c15m[-20:]
    sh = max(c["high"] for c in lookback)
    sl = min(c["low"] for c in lookback)
    cp = c15m[-1]["close"]
    zp = round(((cp - sl) / (sh - sl) * 100.0), 1) if (sh - sl) > 0 else 50.0
    
    print(f"{sym}: Price={cp}, 20-bar Swing High={sh}, Low={sl}, Zone={zp}%")

