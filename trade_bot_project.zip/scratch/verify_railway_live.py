import urllib.request
import json
import time

url = "https://trade-bot-production-f1b1.up.railway.app/"
print(f"Checking {url}...")

for attempt in range(5):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Antigravity-Monitor"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            print(f"Attempt {attempt+1}: Status {resp.status} OK!")
            break
    except Exception as e:
        print(f"Attempt {attempt+1}: {e}")
        time.sleep(4)

api_url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
try:
    req = urllib.request.Request(api_url, headers={"User-Agent": "Antigravity-Monitor"})
    with urllib.request.urlopen(req, timeout=12) as resp:
        data = json.loads(resp.read().decode('utf-8'))
        trades = data.get("trade_history", [])
        stats = data.get("stats", {})
        print(f"API Check: {len(trades)} trades in history, Total Win Rate: {stats.get('win_rate', 'N/A')}%")
except Exception as e:
    print(f"API Check failed: {e}")

