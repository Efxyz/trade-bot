with open("dashboard.py", "r", encoding="utf-8") as f:
    content = f.read()

import re
tables = re.findall(r"<table[^>]*>.*?</table>", content, re.DOTALL)
print(f"Total <table> elements: {len(tables)}")
for i, t in enumerate(tables):
    print(f"--- Table {i+1} ---")
    headers = re.findall(r"<th[^>]*>(.*?)</th>", t)
    print("Headers:", headers)
