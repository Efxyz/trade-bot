import os
from collections import defaultdict

root = os.getcwd()

# Folders to inspect
target_folders = ["agents", "core", "data/tools", "root"]

stats_by_category = defaultdict(lambda: {"files": 0, "total_lines": 0, "code_lines": 0, "comment_lines": 0, "blank_lines": 0})
file_details = []
ext_stats = defaultdict(lambda: {"count": 0, "lines": 0})

def analyze_file(filepath, category):
    ext = os.path.splitext(filepath)[1].lower()
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
    except Exception:
        return

    total = len(lines)
    code = 0
    comment = 0
    blank = 0
    in_multi_comment = False

    for l in lines:
        s = l.strip()
        if not s:
            blank += 1
        elif ext == '.py':
            if s.startswith('"""') or s.startswith("'''"):
                if s.count('"""') == 2 or s.count("'''") == 2:
                    comment += 1
                else:
                    in_multi_comment = not in_multi_comment
                    comment += 1
            elif in_multi_comment:
                comment += 1
                if '"""' in s or "'''" in s:
                    in_multi_comment = False
            elif s.startswith('#'):
                comment += 1
            else:
                code += 1
        elif ext in ('.js', '.css'):
            if s.startswith('/*') and '*/' in s:
                comment += 1
            elif s.startswith('/*'):
                in_multi_comment = True
                comment += 1
            elif in_multi_comment:
                comment += 1
                if '*/' in s:
                    in_multi_comment = False
            elif s.startswith('//'):
                comment += 1
            else:
                code += 1
        else:
            code += 1

    stats_by_category[category]["files"] += 1
    stats_by_category[category]["total_lines"] += total
    stats_by_category[category]["code_lines"] += code
    stats_by_category[category]["comment_lines"] += comment
    stats_by_category[category]["blank_lines"] += blank

    ext_stats[ext]["count"] += 1
    ext_stats[ext]["lines"] += total

    file_details.append({
        "path": os.path.relpath(filepath, root),
        "category": category,
        "total": total,
        "code": code,
        "comment": comment,
        "blank": blank
    })

# Scan root production files
root_prod_files = [
    "main.py", "dashboard.py", "config.py", "sync_to_github.py",
    "run_cloud_tunnel.py", "start_scanner.bat", "open_dashboard.bat",
    "requirements.txt", "Dockerfile", "docker-compose.yml", "Procfile", "railway.json", "README.md"
]
for rf in root_prod_files:
    p = os.path.join(root, rf)
    if os.path.exists(p):
        analyze_file(p, "Ana Sistem (Root)")

# Scan agents/
agents_dir = os.path.join(root, "agents")
if os.path.exists(agents_dir):
    for f in os.listdir(agents_dir):
        if f.endswith('.py'):
            analyze_file(os.path.join(agents_dir, f), "Ajanlar (agents/)")

# Scan core/
core_dir = os.path.join(root, "core")
if os.path.exists(core_dir):
    for f in os.listdir(core_dir):
        if f.endswith('.py'):
            analyze_file(os.path.join(core_dir, f), "Çekirdek Sistem (core/)")

# Scan data/tools/ (office_3d_engine.js etc.)
tools_dir = os.path.join(root, "data", "tools")
if os.path.exists(tools_dir):
    for f in os.listdir(tools_dir):
        if f.endswith(('.js', '.py')):
            analyze_file(os.path.join(tools_dir, f), "3D Grafik & Araçlar (data/tools/)")

# Scan .gemini/rules/
rules_dir = os.path.join(root, ".gemini", "rules")
if os.path.exists(rules_dir):
    for f in os.listdir(rules_dir):
        if f.endswith('.md'):
            analyze_file(os.path.join(rules_dir, f), "Kurallar & Bellek (.gemini/rules/)")

print("=== 1. MODÜL VE KATEGORİ BAZLI SATIR SAYILARI ===")
total_all = 0
code_all = 0
comment_all = 0
blank_all = 0
files_all = 0

for cat, s in stats_by_category.items():
    print(f"\n📁 {cat}:")
    print(f"   Dosya Sayısı: {s['files']}")
    print(f"   Toplam Satır: {s['total_lines']:,}")
    print(f"   Saf Kod Satırı: {s['code_lines']:,}")
    print(f"   Yorum / Dokümantasyon: {s['comment_lines']:,}")
    print(f"   Boşluk Satırı: {s['blank_lines']:,}")
    total_all += s['total_lines']
    code_all += s['code_lines']
    comment_all += s['comment_lines']
    blank_all += s['blank_lines']
    files_all += s['files']

print(f"\n==========================================")
print(f"🌟 GENEL PROJE TOPLAMI:")
print(f"   Toplam Dosya: {files_all}")
print(f"   Toplam Satır: {total_all:,}")
print(f"   Saf Kod Satırı (SLOC): {code_all:,}")
print(f"   Yorum & Strateji Açıklamaları: {comment_all:,}")
print(f"   Boş Satır: {blank_all:,}")
print(f"==========================================")

print("\n=== 2. UZANTI (DİL) BAZLI DAĞILIM ===")
for ext, st in sorted(ext_stats.items(), key=lambda x: x[1]['lines'], reverse=True):
    print(f"   {ext or 'uzantısız':<12}: {st['count']} dosya | {st['lines']:,} satır")

print("\n=== 3. EN BÜYÜK VE KRİTİK DOSYALAR (TOP 10) ===")
for fd in sorted(file_details, key=lambda x: x['total'], reverse=True)[:10]:
    print(f"   📄 {fd['path']:<35} -> {fd['total']:,} satır (Kod: {fd['code']:,} | Yorum: {fd['comment']:,})")

