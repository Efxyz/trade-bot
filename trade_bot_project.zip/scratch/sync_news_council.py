import sys
import os
import time

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from sync_to_github import sync_file_to_github

files_to_sync = [
    ("agents/news_agent.py", "feat(news): Add News Intelligence Council, coin-specific deep dive and multi-agency feeds"),
    ("agents/risk_agent.py", "feat(risk): Integrate News Council Veto shield and dynamic position size multiplier"),
    ("agents/ai_analyst_agent.py", "feat(ai-analyst): Inject News Council quotes into Investment Committee debate"),
    ("main.py", "feat(orchestrator): Integrate News Council Veto into candidate scanner"),
    ("fast_engine.py", "feat(fast-engine): Add News Council black swan veto shield to FAST 1m bot"),
    ("super_fast_engine.py", "feat(super-fast-engine): Add News Council black swan veto shield to SÜPER FAST bot")
]

print("=" * 80)
print("🚀 GİTHUB VE RAILWAY SENKRONİZASYONU: HABER KARARLANDIRMA KONSEYİ (PATRON ONAYLI)")
print("=" * 80)

success_count = 0
for rel_path, msg in files_to_sync:
    print(f"\n📤 Yükleniyor: {rel_path}...")
    ok = sync_file_to_github(rel_path, msg)
    if ok:
        success_count += 1
    else:
        print(f"❌ {rel_path} yüklenemedi!")
    time.sleep(1.0)

print("\n" + "=" * 80)
print(f"🏁 SENKRONİZASYON TAMAMLANDI: {success_count}/{len(files_to_sync)} dosya başarıyla aktarıldı.")
print("⚡ Railway CI/CD boru hattı otomatik olarak tetiklendi.")
print("=" * 80)
