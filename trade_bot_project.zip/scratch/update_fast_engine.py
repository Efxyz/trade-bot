with open("fast_engine.py", "r", encoding="utf-8") as f:
    text = f.read()

# Import new constants
old_imp = """    FAST_CIRCUIT_BREAKER_ENABLED,
    FAST_DAILY_MAX_DRAWDOWN_USDT,"""

new_imp = """    FAST_CIRCUIT_BREAKER_ENABLED,
    FAST_DAILY_MAX_DRAWDOWN_USDT,
    FAST_MAX_DAILY_TRADES,
    FAST_MAX_DAILY_FEE_USDT,"""

text = text.replace(old_imp, new_imp)

# In run_cycle:
old_cycle = """        # 2. Günlük Devre Kesici (Circuit Breaker) Kontrolü
        if FAST_CIRCUIT_BREAKER_ENABLED:
            fast_stats = get_fast_performance_stats() or {}
            today_dollar_gain = float(fast_stats.get("today_dollar_gain") or 0.0)
            if today_dollar_gain <= -FAST_DAILY_MAX_DRAWDOWN_USDT:
                add_fast_scanner_log_db("ALL", "BLOCKED", f"FAST Günlük Devre Kesici (-${abs(today_dollar_gain):.2f} >= -${FAST_DAILY_MAX_DRAWDOWN_USDT})")
                return"""

new_cycle = """        # 2. Günlük Devre Kesici & Sert İşlem/Komisyon Kotası (Anti-Overtrading Guard)
        fast_stats = get_fast_performance_stats() or {}
        today_trades = int(fast_stats.get("today_trades") or 0)
        today_dollar_gain = float(fast_stats.get("today_dollar_gain") or 0.0)
        today_fee_pct = float(fast_stats.get("today_fee_pct") or 0.0)
        today_fee_usd = (today_fee_pct / 100.0) * FAST_ALLOCATED_MARGIN_PER_TRADE

        # A) Sert Günlük İşlem Kotası (Maks 15 İşlem)
        if today_trades >= FAST_MAX_DAILY_TRADES:
            add_fast_scanner_log_db("ALL", "BLOCKED", f"⚡ FAST Günlük İşlem Kotası ({today_trades}/{FAST_MAX_DAILY_TRADES}) Doldu. Komisyon Koruma Kilidi Aktif.")
            return

        # B) Günlük Komisyon Tavanı (Maks $15)
        if today_fee_usd >= FAST_MAX_DAILY_FEE_USDT:
            add_fast_scanner_log_db("ALL", "BLOCKED", f"⚡ FAST Günlük Komisyon Tavanı (${today_fee_usd:.2f} >= ${FAST_MAX_DAILY_FEE_USDT}) Aşıldı. Komisyon Kilidi.")
            return

        # C) Günlük Zarar Limiti Devre Kesici
        if FAST_CIRCUIT_BREAKER_ENABLED and today_dollar_gain <= -FAST_DAILY_MAX_DRAWDOWN_USDT:
            add_fast_scanner_log_db("ALL", "BLOCKED", f"FAST Günlük Devre Kesici (-${abs(today_dollar_gain):.2f} >= -${FAST_DAILY_MAX_DRAWDOWN_USDT})")
            return"""

assert old_imp in text, "old_imp not found"
assert old_cycle in text, "old_cycle not found"

text = text.replace(old_imp, new_imp)
text = text.replace(old_cycle, new_cycle)

with open("fast_engine.py", "w", encoding="utf-8") as f:
    f.write(text)
print("fast_engine.py updated successfully!")

