with open("core/database.py", "r", encoding="utf-8") as f:
    text = f.read()

# For fast:
old_fast = """            SELECT 
                COUNT(*) as today_trades,
                SUM(CASE WHEN simulated_pnl_pct > 0 THEN 1 ELSE 0 END) as today_wins,
                SUM(CASE WHEN simulated_pnl_pct < 0 THEN 1 ELSE 0 END) as today_losses,
                SUM(simulated_pnl_pct) as today_net_pnl_pct,
                SUM(COALESCE(allocated_margin_usdt, 75.0) * (simulated_pnl_pct / 100.0)) as today_dollar_gain
            FROM fast_signals"""

new_fast = """            SELECT 
                COUNT(*) as today_trades,
                SUM(CASE WHEN simulated_pnl_pct > 0 THEN 1 ELSE 0 END) as today_wins,
                SUM(CASE WHEN simulated_pnl_pct < 0 THEN 1 ELSE 0 END) as today_losses,
                SUM(simulated_pnl_pct) as today_net_pnl_pct,
                SUM(fee_pct) as today_fee_pct,
                SUM(COALESCE(allocated_margin_usdt, 75.0) * (simulated_pnl_pct / 100.0)) as today_dollar_gain
            FROM fast_signals"""

# For super_fast:
old_sf = """            SELECT 
                COUNT(*) as today_trades,
                SUM(CASE WHEN simulated_pnl_pct > 0 THEN 1 ELSE 0 END) as today_wins,
                SUM(CASE WHEN simulated_pnl_pct < 0 THEN 1 ELSE 0 END) as today_losses,
                SUM(simulated_pnl_pct) as today_net_pnl_pct,
                SUM(COALESCE(allocated_margin_usdt, 35.0) * (simulated_pnl_pct / 100.0)) as today_dollar_gain
            FROM super_fast_signals"""

new_sf = """            SELECT 
                COUNT(*) as today_trades,
                SUM(CASE WHEN simulated_pnl_pct > 0 THEN 1 ELSE 0 END) as today_wins,
                SUM(CASE WHEN simulated_pnl_pct < 0 THEN 1 ELSE 0 END) as today_losses,
                SUM(simulated_pnl_pct) as today_net_pnl_pct,
                SUM(fee_pct) as today_fee_pct,
                SUM(COALESCE(allocated_margin_usdt, 35.0) * (simulated_pnl_pct / 100.0)) as today_dollar_gain
            FROM super_fast_signals"""

assert old_fast in text, "old_fast not found"
assert old_sf in text, "old_sf not found"

text = text.replace(old_fast, new_fast)
text = text.replace(old_sf, new_sf)

# Add row["today_fee_pct"]
text = text.replace(
    'row["today_losses"] = t_losses\n        row["today_net_pnl_pct"] = t_pct',
    'row["today_losses"] = t_losses\n        row["today_fee_pct"] = round(t_row.get("today_fee_pct") or 0.0, 2)\n        row["today_net_pnl_pct"] = t_pct'
)

text = text.replace(
    'row["today_losses"] = today_row.get("today_losses") or 0\n        row["today_net_pnl_pct"] = round(today_row.get("today_net_pnl_pct") or 0.0, 2)',
    'row["today_losses"] = today_row.get("today_losses") or 0\n        row["today_fee_pct"] = round(today_row.get("today_fee_pct") or 0.0, 2)\n        row["today_net_pnl_pct"] = round(today_row.get("today_net_pnl_pct") or 0.0, 2)'
)

with open("core/database.py", "w", encoding="utf-8") as f:
    f.write(text)
print("core/database.py updated successfully!")

