import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "day-trader-skill-main", "day-trader-skill-main")

print("=== DAY TRADER SKILL SCAN ===")
skills = [d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d))]
print("Skills found:", skills)

for s in ["trader-entry", "trader-exit", "trader-risk", "trader-budget"]:
    sp = os.path.join(base, s, "SKILL.md")
    if os.path.exists(sp):
        print(f"\n--- {s}/SKILL.md ---")
        with open(sp, 'r', encoding='utf-8') as fp:
            print(fp.read()[:1200])

