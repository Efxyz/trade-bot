import os
import sys

root = os.getcwd()

root_files = []
root_dirs = []

for item in os.listdir(root):
    p = os.path.join(root, item)
    if os.path.isdir(p):
        root_dirs.append((item, len(os.listdir(p))))
    else:
        size = os.path.getsize(p)
        root_files.append((item, size))

print("=== ROOT DIRECTORIES ===")
for d, count in sorted(root_dirs):
    print(f"📁 {d}/ ({count} items)")

print("\n=== ROOT FILES ===")
for f, sz in sorted(root_files, key=lambda x: x[0].lower()):
    sz_str = f"{sz/1024:.1f} KB" if sz > 1024 else f"{sz} B"
    print(f"📄 {f:<35} {sz_str:>10}")

