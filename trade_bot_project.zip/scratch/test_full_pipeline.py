import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.risk_agent import RiskOfficerAgent
from agents.quant_simulation_agent import QuantSimulationAgent
from agents.ai_analyst_agent import AIAnalystAgent

client = BinanceFuturesClient()
ta_agent = TechnicalAnalysisAgent()
risk_agent = RiskOfficerAgent()
quant_agent = QuantSimulationAgent()
ai_agent = AIAnalystAgent()

btc_regime = client.get_btc_regime()
ticker = client.get_24hr_tickers().get("BTCUSDT", {})
funding_data = client.get_funding_rate("BTCUSDT")
book_ticker = client.get_book_ticker("BTCUSDT")

c15m = client.get_klines("BTCUSDT", interval="15m", limit=60)
c1h = client.get_klines("BTCUSDT", interval="1h", limit=50)

print("1. TA Analizi Başlatılıyor...")
setup, reason = ta_agent.analyze_setup("BTCUSDT", c15m, c1h)
print(f"   TA Setup: {bool(setup)}")
if not setup:
    print(f"   TA Red Nedeni: {reason}")
    sys.exit(0)

print(f"   Setup Yön: {setup['direction']} | Skor: {setup['confluence_score']}/100")

print("2. Risk Masası Analizi...")
is_approved, risk_report = risk_agent.evaluate(
    setup, None, ticker, btc_regime,
    funding_data=funding_data,
    book_ticker=book_ticker,
    active_signals=[],
    current_equity=1057.24
)
print(f"   Risk Onayı: {is_approved} ({risk_report.get('reason', 'OK')})")
if not is_approved:
    sys.exit(0)

print("3. Kuant Monte Carlo Simülasyonu...")
sim = quant_agent.simulate_setup("BTCUSDT", setup, c15m, num_simulations=10000)
print(f"   Win Prob: {sim.get('win_probability_pct')}% | Expected R: {sim.get('expected_return_r')}R | Approved: {sim.get('is_approved')}")
if not sim.get('is_approved'):
    print(f"   Veto Nedeni: {sim.get('argument')}")
    sys.exit(0)

print("4. AI Komite Tartışması...")
ai_verdict = ai_agent.evaluate_setup(
    setup, risk_report, None, btc_regime, ticker, funding_data, quant_sim=sim
)
print(f"   AI Onayı: {ai_verdict.get('ai_approved')} | Güven: {ai_verdict.get('ai_confidence')}/10")
print(f"   Karar Özeti: {ai_verdict.get('summary')}")

print("\n🎉 TÜM PİPELİNE BAŞARIYLA GEÇTİ! İŞLEM AÇILABİLİR DURUMDA!")
