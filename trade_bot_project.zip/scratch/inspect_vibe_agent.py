import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "Vibe-Trading-main", "Vibe-Trading-main", "agent")

print("--- agent/skills ---")
skills_dir = os.path.join(base, "skills")
if os.path.exists(skills_dir):
    for root, dirs, files in os.walk(skills_dir):
        for f in files:
            if f.endswith('.md') or f.endswith('.py'):
                rel = os.path.relpath(os.path.join(root, f), skills_dir)
                print("Skill file:", rel)

print("\n--- agent/src ---")
src_dir = os.path.join(base, "src")
if os.path.exists(src_dir):
    for root, dirs, files in os.walk(src_dir):
        for f in files:
            if f.endswith('.py'):
                rel = os.path.relpath(os.path.join(root, f), src_dir)
                print("Src file:", rel)

