import urllib.request
import json

urls = [
    "https://trade-bot-production-f1b1.up.railway.app/api/trades",
    "https://trade-bot-production-f1b1.up.railway.app/api/status",
    "https://trade-bot-production-f1b1.up.railway.app/api/performance",
    "https://trade-bot-production-f1b1.up.railway.app/api/history"
]

for url in urls:
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
            print(f"URL: {url} -> SUCCESS! Keys / Sample:")
            if isinstance(data, list):
                print(f"List length: {len(data)}")
                if len(data) > 0:
                    print("First item:", data[0])
            elif isinstance(data, dict):
                print("Dict keys:", list(data.keys()))
                for k, v in data.items():
                    if isinstance(v, list) and len(v) > 0:
                        print(f"  {k} (len {len(v)}): first item = {v[0]}")
                    else:
                        print(f"  {k}: {str(v)[:100]}")
    except Exception as e:
        print(f"URL: {url} -> FAILED: {e}")

