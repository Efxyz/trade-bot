import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.fast_ta_agent import FastTechnicalAnalysisAgent
from agents.super_fast_ta_agent import SuperFastTechnicalAnalysisAgent

def test_all_bots():
    print("=" * 80)
    print("🚀 3-BOT KURUMSAL TEKNİK & GRAFİK ANALİZ MOTORU KAPSAMLI TESTİ")
    print("=" * 80)

    client = BinanceFuturesClient()
    std_agent = TechnicalAnalysisAgent()
    fast_agent = FastTechnicalAnalysisAgent()
    super_agent = SuperFastTechnicalAnalysisAgent()

    test_symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT"]

    for symbol in test_symbols:
        print(f"\n" + "-" * 70)
        print(f"📊 SEMBOL: {symbol}")
        print("-" * 70)

        # 1. STANDART BOT TESTİ (15m + 1h + 4h)
        print(f"--- [1] 15m STANDART BOT (Trend Kanalları, Volume Profile, Camarilla, Divergence, ADX) ---")
        candles_15m = client.get_klines(symbol, "15m", limit=60)
        candles_1h = client.get_klines(symbol, "1h", limit=30)

        setup_std, reason_std = std_agent.analyze_setup(symbol, candles_15m, candles_1h)
        if setup_std:
            print(f"  ✅ ONAYLANDI: {setup_std['direction']} | Skor: {setup_std['confluence_score']}/100 | Grade: {setup_std['risk_grade']}")
            print(f"     Giriş: {setup_std['current_price']} | TP1: {setup_std['take_profit_1']} | SL: {setup_std['stop_loss']} (Risk/Ödül: {setup_std.get('risk_reward')})")
            if "lr_channel" in setup_std and setup_std["lr_channel"]:
                lr = setup_std["lr_channel"]
                print(f"     📐 LR Kanal: Eğim: %{lr['slope_pct']:.2f} ({lr['trend_state']}) | Konum: %{lr['pos_pct']:.1f} | Alt/Üst: {lr['lower_band']:.2f} / {lr['upper_band']:.2f}")
            if "volume_profile" in setup_std and setup_std["volume_profile"]:
                vp = setup_std["volume_profile"]
                print(f"     📊 Volume Profile: POC: {vp['poc']:.2f} | VAH: {vp['vah']:.2f} | VAL: {vp['val']:.2f} | POC Mesafe: %{vp['dist_poc_pct']:.2f}")
            if "camarilla" in setup_std and setup_std["camarilla"]:
                cam = setup_std["camarilla"]
                print(f"     🛡️ Camarilla: PP: {cam['pp']:.2f} | R4: {cam['r4']:.2f} | R3: {cam['r3']:.2f} | S3: {cam['s3']:.2f} | S4: {cam['s4']:.2f}")
            if "adx_data" in setup_std and setup_std["adx_data"]:
                adx = setup_std["adx_data"]
                print(f"     📈 ADX Trend Gücü: {adx['adx']:.1f} ({adx['trend_strength']}) | DI+: {adx['plus_di']:.1f} | DI-: {adx['minus_di']:.1f}")
            if "rsi_divergence" in setup_std and setup_std["rsi_divergence"]:
                div = setup_std["rsi_divergence"]
                print(f"     🎯 RSI Divergence: {div['type']} (Güç: {div['strength']})")
            print(f"     Gerekçeler: {setup_std.get('ta_reasons')}")
        else:
            print(f"  ⏸️ BEKLEMEDE / FİLTRELENDİ: {reason_std}")

        # 2. FAST BOT TESTİ (1m + 5m)
        print(f"\n--- [2] FAST BOT (1m LR Kanalı & Volume Profile) ---")
        candles_1m = client.get_klines(symbol, "1m", limit=50)
        candles_5m = client.get_klines(symbol, "5m", limit=30)
        setup_fast, reason_fast = fast_agent.analyze_fast_setup(symbol, candles_1m, candles_5m)
        if setup_fast:
            print(f"  ✅ ONAYLANDI: {setup_fast['direction']} | Skor: {setup_fast['confluence_score']}/100")
            print(f"     Giriş: {setup_fast['current_price']} | TP: {setup_fast['take_profit_1']} | SL: {setup_fast['stop_loss']}")
            print(f"     Gerekçeler: {setup_fast.get('ta_reasons')}")
        else:
            print(f"  ⏸️ BEKLEMEDE: {reason_fast}")

        # 3. SÜPER FAST BOT TESTİ (Mikro 1m + Tick)
        print(f"\n--- [3] SÜPER FAST BOT (Mikro LR Kanalı & Camarilla Intraday) ---")
        book_ticker = client.get_book_ticker(symbol)
        recent_prices = [float(c["close"]) for c in candles_1m[-5:]] if candles_1m else []
        setup_super, reason_super = super_agent.analyze_super_fast_setup(symbol, recent_prices, candles_1m, book_ticker)
        if setup_super:
            print(f"  ✅ ONAYLANDI: {setup_super['direction']} | Skor: {setup_super['confluence_score']}/100")
            print(f"     Giriş: {setup_super['current_price']} | TP: {setup_super['take_profit_1']} | SL: {setup_super['stop_loss']}")
            print(f"     Gerekçeler: {setup_super.get('ta_reasons')}")
        else:
            print(f"  ⏸️ BEKLEMEDE: {reason_super}")

    print("\n" + "=" * 80)
    print("🏁 TEST TAMAMLANDI")
    print("=" * 80)

if __name__ == "__main__":
    test_all_bots()
