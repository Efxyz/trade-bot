import sys, os
sys.path.insert(0, os.getcwd())
from sync_to_github import sync_file_to_github

files_to_sync = [
    ("config.py", "Feat(config): Freqtrade Side Guard, Ladder Step 1 BE+ (0.35%), Early Invalidation (20m/0.35%)"),
    ("core/quant_knowledge_base.py", "Feat(core): Master Quant & AI Trading Knowledge Base from 6 GitHub repos"),
    ("core/database.py", "Feat(db): Add check_side_stoploss_guard for direction-specific loss prevention"),
    ("agents/risk_agent.py", "Feat(risk): Integrate Freqtrade Side-Specific Stoploss Guard into RiskOfficer"),
    ("agents/ta_agent.py", "Feat(ta): Add pre-scan Side Stoploss Guard check to halt losing direction"),
    ("agents/tracker_agent.py", "Feat(tracker): Apply BE+ lock on Step 1 and 20m Early Invalidation")
]

print("Starting sync of enhanced files to GitHub...")
all_ok = True
for rel_path, commit_msg in files_to_sync:
    print(f"\nSyncing {rel_path}...")
    success = sync_file_to_github(rel_path, commit_msg)
    if not success:
        all_ok = False
        print(f"Failed to sync {rel_path}")

if all_ok:
    print("\n🎉 ALL 6 PRODUCTION FILES SUCCESSFULLY SYNCED TO GITHUB!")
    print("Railway is now building and deploying the updated bot!")
else:
    print("\n⚠️ Some files failed to sync. Check output above.")

