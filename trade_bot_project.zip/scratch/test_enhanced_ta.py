import sys
from pathlib import Path
sys.path.insert(0, r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
ta = TechnicalAnalysisAgent()

symbols = ["ETHUSDT", "BTCUSDT", "SOLUSDT", "DOGEUSDT", "ZECUSDT"]

print("=== YENİ GELİŞMİŞ TA MOTORU CANLI TESTİ ===")
for sym in symbols:
    c15m = client.get_klines(sym, interval="15m", limit=80)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    setup, reason = ta.analyze_setup(sym, c15m, c1h)
    
    print(f"\n🪙 {sym}:")
    if setup:
        print(f"  ✅ ONAYLANDI: {setup['direction']} (Skor: {setup['confluence_score']}/100, Kaldıraç: {setup['leverage']}x)")
        print(f"  💵 Giriş: ${setup['actual_entry_price']} | SL: ${setup['stop_loss']} (-%{setup['sl_pct']}) | TP: ${setup['take_profit_1']} (+%{setup['tp1_pct']}) | R:R={setup['risk_reward']}")
        print(f"  📊 Gerekçeler: {setup['ta_reasons']}")
        lr = setup['indicators']['lr_channel']
        vp = setup['indicators']['volume_profile']
        cam = setup['indicators']['camarilla']
        adx = setup['indicators']['adx_data']
        print(f"  📈 LR Kanal: {lr['trend']} (Kanal Pozisyonu: %{lr['position_pct']}, Genişlik: %{lr['channel_width_pct']})")
        print(f"  🎯 Volume Profile: POC=${vp['poc']}, VAH=${vp['vah']}, VAL=${vp['val']} (Durum: {vp['interaction']})")
        print(f"  🪜 Camarilla: H4=${cam.get('r4_breakout')}, L4=${cam.get('s4_breakdown')}")
        print(f"  🔥 ADX Gücü: {adx['adx']} ({adx['trend_strength']})")
    else:
        clean_r = reason.replace("📌", "").replace("⛔", "").replace("🎯", "").replace("<strong>", "").replace("</strong>", "").replace("<br>", "\n    ")
        print(f"  ❌ REDDEDİLDİ:\n    {clean_r}")
