def format_turkey_time_py(time_str):
    if not time_str:
        return ""
    s = str(time_str).strip()
    import re
    from datetime import datetime, timedelta
    
    # Full datetime YYYY-MM-DD HH:MM:SS
    m = re.match(r"^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}(?::\d{2})?)", s)
    if m:
        date_part = m.group(1)
        time_part = m.group(2)
        if len(time_part) == 5:
            time_part += ":00"
        dt = datetime.strptime(f"{date_part} {time_part}", "%Y-%m-%d %H:%M:%S")
        tr_dt = dt + timedelta(hours=3)
        return tr_dt.strftime("%Y-%m-%d %H:%M:%S")
    
    # Time only HH:MM:SS or HH:MM
    m_time = re.match(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$", s)
    if m_time:
        hh = int(m_time.group(1))
        mm = int(m_time.group(2))
        ss = int(m_time.group(3)) if m_time.group(3) else None
        new_hh = (hh + 3) % 24
        if ss is not None:
            return f"{new_hh:02d}:{mm:02d}:{ss:02d}"
        return f"{new_hh:02d}:{mm:02d}"
    
    return s

# Test cases
test_cases = [
    "2026-11-15 13:27:55",
    "2026-11-15 22:30:00",
    "13:38:43",
    "23:15:00",
    "10:31",
    "",
    None,
    "Haber metni"
]

for t in test_cases:
    print(f"{repr(t)} -> {repr(format_turkey_time_py(t))}")
