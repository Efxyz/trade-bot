import json
import os
import sys
import time
from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
os.chdir(str(project_root))

from config import (
    BINANCE_ROUNDTRIP_FEE_PCT,
    ESTIMATED_SLIPPAGE_PCT,
    EXCLUDED_SYMBOLS_BLACKLIST,
    LADDER_DYNAMIC_CHANNEL_PCT,
    LADDER_STEPS,
    LEVERAGE_HIGH,
    LEVERAGE_STANDARD,
    MAX_CONCURRENT_TRADES,
    MAX_HOLD_MINUTES,
    MAX_POSITIONS_PER_DIRECTION,
    MAX_SCALP_SL_PCT,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_CONFLUENCE_SCORE,
    MIN_RR_RATIO,
    MIN_SCALP_SL_PCT,
    PORTFOLIO_EQUITY_USDT,
    POST_LOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
)
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

from benchmark_precompute import build_full_1h_candles

coin_data = {}
all_ts = set()
for sym, c_list in raw_cache.items():
    if sym in EXCLUDED_SYMBOLS_BLACKLIST:
        continue
    c_1h = build_full_1h_candles(c_list)
    h_close_ts = [c['timestamp'] + 3600*1000 for c in c_1h]
    coin_data[sym] = {
        'list_15m': c_list,
        'by_ts': {x['timestamp']: x for x in c_list},
        'idx_by_ts': {x['timestamp']: i for i, x in enumerate(c_list)},
        'list_1h': c_1h,
        'h_close_ts': h_close_ts
    }
    all_ts.update(x['timestamp'] for x in c_list)

sorted_ts = sorted(list(all_ts))
ta_agent = TechnicalAnalysisAgent()
quant_sim = QuantSimulationAgent(default_simulations=1000)

print(f"Veriler hazır: {len(coin_data)} parite, {len(sorted_ts)} periyot.", flush=True)

print("2. Sinyaller Önceden Taranıyor (TA Confluence Engine)...", flush=True)
signals_by_ts = {ts: [] for ts in sorted_ts}
for sym, d in coin_data.items():
    c15 = d['list_15m']
    c1h = d['list_1h']
    h_close_ts = d['h_close_ts']
    for idx, c in enumerate(c15):
        if idx < 45:
            continue
        ts = c['timestamp']
        win_15m = c15[max(0, idx-59) : idx+1]
        h_end_idx = bisect_right(h_close_ts, ts)
        win_1h = c1h[max(0, h_end_idx-35) : h_end_idx] if h_end_idx >= 15 else None
        
        setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
        if setup:
            signals_by_ts[ts].append((sym, setup))

print(f"✓ Sinyaller hazır. Simülasyon motoru başlatılıyor...", flush=True)

def simulate_engine(
    label: str,
    use_side_guard: bool = True,
    early_inv_mode: str = "OFF", # "OFF", "TIGHT_20M", "CALIBRATED_60M"
    ladder_mode: str = "CURRENT"  # "CURRENT", "OLD"
):
    initial_equity = 1000.0
    equity = initial_equity
    max_concurrent = 5
    max_per_dir = 3
    target_risk_usd = 20.0

    if ladder_mode == "CURRENT":
        # Yeni Kalibre Edilmiş Merdiven
        steps = [
            {"step": 1, "trigger_raw_pct": 0.40, "lock_raw_pct": 0.15, "name": "Basamak 1 (BE+ %0.15)"},
            {"step": 2, "trigger_raw_pct": 0.70, "lock_raw_pct": 0.35, "name": "Basamak 2 (%0.35)"},
            {"step": 3, "trigger_raw_pct": 1.15, "lock_raw_pct": 0.75, "name": "Basamak 3 (%0.75)"},
            {"step": 4, "trigger_raw_pct": 1.65, "lock_raw_pct": 1.30, "name": "Basamak 4 (%1.30)"}
        ]
    else:
        steps = [
            {"step": 1, "trigger_raw_pct": 0.60, "lock_raw_pct": 0.15, "name": "Eski Basamak 1"},
            {"step": 2, "trigger_raw_pct": 1.00, "lock_raw_pct": 0.50, "name": "Eski Basamak 2"}
        ]

    active_trades = []
    completed_trades = []
    cooldown_until = {}
    side_consecutive_losses = {"LONG": 0, "SHORT": 0}
    side_locked_until = {"LONG": 0, "SHORT": 0}
    equity_curve = []

    for ts in sorted_ts:
        dt = datetime.fromtimestamp(ts / 1000, tz=timezone.utc)
        current_time_str = dt.strftime("%Y-%m-%d %H:%M")

        # 1. Açık İşlemleri Takip Et
        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            c_info = coin_data.get(sym, {}).get('by_ts', {}).get(ts)
            if not c_info:
                still_active.append(trade)
                continue

            high_p = c_info['high']
            low_p = c_info['low']
            close_p = c_info['close']

            direction = trade['direction']
            entry_p = trade['entry_price']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            lev = trade['leverage']

            trade['bars_held'] += 1
            bars_held = trade['bars_held']
            minutes_open = bars_held * 15

            trade['highest_price'] = max(trade.get('highest_price', entry_p), high_p)
            trade['lowest_price'] = min(trade.get('lowest_price', entry_p), low_p)

            closed = False
            exit_price = entry_p
            exit_reason = ""

            if direction == "LONG":
                peak_gain_pct = ((trade['highest_price'] - entry_p) / entry_p) * 100.0

                for step in steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['highest_price'] * (1.0 - LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK" if trade['ladder_level'] > 0 else "HIT_SL"
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif early_inv_mode == "TIGHT_20M" and trade['ladder_level'] == 0 and minutes_open >= 20:
                    raw_c = (close_p - entry_p) / entry_p
                    if raw_c <= -0.0035:
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif early_inv_mode == "CALIBRATED_60M" and trade['ladder_level'] == 0 and minutes_open >= 60:
                    raw_c = (close_p - entry_p) / entry_p
                    if raw_c <= -0.0070:
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (close_p - entry_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            else: # SHORT
                peak_gain_pct = ((entry_p - trade['lowest_price']) / entry_p) * 100.0

                for step in steps:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if peak_gain_pct >= 1.05:
                    ch_sl = trade['lowest_price'] * (1.0 + LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK" if trade['ladder_level'] > 0 else "HIT_SL"
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif early_inv_mode == "TIGHT_20M" and trade['ladder_level'] == 0 and minutes_open >= 20:
                    raw_c = (entry_p - close_p) / entry_p
                    if raw_c <= -0.0035:
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif early_inv_mode == "CALIBRATED_60M" and trade['ladder_level'] == 0 and minutes_open >= 60:
                    raw_c = (entry_p - close_p) / entry_p
                    if raw_c <= -0.0070:
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (entry_p - close_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = (BINANCE_ROUNDTRIP_FEE_PCT + ESTIMATED_SLIPPAGE_PCT) * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                equity_curve.append((current_time_str, round(equity, 2)))
                completed_trades.append({
                    'symbol': sym,
                    'direction': direction,
                    'dollar_gain': round(dollar_gain, 2),
                    'status': exit_reason,
                    'ladder_level': trade['ladder_level']
                })
                cooldown_until[sym] = ts + (POST_LOSS_COOLDOWN_MINUTES * 60 * 1000)

                if dollar_gain < 0:
                    side_consecutive_losses[direction] += 1
                    if use_side_guard and side_consecutive_losses[direction] >= SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES:
                        side_locked_until[direction] = ts + (SIDE_STOPLOSS_COOLDOWN_MINUTES * 60 * 1000)
                else:
                    side_consecutive_losses[direction] = 0
            else:
                still_active.append(trade)

        active_trades = still_active

        if len(active_trades) >= max_concurrent:
            continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        for sym, setup in signals_by_ts.get(ts, []):
            if len(active_trades) >= max_concurrent:
                break
            if sym in active_syms or ts < cooldown_until.get(sym, 0):
                continue

            direction = setup['direction']

            if use_side_guard and ts < side_locked_until.get(direction, 0):
                continue
            if direction == 'LONG' and long_count >= max_per_dir:
                continue
            if direction == 'SHORT' and short_count >= max_per_dir:
                continue

            sl_pct = setup['sl_pct']
            tp_pct = setup['tp1_pct']
            score = setup['confluence_score']

            is_sniper = (score >= 85 and sl_pct <= MAX_SL_PCT_20X)
            leverage = 20 if is_sniper else 10
            max_sl_allowed = MAX_SL_PCT_20X if leverage == 20 else MAX_SL_PCT_10X

            if sl_pct > max_sl_allowed or sl_pct <= 0:
                continue

            rr = tp_pct / sl_pct if sl_pct > 0 else 0
            if rr < MIN_RR_RATIO:
                continue

            allocated_margin = min(target_risk_usd / (sl_pct / 100.0 * leverage), 200.0)
            allocated_margin = max(allocated_margin, 50.0)

            active_trades.append({
                'symbol': sym,
                'direction': direction,
                'leverage': leverage,
                'entry_price': setup['current_price'],
                'current_sl': setup['stop_loss'],
                'take_profit': setup['take_profit_1'],
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'margin': allocated_margin,
                'ladder_level': 0,
                'bars_held': 0,
                'highest_price': setup['current_price'],
                'lowest_price': setup['current_price']
            })
            if direction == 'LONG':
                long_count += 1
            else:
                short_count += 1

    wins = [t for t in completed_trades if t['dollar_gain'] > 0]
    losses = [t for t in completed_trades if t['dollar_gain'] < 0]
    bes = [t for t in completed_trades if t['dollar_gain'] == 0]
    total_trades = len(completed_trades)
    win_rate = len(wins) / total_trades * 100 if total_trades > 0 else 0
    net_pnl = sum(t['dollar_gain'] for t in completed_trades)
    exits = Counter(t['status'] for t in completed_trades)

    print(f"\n=======================================================")
    print(f"📊 {label}")
    print(f"=======================================================")
    print(f"💰 Başlangıç: ${initial_equity:.2f} | Bitiş: ${equity:.2f} | Net PnL: ${net_pnl:+.2f} ({net_pnl/10:.1f}%)")
    print(f"🎯 İşlem: {total_trades} (Win: {len(wins)}, Loss: {len(losses)}, BE: {len(bes)}) | WinRate: %{win_rate:.1f}")
    print(f"🚪 Çıkışlar: {dict(exits)}")
    return {
        'net_pnl': net_pnl,
        'win_rate': win_rate,
        'wins': len(wins),
        'losses': len(losses),
        'total': total_trades,
        'exits': dict(exits)
    }

# Test 1: Sıkı 20m Erken Kes + Freqtrade Guard + Yeni Merdiven
simulate_engine("1. Sıkı 20m Erken Kes (Mevcut Ayar)", use_side_guard=True, early_inv_mode="TIGHT_20M", ladder_mode="CURRENT")

# Test 2: Erken Kes KAPALI (Nefes Alan Pozisyonlar) + Freqtrade Guard + Yeni Merdiven
simulate_engine("2. Erken Kes KAPALI + Freqtrade Guard + Yeni Merdiven", use_side_guard=True, early_inv_mode="OFF", ladder_mode="CURRENT")

# Test 3: Erken Kes KAPALI + Freqtrade Guard YOK + Eski Merdiven (Tam Eski Bot)
simulate_engine("3. Eski Bot (Freqtrade Guard YOK + Eski Merdiven)", use_side_guard=False, early_inv_mode="OFF", ladder_mode="OLD")
