import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

for sym in ["BTCUSDT", "ETHUSDT", "NEARUSDT", "XRPUSDT", "LINKUSDT", "BNBUSDT", "FETUSDT"]:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    setup, reason = agent.analyze_setup(sym, c15m, c1h)
    
    is_setup = bool(setup)
    direction = setup["direction"] if setup else "REJECTED"
    score = setup["confluence_score"] if setup else "N/A"
    print(f"{sym:<10}: Setup={str(is_setup):<5} | Direction={direction:<6} | Score={str(score):<4} | Reason={reason[:90]}")
