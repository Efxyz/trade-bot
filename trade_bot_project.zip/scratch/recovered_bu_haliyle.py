import os
import sys
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
sys.path.insert(0, r"C:\Users\isiks\.gemini\antigravity\brain\a2f493b1-6bd2-4f3b-a3f9-f21e7725bbd5\scratch")
os.chdir(str(project_root))

import json
import time
from datetime import datetime, timezone
from typing import List, Dict, Tuple
from collections import defaultdict, Counter

from config import (
    LADDER_STEPS,
    MIN_CONFLUENCE_SCORE,
    LEVERAGE_STANDARD,
    LEVERAGE_HIGH,
    BINANCE_ROUNDTRIP_FEE_PCT,
    ESTIMATED_SLIPPAGE_PCT,
    MAX_HOLD_MINUTES,
    MAX_SCALP_SL_PCT,
    MIN_SCALP_SL_PCT,
    DAILY_BASE_MAX_TRADES,
    PROFIT_STEP_FOR_BONUS_TRADES,
    BONUS_TRADES_PER_STEP,
    DAILY_MAX_DRAWDOWN_USDT,
    DAILY_TRAILING_PROFIT_LOCK_ENABLED
)
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent
from test_90d_fetch import fetch_90d_candles
from run_realistic_sim import check_btc_shield
from run_full_updated_month_test import build_1h_candles_from_15m

COINS_30D = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT",
    "DOGEUSDT", "1000PEPEUSDT", "WIFUSDT",
    "SUIUSDT", "APTUSDT", "ARBUSDT", "OPUSDT", "NEARUSDT", "AVAXUSDT",
    "FETUSDT", "RENDERUSDT", "TAOUSDT",
    "LINKUSDT", "INJUSDT", "TIAUSDT"
]

def run_simulation():
    print("=" * 70)
    print("🚀 GÜNCEL MOTOR İLE GEÇMİŞ 30 GÜN (1 AY) BÜYÜK ANALİZİ BAŞLIYOR")
    print("=" * 70)
    print("Aktif Kalkanlar ve Özellikler:")
    print(" • 20x Sniper Girişleri (Skor >= 85 ve SL <= %1.00)")
    print(f" • Minimum Confluence Skoru: {MIN_CONFLUENCE_SCORE} (Grade A+ Keskin Nişancı)")
    print(" • 1 Saatlik Makro Trend Kalkanı (1h EMA20 Uyumu)")
    print(" • 4 Kademeli Merdiven Kâr Sistemi (Step-Ladder Profit Lock)")
    print(f" • Dinamik Günlük Kota: Taban {DAILY_BASE_MAX_TRADES} + Her ${PROFIT_STEP_FOR_BONUS_TRADES} Kârda +{BONUS_TRADES_PER_STEP} Slot")
    print(f" • Günlük Zirve Kâr Kilidi (Trailing Floor): Zirve >= $30 -> $15 / $35 / $55 Kilit")
    print(f" • Günlük Circuit Breaker: -${DAILY_MAX_DRAWDOWN_USDT} Net Zararda Taramayı Dondur")
    print("=" * 70)

    # 1. Veri İndirme (2880 mum = 30 gün)
    print("\n📥 20 Likit Kripto Para İçin 30 Günlük 15m Mumlar Çekiliyor...")
    coin_data = {}
    all_timestamps = set()
    t_start = time.time()
    for idx, sym in enumerate(COINS_30D, 1):
        c = fetch_90d_candles(sym, 2880)
        if len(c) >= 100:
            coin_data[sym] = {'_list': c, 'by_ts': {x['timestamp']: x for x in c}}
            all_timestamps.update(x['timestamp'] for x in c)
            print(f"  [{idx:02d}/{len(COINS_30D):02d}] ✓ {sym:<12}: {len(c)} mum ({len(c)*15/60/24:.1f} gün)")
        else:
            print(f"  [{idx:02d}/{len(COINS_30D):02d}] ⚠️ {sym:<12}: Yetersiz veri ({len(c)} mum)")

    sorted_ts = sorted(list(all_timestamps))
    btc_candles = coin_data.get("BTCUSDT", {}).get('_list', [])
    btc_ts_to_idx = {c['timestamp']: idx for idx, c in enumerate(btc_candles)}
    coin_indices = {sym: {c['timestamp']: i for i, c in enumerate(d['_list'])} for sym, d in coin_data.items()}

    print(f"\n✓ Toplam {len(sorted_ts)} periyot (15 dakikalık bar) simüle edilecek.")
    print(f"   Başlangıç: {datetime.fromtimestamp(sorted_ts[0]/1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"   Bitiş:     {datetime.fromtimestamp(sorted_ts[-1]/1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}\n")

    ta_agent = TechnicalAnalysisAgent()
    quant_sim = QuantSimulationAgent(default_simulations=1000, win_threshold_pct=70.0)

    initial_equity = 1000.0
    equity = initial_equity
    max_concurrent = 5
    max_per_dir = 3
    target_risk_usd = 20.0

    active_trades = []
    completed_trades = []
    cooldown_until = {}
    equity_curve = [(sorted_ts[0], equity)]

    # Günlük Takip Değişkenleri
    current_day_str = None
    daily_trades_count = 0
    daily_net_dollar = 0.0
    daily_loss_sum = 0.0
    daily_peak_pnl = 0.0
    daily_circuit_breaker = False
    daily_profit_locked = False

    daily_reports = {}

    for ts in sorted_ts:
        dt_utc = datetime.fromtimestamp(ts/1000, tz=timezone.utc)
        bar_day_str = dt_utc.strftime('%Y-%m-%d')
        current_time_str = dt_utc.strftime('%Y-%m-%d %H:%M')

        # Gün Değişimi Kontrolü
        if bar_day_str != current_day_str:
            if current_day_str is not None:
                daily_reports[current_day_str] = {
                    'trades': daily_trades_count,
                    'net_dollar': round(daily_net_dollar, 2),
                    'peak_pnl': round(daily_peak_pnl, 2),
                    'loss_sum': round(daily_loss_sum, 2),
                    'circuit_breaker': daily_circuit_breaker,
                    'profit_locked': daily_profit_locked
                }
            current_day_str = bar_day_str
            daily_trades_count = 0
            daily_net_dollar = 0.0
            daily_loss_sum = 0.0
            daily_peak_pnl = 0.0
            daily_circuit_breaker = False
            daily_profit_locked = False

        # 1. AÇIK İŞLEMLERİ GÜNCELLE
        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            bar = coin_data[sym]['by_ts'].get(ts)
            if not bar:
                still_active.append(trade)
                continue

            entry_p = trade['entry_price']
            direction = trade['direction']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            bars_held = trade['bars_held'] + 1
            trade['bars_held'] = bars_held
            lev = trade['leverage']

            high_p = bar['high']
            low_p = bar['low']
            close_p = bar['close']

            closed = False
            exit_price = None
            exit_reason = None

            if direction == "LONG":
                max_gain_pct = ((high_p - entry_p) / entry_p) * 100.0
                for step in LADDER_STEPS:
                    if max_gain_pct >= step['trigger_raw_pct']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK" if trade['ladder_level'] > 0 else "HIT_SL"
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_change = (close_p - entry_p) / entry_p
                    if raw_change > 0.001:
                        closed = True
                        exit_price = close_p
                        exit_reason = "TIMEOUT_PROFIT_EXIT"
                    elif bars_held < 8 and abs(raw_change) < 0.004:
                        pass
                    else:
                        closed = True
                        exit_price = close_p
                        exit_reason = "TIMEOUT_EXIT"

            else: # SHORT
                max_gain_pct = ((entry_p - low_p) / entry_p) * 100.0
                for step in LADDER_STEPS:
                    if max_gain_pct >= step['trigger_raw_pct']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK" if trade['ladder_level'] > 0 else "HIT_SL"
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_change = (entry_p - close_p) / entry_p
                    if raw_change > 0.001:
                        closed = True
                        exit_price = close_p
                        exit_reason = "TIMEOUT_PROFIT_EXIT"
                    elif bars_held < 8 and abs(raw_change) < 0.004:
                        pass
                    else:
                        closed = True
                        exit_price = close_p
                        exit_reason = "TIMEOUT_EXIT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = (BINANCE_ROUNDTRIP_FEE_PCT + ESTIMATED_SLIPPAGE_PCT) * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                equity_curve.append((ts, equity))

                completed_trades.append({
                    'symbol': sym,
                    'direction': direction,
                    'leverage': lev,
                    'risk_grade': trade['risk_grade'],
                    'entry_time': trade['entry_time_str'],
                    'exit_time': current_time_str,
                    'entry_price': entry_p,
                    'exit_price': exit_price,
                    'status': exit_reason,
                    'raw_pnl_pct': round(raw_gain_pct, 2),
                    'net_pnl_pct': round(net_margin, 2),
                    'dollar_gain': round(dollar_gain, 2),
                    'margin': round(trade['margin'], 2),
                    'bars_held': bars_held,
                    'equity_after': round(equity, 2)
                })
                cooldown_until[sym] = ts + (45 * 60 * 1000)

                # Günlük Metrikleri Güncelle
                daily_net_dollar += dollar_gain
                if dollar_gain < 0:
                    daily_loss_sum += abs(dollar_gain)
                    if daily_loss_sum >= DAILY_MAX_DRAWDOWN_USDT:
                        daily_circuit_breaker = True

                daily_peak_pnl = max(daily_peak_pnl, daily_net_dollar)
                if DAILY_TRAILING_PROFIT_LOCK_ENABLED and daily_peak_pnl >= 30.0:
                    floor = 15.0 if daily_peak_pnl < 50.0 else (35.0 if daily_peak_pnl < 75.0 else 55.0)
                    if daily_net_dollar <= floor:
                        daily_profit_locked = True
            else:
                still_active.append(trade)

        active_trades = still_active

        # 2. GÜNLÜK FREN VE KOTA KONTROLLERİ
        if len(active_trades) >= max_concurrent:
            continue
        if daily_circuit_breaker:
            continue
        if daily_profit_locked:
            continue

        # Dinamik Kota Hesabı
        bonus_slots = 0
        if daily_net_dollar > 0 and PROFIT_STEP_FOR_BONUS_TRADES > 0:
            bonus_slots = int(daily_net_dollar // PROFIT_STEP_FOR_BONUS_TRADES) * BONUS_TRADES_PER_STEP
        effective_max_trades = DAILY_BASE_MAX_TRADES + bonus_slots

        if daily_trades_count >= effective_max_trades:
            continue

        # BTC Kalkanı
        btc_idx = btc_ts_to_idx.get(ts)
        if btc_idx is not None:
            btc_ok, _ = check_btc_shield(btc_candles, btc_idx)
            if not btc_ok:
                continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        for sym in COINS_30D:
            if len(active_trades) >= max_concurrent:
                break
            if daily_trades_count >= effective_max_trades:
                break
            if sym in active_syms:
                continue
            if ts < cooldown_until.get(sym, 0):
                continue

            bar = coin_data[sym]['by_ts'].get(ts)
            if not bar:
                continue

            idx = coin_indices[sym].get(ts)
            if idx is None or idx < 60:
                continue

            candle_window = coin_data[sym]['_list'][idx-59 : idx+1]
            all_past_15m = coin_data[sym]['_list'][: idx+1]
            c_1h = build_1h_candles_from_15m(all_past_15m)
            candles_1h_window = c_1h[-35:] if len(c_1h) >= 20 else None

            setup, reason = ta_agent.analyze_setup(sym, candle_window, candles_1h_window)

            if setup and setup.get('confluence_score', 0) >= MIN_CONFLUENCE_SCORE:
                d = setup['direction']
                if d == "LONG" and long_count >= max_per_dir:
                    continue
                if d == "SHORT" and short_count >= max_per_dir:
                    continue

                q_sim = quant_sim.simulate_setup(sym, setup, candle_window, num_simulations=1000)
                if not q_sim.get('is_approved', False):
                    continue

                entry_p = bar['close']
                sl_p = setup['stop_loss']
                tp_p = setup['take_profit_2']
                lev = setup.get('leverage', 10)
                grade = setup.get('risk_grade', 'Grade A')

                if d == "LONG" and (sl_p >= entry_p or tp_p <= entry_p):
                    continue
                if d == "SHORT" and (sl_p <= entry_p or tp_p >= entry_p):
                    continue

                # Dinamik Marjin (Risk $20 sabitleme)
                raw_sl_pct = abs(entry_p - sl_p) / entry_p
                total_loss_frac = (raw_sl_pct + 0.0012) * lev
                calc_margin = target_risk_usd / total_loss_frac if total_loss_frac > 0 else 100.0
                margin = min(calc_margin, 200.0, equity * 0.20)

                active_trades.append({
                    'symbol': sym,
                    'direction': d,
                    'leverage': lev,
                    'risk_grade': grade,
                    'entry_time_str': current_time_str,
                    'entry_price': entry_p,
                    'current_sl': sl_p,
                    'take_profit': tp_p,
                    'margin': margin,
                    'bars_held': 0,
                    'ladder_level': 0
                })
                active_syms.add(sym)
                if d == "LONG":
                    long_count += 1
                else:
                    short_count += 1
                daily_trades_count += 1

    # Raporlama
    total = len(completed_trades)
    print("\n" + "=" * 70)
    print("🏆 GÜNCEL BOT İLE GEÇMİŞ 30 GÜN NİHAİ TEST BİLANÇOSU")
    print("=" * 70)
    print(f"💰 Başlangıç Kasası:             ${initial_equity:,.2f} USDT")
    print(f"💼 Bitiş Kasası:                 ${equity:,.2f} USDT")
    tot_dollar = sum(t['dollar_gain'] for t in completed_trades)
    ret_pct = ((equity - initial_equity) / initial_equity) * 100.0
    print(f"🟢 Net Dolar Getirisi:           {'+' if tot_dollar>=0 else ''}${tot_dollar:,.2f} ({'+' if ret_pct>=0 else ''}%{ret_pct:.2f})")
    print(f"🎯 Toplam İşlem Sayısı:          {total} adet (Günde ortalama {total/30:.1f} işlem)")

    if total > 0:
        wins = [t for t in completed_trades if t['net_pnl_pct'] > 0]
        losses = [t for t in completed_trades if t['net_pnl_pct'] < 0]
        win_rate = (len(wins) / total) * 100.0
        sum_w = sum(t['dollar_gain'] for t in wins)
        sum_l = abs(sum(t['dollar_gain'] for t in losses))
        pf = round(sum_w / sum_l, 2) if sum_l > 0 else 99.0

        sniper_trades = [t for t in completed_trades if t.get('leverage') == 20]
        sniper_wins = [t for t in sniper_trades if t['net_pnl_pct'] > 0]
        std_trades = [t for t in completed_trades if t.get('leverage') == 10]
        std_wins = [t for t in std_trades if t['net_pnl_pct'] > 0]

        peak = initial_equity
        max_dd = 0.0
        max_dd_pct = 0.0
        for _, eq in equity_curve:
            if eq > peak:
                peak = eq
            dd = peak - eq
            dd_p = (dd / peak) * 100.0
            if dd > max_dd:
                max_dd = dd
            if dd_p > max_dd_pct:
                max_dd_pct = dd_p

        print(f"✅ Kazanan İşlemler (Win Rate):  {len(wins)} adet (%{win_rate:.1f})")
        print(f"🛑 Kaybeden İşlemler (Loss):     {len(losses)} adet (%{(len(losses)/total)*100:.1f})")
        print(f"⚖️ Profit Factor (Kâr Faktörü):  {pf}")
        print(f"📉 Maksimum Geri Çekilme (MDD):  -${max_dd:.2f} (-%{max_dd_pct:.2f})")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"🎯 20x Sniper İşlemleri:         {len(sniper_trades)} adet | %{(len(sniper_wins)/len(sniper_trades)*100) if sniper_trades else 0:.1f} Win | Net: ${sum(t['dollar_gain'] for t in sniper_trades):.2f}")
        print(f"🎯 10x Standart Scalpler:        {len(std_trades)} adet | %{(len(std_wins)/len(std_trades)*100) if std_trades else 0:.1f} Win | Net: ${sum(t['dollar_gain'] for t in std_trades):.2f}")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        # Çıkış Nedenleri
        exit_counts = Counter(t['status'] for t in completed_trades)
        print("📊 ÇIKIŞ NEDENLERİ DAĞILIMI:")
        for status, count in exit_counts.most_common():
            print(f"   • {status:<24}: {count:3d} adet (%{count/total*100:5.1f})")

        # Coin Dağılımı
        by_coin = defaultdict(lambda: {'trades': 0, 'wins': 0, 'dollar': 0.0})
        for t in completed_trades:
            s = t['symbol']
            by_coin[s]['trades'] += 1
            if t['net_pnl_pct'] > 0:
                by_coin[s]['wins'] += 1
            by_coin[s]['dollar'] += t['dollar_gain']

        print("\n🪙 EN ÇOK KAZANDIRAN COİNLER:")
        sorted_coins = sorted(by_coin.items(), key=lambda x: x[1]['dollar'], reverse=True)
        for s, st in sorted_coins[:6]:
            c_wr = (st['wins'] / st['trades'] * 100) if st['trades'] > 0 else 0
            sign = "+" if st['dollar'] >= 0 else ""
            print(f"   • {s:<14} | {st['trades']:2d} İşlem | Win: %{c_wr:5.1f} | Net: {sign}${st['dollar']:6.2f}")

        # Günlük Kâr Kalkanı ve Circuit Breaker İstatistikleri
        cb_days = sum(1 for d in daily_reports.values() if d.get('circuit_breaker'))
        locked_days = sum(1 for d in daily_reports.values() if d.get('profit_locked'))
        winning_days = sum(1 for d in daily_reports.values() if d.get('net_dollar', 0) > 0)
        losing_days = sum(1 for d in daily_reports.values() if d.get('net_dollar', 0) < 0)

        print("\n📅 GÜNLÜK KALKAN RAPORU:")
        print(f"   • Kârlı Kapanan Günler:       {winning_days} gün")
        print(f"   • Zararlı Kapanan Günler:     {losing_days} gün")
        print(f"   • Zirve Kâr Kilidi Tetiklenen: {locked_days} gün (Kâr kasaya kilitlendi)")
        print(f"   • Circuit Breaker Tetiklenen: {cb_days} gün (Azami -$50 freni)")

        # JSON kaydet
        with open('bu_haliyle_30d_sim_results.json', 'w', encoding='utf-8') as f:
            json.dump({
                'initial_equity': initial_equity,
                'final_equity': round(equity, 2),
                'net_dollar': round(tot_dollar, 2),
                'return_pct': round(ret_pct, 2),
                'total_trades': total,
                'win_count': len(wins),
                'loss_count': len(losses),
                'win_rate': round(win_rate, 1),
                'profit_factor': pf,
                'max_dd_dollar': round(max_dd, 2),
                'max_dd_pct': round(max_dd_pct, 2),
                'sniper_stats': {'trades': len(sniper_trades), 'wins': len(sniper_wins), 'net_dollar': round(sum(t['dollar_gain'] for t in sniper_trades), 2)},
                'std_stats': {'trades': len(std_trades), 'wins': len(std_wins), 'net_dollar': round(sum(t['dollar_gain'] for t in std_trades), 2)},
                'exit_counts': dict(exit_counts),
                'daily_reports': daily_reports,
                'trades': completed_trades
            }, f, indent=2, ensure_ascii=False)

if __name__ == '__main__':
    run_simulation()
