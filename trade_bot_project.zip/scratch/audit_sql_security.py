import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
db_file = os.path.join(WORKSPACE_DIR, "core", "database.py")
content = open(db_file, "r", encoding="utf-8", errors="ignore").read()

import re
# Find execute calls with f-strings
f_string_sql = re.findall(r"cursor\.execute\(\s*f['\"][^'\"]*\{[^'\"]*\}['\"]", content)
print("=" * 80)
print("🛡️ SQL INJECTION & DATABASE GÜVENLİK DENETİMİ (core/database.py)")
print("=" * 80)
if f_string_sql:
    print(f"⚠️ {len(f_string_sql)} adet f-string SQL sorgusu tespit edildi:")
    for sql in f_string_sql:
        print("  -", sql.strip())
else:
    print("✅ Temiz: cursor.execute() sorguları parametreli (placeholder '?') yapıda kullanılmış veya güvenli.")
