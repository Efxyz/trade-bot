import os
import sys
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
sys.path.insert(0, r"C:\Users\isiks\.gemini\antigravity\brain\a2f493b1-6bd2-4f3b-a3f9-f21e7725bbd5\scratch")
os.chdir(str(project_root))

import json
import time
from datetime import datetime, timezone
from typing import List, Dict, Tuple
from collections import defaultdict, Counter

from config import (
    LADDER_STEPS,
    LADDER_DYNAMIC_CHANNEL_PCT,
    MIN_CONFLUENCE_SCORE,
    MIN_CONFLUENCE_SCORE_SHORT,
    LEVERAGE_STANDARD,
    LEVERAGE_HIGH,
    BINANCE_ROUNDTRIP_FEE_PCT,
    MAX_HOLD_MINUTES,
    MAX_SCALP_SL_PCT,
    MIN_SCALP_SL_PCT,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_RR_RATIO,
    DAILY_BASE_MAX_TRADES,
    PROFIT_STEP_FOR_BONUS_TRADES,
    BONUS_TRADES_PER_STEP,
    DAILY_MAX_DRAWDOWN_USDT,
    DAILY_TRAILING_PROFIT_LOCK_ENABLED,
    EARLY_INVALIDATION_ENABLED,
    EARLY_INVALIDATION_MINUTES,
    EARLY_INVALIDATION_LOSS_PCT,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    EXCLUDED_SYMBOLS_BLACKLIST,
    SMC_PREMIUM_DISCOUNT_FILTER,
    MAX_VWAP_DISTANCE_PCT
)
from agents.ta_agent import TechnicalAnalysisAgent
from test_90d_fetch import fetch_90d_candles

def build_1h_candles_from_15m(candles_15m: List[Dict]) -> List[Dict]:
    if not candles_15m:
        return []
    candles_1h = []
    bucket = []
    current_hour = None
    for c in candles_15m:
        hour_ts = (c['timestamp'] // (3600 * 1000)) * (3600 * 1000)
        if current_hour is None:
            current_hour = hour_ts
        if hour_ts != current_hour and bucket:
            candles_1h.append({
                'timestamp': current_hour,
                'open': bucket[0]['open'],
                'high': max(b['high'] for b in bucket),
                'low': min(b['low'] for b in bucket),
                'close': bucket[-1]['close'],
                'volume': sum(b['volume'] for b in bucket)
            })
            bucket = [c]
            current_hour = hour_ts
        else:
            bucket.append(c)
    if bucket:
        candles_1h.append({
            'timestamp': current_hour,
            'open': bucket[0]['open'],
            'high': max(b['high'] for b in bucket),
            'low': min(b['low'] for b in bucket),
            'close': bucket[-1]['close'],
            'volume': sum(b['volume'] for b in bucket)
        })
    return candles_1h

def check_btc_shield(btc_candles: List[Dict], idx: int) -> Tuple[bool, str]:
    if idx < 40:
        return True, "Yetersiz BTC verisi"
    closes = [c['close'] for c in btc_candles[:idx+1]]
    curr_p = closes[-1]
    # EMA 20
    k = 2.0 / (20 + 1)
    ema20 = closes[0]
    for p in closes[1:]:
        ema20 = p * k + ema20 * (1 - k)
    change_3h = ((curr_p - closes[-12]) / closes[-12]) * 100.0 if len(closes) >= 12 else 0.0
    if change_3h <= -2.5:
        return False, "BTC Çöküş Filtresi (-%2.5+ düşüş)"
    return True, "BTC Normal"

COINS_UNIVERSE = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT",
    "DOGEUSDT", "1000PEPEUSDT", "WIFUSDT",
    "SUIUSDT", "OPUSDT", "NEARUSDT", "AVAXUSDT",
    "FETUSDT", "RENDERUSDT", "TAOUSDT", "TIAUSDT"
]

def run_simulation():
    print("=" * 75)
    print("🚀 GÜNCEL KORUMA VE FREQTRADE KALKANLARI İLE 30 GÜNLÜK BÜYÜK SİMÜLASYON")
    print("=" * 75)
    print("Devredeki Yeni Kalkanlar:")
    print(" • Freqtrade Side-Specific Stoploss Guard (Peş peşe 2 kayıpta o yön 120 dk dondurulur)")
    print(" • Yeni Merdiven Kâr Sistemi (Basamak 1: +%0.35 trigger -> +%0.10 BE+ kilit)")
    print(" • 20 Dakikalık Erken İptal Kalkanı (-%0.35 raw kayıpta küçük zararla kesme)")
    print(" • SMC Premium / Discount Filtresi (Dipten Short / Tepeden Long Engeli)")
    print(" • RSI Divergence & Lastik Bandı VWAP Filtresi")
    print(f" • Zehirli Parite Kara Listesi: {EXCLUDED_SYMBOLS_BLACKLIST}")
    print("=" * 75)

    # 1. 30 Günlük Verileri İndir / Önbellekten Oku (2,880 15m mum)
    cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
    coin_data = {}
    all_timestamps = set()

    if os.path.exists(cache_path):
        print(f"\n📂 30 Günlük Veriler Yerel Önbellekten Yükleniyor: {cache_path}...")
        with open(cache_path, "r", encoding="utf-8") as f:
            raw_cache = json.load(f)
        for sym, c in raw_cache.items():
            coin_data[sym] = {'_list': c, 'by_ts': {x['timestamp']: x for x in c}}
            all_timestamps.update(x['timestamp'] for x in c)
        print(f"✓ {len(coin_data)} parite için önbellek başarıyla yüklendi.")
    else:
        print("\n📥 Pariteler İçin 30 Günlük Gerçek Binance 15m Mumları Alınıyor...")
        raw_to_cache = {}
        for idx, sym in enumerate(COINS_UNIVERSE, 1):
            if sym in EXCLUDED_SYMBOLS_BLACKLIST:
                continue
            c = fetch_90d_candles(sym, 2880)
            if len(c) >= 100:
                raw_to_cache[sym] = c
                coin_data[sym] = {'_list': c, 'by_ts': {x['timestamp']: x for x in c}}
                all_timestamps.update(x['timestamp'] for x in c)
                print(f"  [{idx:02d}/{len(COINS_UNIVERSE):02d}] ✓ {sym:<12}: {len(c)} mum ({len(c)*15/60/24:.1f} gün)")
            time.sleep(0.03)
        try:
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(raw_to_cache, f)
            print("💾 30 günlük veriler hızlandırma için önbelleğe kaydedildi.")
        except Exception:
            pass

    sorted_ts = sorted(list(all_timestamps))
    btc_candles = coin_data.get("BTCUSDT", {}).get('_list', [])
    btc_ts_to_idx = {c['timestamp']: idx for idx, c in enumerate(btc_candles)}
    coin_indices = {sym: {c['timestamp']: i for i, c in enumerate(d['_list'])} for sym, d in coin_data.items()}

    print(f"\n✓ Toplam {len(sorted_ts)} periyot simüle edilecek.")
    print(f"   Başlangıç: {datetime.fromtimestamp(sorted_ts[0]/1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
    print(f"   Bitiş:     {datetime.fromtimestamp(sorted_ts[-1]/1000, tz=timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}\n")

    ta_agent = TechnicalAnalysisAgent()

    initial_equity = 1000.0
    equity = initial_equity
    max_concurrent = 5
    max_per_dir = 3
    target_risk_usd = 20.0

    active_trades = []
    completed_trades = []
    cooldown_until = {}
    equity_curve = [(sorted_ts[0], equity)]

    # Side-Specific Stoploss Guard State
    side_consecutive_losses = {"LONG": 0, "SHORT": 0}
    side_locked_until = {"LONG": 0, "SHORT": 0}

    # Günlük Takip
    current_day_str = None
    daily_trades_count = 0
    daily_net_dollar = 0.0
    daily_loss_sum = 0.0
    daily_circuit_breaker = False
    daily_profit_locked = False
    daily_peak_pnl = 0.0
    daily_reports = []

    for ts in sorted_ts:
        dt = datetime.fromtimestamp(ts / 1000, tz=timezone.utc)
        day_str = dt.strftime("%Y-%m-%d")
        current_time_str = dt.strftime("%Y-%m-%d %H:%M")

        # Gün Sonu Değerlendirmesi
        if current_day_str != day_str:
            if current_day_str is not None:
                daily_reports.append({
                    'day': current_day_str,
                    'trades': daily_trades_count,
                    'net_pnl_usd': round(daily_net_dollar, 2),
                    'equity': round(equity, 2),
                    'breaker': daily_circuit_breaker,
                    'profit_locked': daily_profit_locked
                })
            current_day_str = day_str
            daily_trades_count = 0
            daily_net_dollar = 0.0
            daily_loss_sum = 0.0
            daily_circuit_breaker = False
            daily_profit_locked = False
            daily_peak_pnl = 0.0

        # 1. AÇIK İŞLEMLERİ TAKİP ET (TP, MERDİVEN BE+, ERKEN İPTAL, SL)
        still_active = []
        for trade in active_trades:
            sym = trade['symbol']
            c_info = coin_data.get(sym, {}).get('by_ts', {}).get(ts)
            if not c_info:
                still_active.append(trade)
                continue

            high_p = c_info['high']
            low_p = c_info['low']
            close_p = c_info['close']

            direction = trade['direction']
            entry_p = trade['entry_price']
            curr_sl = trade['current_sl']
            tp_p = trade['take_profit']
            lev = trade['leverage']

            trade['bars_held'] += 1
            bars_held = trade['bars_held']
            minutes_open = bars_held * 15

            # En yüksek/en düşük fiyatları kaydet
            trade['highest_price'] = max(trade.get('highest_price', entry_p), high_p)
            trade['lowest_price'] = min(trade.get('lowest_price', entry_p), low_p)

            closed = False
            exit_price = entry_p
            exit_reason = ""

            if direction == "LONG":
                peak_gain_pct = ((trade['highest_price'] - entry_p) / entry_p) * 100.0

                # Merdiven Kâr Sistemi
                for step in LADDER_STEPS:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 + step['lock_raw_pct'] / 100.0)
                        if locked_sl > curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                # Dinamik Kanal (Runner)
                if peak_gain_pct >= 1.05:
                    ch_sl = trade['highest_price'] * (1.0 - LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl > curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                # Stop veya Merdiven Stop Çarpması
                if low_p <= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"

                # TP Çarpması
                elif high_p >= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"

                # 20 DAKİKALIK ERKEN İPTAL KALKANI (EARLY INVALIDATION)
                elif EARLY_INVALIDATION_ENABLED and trade['ladder_level'] == 0 and minutes_open >= EARLY_INVALIDATION_MINUTES:
                    raw_c = (close_p - entry_p) / entry_p
                    if raw_c <= -(EARLY_INVALIDATION_LOSS_PCT / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"

                # 90 Dakika Zaman Aşımı
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (close_p - entry_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            else: # SHORT
                peak_gain_pct = ((entry_p - trade['lowest_price']) / entry_p) * 100.0

                # Merdiven Kâr Sistemi
                for step in LADDER_STEPS:
                    if peak_gain_pct >= step['trigger_raw_pct'] and step['step'] > trade['ladder_level']:
                        locked_sl = entry_p * (1.0 - step['lock_raw_pct'] / 100.0)
                        if locked_sl < curr_sl:
                            trade['current_sl'] = locked_sl
                            curr_sl = locked_sl
                            trade['ladder_level'] = step['step']

                # Dinamik Kanal (Runner)
                if peak_gain_pct >= 1.05:
                    ch_sl = trade['lowest_price'] * (1.0 + LADDER_DYNAMIC_CHANNEL_PCT / 100.0)
                    if ch_sl < curr_sl:
                        trade['current_sl'] = ch_sl
                        curr_sl = ch_sl

                # Stop veya Merdiven Stop Çarpması
                if high_p >= curr_sl:
                    closed = True
                    exit_price = curr_sl
                    if trade['ladder_level'] >= 2:
                        exit_reason = f"LADDER_STEP_{trade['ladder_level']}_LOCK"
                    elif trade['ladder_level'] == 1:
                        exit_reason = "CLOSED_BE"
                    else:
                        exit_reason = "HIT_SL"

                # TP Çarpması
                elif low_p <= tp_p:
                    closed = True
                    exit_price = tp_p
                    exit_reason = "HIT_TP"

                # 20 DAKİKALIK ERKEN İPTAL KALKANI (EARLY INVALIDATION)
                elif EARLY_INVALIDATION_ENABLED and trade['ladder_level'] == 0 and minutes_open >= EARLY_INVALIDATION_MINUTES:
                    raw_c = (entry_p - close_p) / entry_p
                    if raw_c <= -(EARLY_INVALIDATION_LOSS_PCT / 100.0):
                        closed = True
                        exit_price = close_p
                        exit_reason = "EARLY_INVALIDATION_EXIT"

                # 90 Dakika Zaman Aşımı
                elif bars_held >= (MAX_HOLD_MINUTES // 15):
                    raw_c = (entry_p - close_p) / entry_p
                    closed = True
                    exit_price = close_p
                    exit_reason = "TIMEOUT_PROFIT_EXIT" if raw_c > 0.001 else "TIMEOUT_EXIT"

            if closed:
                raw_gain_pct = ((exit_price - entry_p) / entry_p) * 100.0 if direction == "LONG" else ((entry_p - exit_price) / entry_p) * 100.0
                gross_margin = raw_gain_pct * lev
                fee_pct = BINANCE_ROUNDTRIP_FEE_PCT * lev
                net_margin = gross_margin - fee_pct
                dollar_gain = trade['margin'] * (net_margin / 100.0)

                equity += dollar_gain
                equity_curve.append((ts, equity))

                completed_trades.append({
                    'symbol': sym,
                    'direction': direction,
                    'leverage': lev,
                    'risk_grade': trade['risk_grade'],
                    'entry_time': trade['entry_time_str'],
                    'exit_time': current_time_str,
                    'entry_price': entry_p,
                    'exit_price': exit_price,
                    'status': exit_reason,
                    'raw_pnl_pct': round(raw_gain_pct, 2),
                    'net_pnl_pct': round(net_margin, 2),
                    'dollar_gain': round(dollar_gain, 2),
                    'margin': round(trade['margin'], 2),
                    'bars_held': bars_held,
                    'equity_after': round(equity, 2)
                })
                cooldown_until[sym] = ts + (45 * 60 * 1000)

                # FREQTRADE SIDE GUARD GÜNCELLEMESİ
                if dollar_gain < 0:
                    side_consecutive_losses[direction] += 1
                    if SIDE_STOPLOSS_GUARD_ENABLED and side_consecutive_losses[direction] >= SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES:
                        side_locked_until[direction] = ts + (SIDE_STOPLOSS_COOLDOWN_MINUTES * 60 * 1000)
                else:
                    # Kârlı veya başabaş işlem seriyi sıfırlar
                    side_consecutive_losses[direction] = 0

                # Günlük Metrikleri Güncelle
                daily_net_dollar += dollar_gain
                if dollar_gain < 0:
                    daily_loss_sum += abs(dollar_gain)
                    if daily_loss_sum >= DAILY_MAX_DRAWDOWN_USDT:
                        daily_circuit_breaker = True

                daily_peak_pnl = max(daily_peak_pnl, daily_net_dollar)
                if DAILY_TRAILING_PROFIT_LOCK_ENABLED and daily_peak_pnl >= 30.0:
                    floor = 15.0 if daily_peak_pnl < 50.0 else (35.0 if daily_peak_pnl < 75.0 else 55.0)
                    if daily_net_dollar <= floor:
                        daily_profit_locked = True
            else:
                still_active.append(trade)

        active_trades = still_active

        # 2. YENİ İŞLEM FİLTRELERİ
        if len(active_trades) >= max_concurrent:
            continue
        if daily_circuit_breaker or daily_profit_locked:
            continue

        bonus_slots = 0
        if daily_net_dollar > 0 and PROFIT_STEP_FOR_BONUS_TRADES > 0:
            bonus_slots = int(daily_net_dollar // PROFIT_STEP_FOR_BONUS_TRADES) * BONUS_TRADES_PER_STEP
        effective_max_trades = DAILY_BASE_MAX_TRADES + bonus_slots

        if daily_trades_count >= effective_max_trades:
            continue

        btc_idx = btc_ts_to_idx.get(ts)
        if btc_idx is not None:
            btc_ok, _ = check_btc_shield(btc_candles, btc_idx)
            if not btc_ok:
                continue

        active_syms = {t['symbol'] for t in active_trades}
        long_count = sum(1 for t in active_trades if t['direction'] == 'LONG')
        short_count = sum(1 for t in active_trades if t['direction'] == 'SHORT')

        for sym in COINS_UNIVERSE:
            if sym in EXCLUDED_SYMBOLS_BLACKLIST:
                continue
            if len(active_trades) >= max_concurrent:
                break
            if daily_trades_count >= effective_max_trades:
                break
            if sym in active_syms:
                continue
            if ts < cooldown_until.get(sym, 0):
                continue

            c_idx = coin_indices.get(sym, {}).get(ts)
            if c_idx is None or c_idx < 40:
                continue

            candles_sub = coin_data[sym]['_list'][:c_idx+1]
            win_15m = candles_sub[-60:] if len(candles_sub) >= 60 else candles_sub
            c_1h_all = build_1h_candles_from_15m(candles_sub)
            win_1h = c_1h_all[-35:] if len(c_1h_all) >= 20 else None

            # TA Agent Analizi (Tüm güncel SMC Premium/Discount, VWAP ve Divergence filtreleri devrede!)
            setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
            if not setup:
                continue

            direction = setup['direction']

            # FREQTRADE SIDE STOPLOSS GUARD KONTROLÜ
            if SIDE_STOPLOSS_GUARD_ENABLED and ts < side_locked_until.get(direction, 0):
                # Bu yön soğuma sürecinde, sinyal reddedilir!
                continue

            if direction == 'LONG' and long_count >= max_per_dir:
                continue
            if direction == 'SHORT' and short_count >= max_per_dir:
                continue

            sl_pct = setup['sl_pct']
            tp_pct = setup['tp1_pct']
            score = setup['confluence_score']

            is_sniper = (score >= 85 and sl_pct <= MAX_SL_PCT_20X)
            leverage = 20 if is_sniper else 10
            max_sl_allowed = MAX_SL_PCT_20X if leverage == 20 else MAX_SL_PCT_10X

            if sl_pct > max_sl_allowed or sl_pct <= 0:
                continue

            rr = tp_pct / sl_pct if sl_pct > 0 else 0
            if rr < MIN_RR_RATIO:
                continue

            # Sabit 2% Risk Bütçelemesi
            allocated_margin = min(target_risk_usd / (sl_pct / 100.0 * leverage), 200.0)
            allocated_margin = max(allocated_margin, 50.0)

            entry_p = setup['current_price']
            sl_p = setup['stop_loss']
            tp_p = setup['take_profit_1']

            active_trades.append({
                'symbol': sym,
                'direction': direction,
                'leverage': leverage,
                'risk_grade': setup['risk_grade'],
                'entry_time_ts': ts,
                'entry_time_str': current_time_str,
                'entry_price': entry_p,
                'current_sl': sl_p,
                'take_profit': tp_p,
                'sl_pct': sl_pct,
                'tp_pct': tp_pct,
                'margin': allocated_margin,
                'ladder_level': 0,
                'bars_held': 0,
                'highest_price': entry_p,
                'lowest_price': entry_p
            })
            daily_trades_count += 1
            if direction == 'LONG':
                long_count += 1
            else:
                short_count += 1

    # Özet Raporu Hesapla
    win_trades = [t for t in completed_trades if t['dollar_gain'] > 0]
    loss_trades = [t for t in completed_trades if t['dollar_gain'] < 0]
    be_trades = [t for t in completed_trades if t['dollar_gain'] == 0]

    win_count = len(win_trades)
    loss_count = len(loss_trades)
    total_trades = len(completed_trades)
    win_rate = round((win_count / total_trades * 100.0), 2) if total_trades > 0 else 0.0

    total_win_usd = sum(t['dollar_gain'] for t in win_trades)
    total_loss_usd = sum(t['dollar_gain'] for t in loss_trades)
    net_pnl_usd = round(total_win_usd + total_loss_usd, 2)
    profit_factor = round(abs(total_win_usd / total_loss_usd), 2) if total_loss_usd != 0 else 99.0

    peak_eq = initial_equity
    max_dd_usd = 0.0
    max_dd_pct = 0.0
    for _, eq in equity_curve:
        if eq > peak_eq:
            peak_eq = eq
        dd = peak_eq - eq
        dd_pct = (dd / peak_eq) * 100.0 if peak_eq > 0 else 0.0
        if dd > max_dd_usd:
            max_dd_usd = dd
            max_dd_pct = dd_pct

    exit_counts = Counter(t['status'] for t in completed_trades)

    long_trades = [t for t in completed_trades if t['direction'] == 'LONG']
    short_trades = [t for t in completed_trades if t['direction'] == 'SHORT']

    long_wins = [t for t in long_trades if t['dollar_gain'] > 0]
    short_wins = [t for t in short_trades if t['dollar_gain'] > 0]

    results = {
        'initial_equity': initial_equity,
        'final_equity': round(equity, 2),
        'net_dollar': net_pnl_usd,
        'return_pct': round(((equity - initial_equity) / initial_equity) * 100.0, 2),
        'total_trades': total_trades,
        'win_count': win_count,
        'loss_count': loss_count,
        'be_count': len(be_trades),
        'win_rate': win_rate,
        'profit_factor': profit_factor,
        'max_dd_dollar': round(max_dd_usd, 2),
        'max_dd_pct': round(max_dd_pct, 2),
        'long_stats': {
            'total': len(long_trades),
            'wins': len(long_wins),
            'win_rate': round(len(long_wins)/len(long_trades)*100.0, 2) if long_trades else 0,
            'net_dollar': round(sum(t['dollar_gain'] for t in long_trades), 2)
        },
        'short_stats': {
            'total': len(short_trades),
            'wins': len(short_wins),
            'win_rate': round(len(short_wins)/len(short_trades)*100.0, 2) if short_trades else 0,
            'net_dollar': round(sum(t['dollar_gain'] for t in short_trades), 2)
        },
        'exit_counts': dict(exit_counts),
        'daily_reports': daily_reports,
        'trades': completed_trades
    }

    out_path = os.path.join(str(project_root), "data", "simulations", "sim_current_bot_30d_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print("\n" + "=" * 75)
    print("🏆 GÜNCEL BOT 30 GÜNLÜK BÜYÜK SİMÜLASYON SONUÇLARI")
    print("=" * 75)
    print(f"💰 Başlangıç Kasası     : ${initial_equity:.2f} USDT")
    print(f"🏁 Bitiş Kasası         : ${equity:.2f} USDT")
    print(f"📈 Net Kâr / Zarar      : {net_pnl_usd:+.2f} USDT (%{results['return_pct']:+.2f})")
    print(f"🎯 Toplam İşlem Sayısı  : {total_trades}")
    print(f"🟢 Başarılı (Kazanılan) : {win_count}")
    print(f"🔴 Kaybedilen (Stop)    : {loss_count}")
    print(f"🛡️ Başa-Baş (BE+ Çıkış) : {len(be_trades)}")
    print(f"📊 Başarı Oranı (WinRate): %{win_rate:.2f}")
    print(f"⚖️ Profit Factor (Kâr/Z): {profit_factor:.2f}")
    print(f"📉 Maksimum Çekilme (DD): %{max_dd_pct:.2f} (-${max_dd_usd:.2f})")
    print("-" * 75)
    print("ÇIKIŞ NEDENLERİ DAĞILIMI:")
    for status, count in exit_counts.items():
        print(f"  • {status:<25}: {count} adet")
    print("-" * 75)
    print("YÖN BAZLI PERFORMANS:")
    print(f"  • LONG : {len(long_trades)} işlem | {len(long_wins)} kazanç (%{results['long_stats']['win_rate']}) | Net: ${results['long_stats']['net_dollar']:+.2f}")
    print(f"  • SHORT: {len(short_trades)} işlem | {len(short_wins)} kazanç (%{results['short_stats']['win_rate']}) | Net: ${results['short_stats']['net_dollar']:+.2f}")
    print("=" * 75)
    print(f"📁 Detaylı JSON Raporu: {out_path}")

if __name__ == '__main__':
    run_simulation()
