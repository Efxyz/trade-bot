const fs = require('fs');

function formatTurkeyTime(timeStr) {
    if (!timeStr) return '';
    try {
        const s = String(timeStr).trim();
        const matchDt = s.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/);
        if (matchDt) {
            const [y, m, d] = matchDt[1].split('-').map(Number);
            const hh = Number(matchDt[2]);
            const mm = Number(matchDt[3]);
            const ss = matchDt[4] ? Number(matchDt[4]) : 0;
            const utc = new Date(Date.UTC(y, m - 1, d, hh + 3, mm, ss));
            const ry = utc.getUTCFullYear();
            const rm = String(utc.getUTCMonth() + 1).padStart(2, '0');
            const rd = String(utc.getUTCDate()).padStart(2, '0');
            const rh = String(utc.getUTCHours()).padStart(2, '0');
            const rmin = String(utc.getUTCMinutes()).padStart(2, '0');
            const rsec = String(utc.getUTCSeconds()).padStart(2, '0');
            return `${ry}-${rm}-${rd} ${rh}:${rmin}:${rsec}`;
        }
        const matchTime = s.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
        if (matchTime) {
            const hh = Number(matchTime[1]);
            const mm = matchTime[2];
            const ss = matchTime[3];
            const newH = String((hh + 3) % 24).padStart(2, '0');
            if (ss !== undefined) {
                return `${newH}:${mm}:${ss}`;
            }
            return `${newH}:${mm}`;
        }
    } catch (e) {
        console.warn('formatTurkeyTime error:', e);
    }
    return timeStr;
}

const testCases = [
    "2026-11-15 13:27:55",
    "2026-11-15 22:30:00",
    "13:38:43",
    "23:15:00",
    "10:31",
    "",
    null,
    "Haber metni"
];

testCases.forEach(t => {
    console.log(JSON.stringify(t), "->", JSON.stringify(formatTurkeyTime(t)));
});
