import urllib.request
import json

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Antigravity"})

with urllib.request.urlopen(req, timeout=15) as resp:
    data = json.loads(resp.read().decode("utf-8"))

trades = data.get("trade_history", [])
print(f"Total trades on live Railway: {len(trades)}")
print("Latest 3 trades:")
for t in trades[:3]:
    print(t)

print("\nLooking for entry 547.94 / exit 554.38:")
for t in trades:
    entry = float(t.get("actual_entry_price") or t.get("entry_price") or 0.0)
    exit_p = float(t.get("exit_price") or 0.0)
    if abs(entry - 547.94) < 0.1 or abs(exit_p - 554.38) < 0.1:
        print("FOUND MATCH:", t)

