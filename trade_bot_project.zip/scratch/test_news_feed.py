import sys
import requests
import xml.etree.ElementTree as ET
import urllib.parse

def test_coin_news(coin_name: str, ticker: str):
    query = f"{ticker} OR {coin_name} crypto when:24h"
    encoded_query = urllib.parse.quote(query)
    url = f"https://news.google.com/rss/search?q={encoded_query}&hl=en-US&gl=US&ceid=US:en"
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    
    print(f"\n📡 Araştırılıyor: {coin_name} ({ticker})...")
    try:
        resp = requests.get(url, headers=headers, timeout=5)
        print(f"Status Code: {resp.status_code}")
        if resp.status_code == 200:
            root = ET.fromstring(resp.content)
            items = root.findall(".//item")
            print(f"Bulunan Haber Sayısı: {len(items)}")
            for idx, item in enumerate(items[:4]):
                title = item.find("title").text if item.find("title") is not None else ""
                source = item.find("source").text if item.find("source") is not None else "Google News"
                pub_date = item.find("pubDate").text if item.find("pubDate") is not None else ""
                print(f"  [{idx+1}] [{source}] {title}")
                print(f"      Tarih: {pub_date}")
    except Exception as e:
        print(f"Hata: {e}")

if __name__ == "__main__":
    test_coin_news("Solana", "SOL")
    test_coin_news("Ethereum", "ETH")
    test_coin_news("Dogecoin", "DOGE")
