import json

log_file = r'C:\Users\isiks\.gemini\antigravity\brain\a2f493b1-6bd2-4f3b-a3f9-f21e7725bbd5\.system_generated\logs\transcript_full.jsonl'

with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
    for line in f:
        if 'bu_haliyle_30d_sim' in line and '"name":"write_file"' in line:
            data = json.loads(line)
            calls = data.get('tool_calls', [])
            for c in calls:
                if 'write_file' in c.get('name', ''):
                    args = c.get('args', {})
                    path = args.get('Path', '')
                    print("Found write_file path:", path)
                    if 'sim' in path or 'scratch' in path:
                        print("Content snippet:\n", args.get('Content', '')[:1000])

