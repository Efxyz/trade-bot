with open("dashboard.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

print("Searching HTML/JS in dashboard.py for time-related displays...")
for i in range(40, 5300):
    line = lines[i]
    # Check for clock, time, header, date displays, scanner log times, news times, etc.
    if any(k in line.lower() for k in ["clock", "header-time", "timestamp", "last_update", "saat", "zaman", "dakika", "tarih", "time-badge", "datetime", "parse"]):
        print(f"L{i+1}: {line.strip()[:120]}")
