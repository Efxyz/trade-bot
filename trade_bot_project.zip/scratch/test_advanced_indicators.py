import sys
from pathlib import Path
import math
from typing import List, Dict, Tuple, Optional

# Let's test with real Binance data
sys.path.insert(0, r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
from core.binance_client import BinanceFuturesClient

client = BinanceFuturesClient()
candles_15m = client.get_klines("ETHUSDT", interval="15m", limit=80)
print(f"Fetched {len(candles_15m)} 15m candles for ETHUSDT.")

# ==========================================
# 1. LINEAR REGRESSION CHANNEL (OLS + 2 STD)
# ==========================================
def calculate_linear_regression_channel(candles: List[Dict], period: int = 40, num_std: float = 2.0) -> Dict:
    if len(candles) < period:
        return {"slope": 0.0, "baseline": 0.0, "upper": 0.0, "lower": 0.0, "position_pct": 50.0, "trend": "FLAT"}
    
    recent = candles[-period:]
    closes = [float(c["close"]) for c in recent]
    n = len(closes)
    x = list(range(n))
    
    # OLS Formula: y = slope * x + intercept
    sum_x = sum(x)
    sum_y = sum(closes)
    sum_xx = sum(xi * xi for xi in x)
    sum_xy = sum(xi * yi for xi, yi in zip(x, closes))
    
    denom = (n * sum_xx - sum_x * sum_x)
    if denom == 0:
        return {"slope": 0.0, "baseline": closes[-1], "upper": closes[-1], "lower": closes[-1], "position_pct": 50.0, "trend": "FLAT"}
    
    slope = (n * sum_xy - sum_x * sum_y) / denom
    intercept = (sum_y - slope * sum_x) / n
    
    # Current bar regression value (at x = n - 1)
    baseline = slope * (n - 1) + intercept
    
    # Calculate Standard Error (Residuals Std Dev)
    residuals = [(closes[i] - (slope * i + intercept)) for i in range(n)]
    variance = sum(r * r for r in residuals) / n
    std_dev = math.sqrt(variance)
    
    upper = baseline + (num_std * std_dev)
    lower = baseline - (num_std * std_dev)
    
    curr_price = closes[-1]
    channel_width = upper - lower
    pos_pct = ((curr_price - lower) / channel_width * 100.0) if channel_width > 0 else 50.0
    
    # Slope normalized to percent change over period
    slope_pct = (slope * n / baseline) * 100.0 if baseline > 0 else 0.0
    
    if slope_pct > 1.2:
        trend = "BULLISH_CHANNEL"
    elif slope_pct < -1.2:
        trend = "BEARISH_CHANNEL"
    else:
        trend = "HORIZONTAL_CHANNEL"
        
    return {
        "slope": round(slope, 6),
        "slope_pct": round(slope_pct, 2),
        "baseline": round(baseline, 4),
        "upper": round(upper, 4),
        "lower": round(lower, 4),
        "channel_width_pct": round((channel_width / baseline * 100.0) if baseline > 0 else 0.0, 2),
        "position_pct": round(pos_pct, 1),
        "trend": trend,
        "is_support_test": pos_pct <= 18.0,
        "is_resistance_test": pos_pct >= 82.0,
        "is_upper_breakout": curr_price > upper,
        "is_lower_breakdown": curr_price < lower
    }

lr_res = calculate_linear_regression_channel(candles_15m)
print("1. Linear Regression Channel Result:")
print("  ", lr_res)

# ==========================================
# 2. VOLUME PROFILE (POC, VAH, VAL)
# ==========================================
def calculate_volume_profile(candles: List[Dict], lookback: int = 48, bins: int = 30, value_area_pct: float = 0.70) -> Dict:
    if len(candles) < 20:
        return {"poc": 0.0, "vah": 0.0, "val": 0.0, "interaction": "NONE"}
    
    recent = candles[-min(len(candles), lookback):]
    highs = [float(c["high"]) for c in recent]
    lows = [float(c["low"]) for c in recent]
    
    max_p = max(highs)
    min_p = min(lows)
    
    if max_p == min_p:
        return {"poc": max_p, "vah": max_p, "val": min_p, "interaction": "NONE"}
    
    bin_width = (max_p - min_p) / bins
    bin_centers = [min_p + (i + 0.5) * bin_width for i in range(bins)]
    bin_volumes = [0.0] * bins
    
    for c in recent:
        c_h = float(c["high"])
        c_l = float(c["low"])
        c_vol = float(c["volume"])
        if c_h == c_l or c_vol <= 0:
            continue
            
        # Distribute candle volume to overlapping bins
        overlap_indices = [i for i, center in enumerate(bin_centers) if (center >= c_l - bin_width*0.5) and (center <= c_h + bin_width*0.5)]
        if overlap_indices:
            vol_per_bin = c_vol / len(overlap_indices)
            for idx in overlap_indices:
                bin_volumes[idx] += vol_per_bin
        else:
            # Fallback to closest bin
            c_close = float(c["close"])
            closest_idx = min(range(bins), key=lambda i: abs(bin_centers[i] - c_close))
            bin_volumes[closest_idx] += c_vol
            
    # Point of Control (POC): bin with maximum volume
    poc_idx = max(range(bins), key=lambda i: bin_volumes[i])
    poc_price = bin_centers[poc_idx]
    
    # Value Area: 70% of total volume expanding outward from POC
    total_vol = sum(bin_volumes)
    target_vol = total_vol * value_area_pct
    
    accum_vol = bin_volumes[poc_idx]
    up_idx = poc_idx
    down_idx = poc_idx
    
    while accum_vol < target_vol:
        next_up_vol = bin_volumes[up_idx + 1] if up_idx + 1 < bins else -1.0
        next_down_vol = bin_volumes[down_idx - 1] if down_idx - 1 >= 0 else -1.0
        
        if next_up_vol < 0 and next_down_vol < 0:
            break
            
        if next_up_vol >= next_down_vol:
            up_idx += 1
            accum_vol += bin_volumes[up_idx]
        else:
            down_idx -= 1
            accum_vol += bin_volumes[down_idx]
            
    val_price = bin_centers[down_idx]
    vah_price = bin_centers[up_idx]
    
    curr_price = float(candles[-1]["close"])
    
    # Interaction detection
    interaction = "INSIDE_VALUE_AREA"
    dist_poc_pct = abs(curr_price - poc_price) / curr_price * 100.0
    
    if curr_price > vah_price:
        interaction = "ABOVE_VAH_EXPANSION"
    elif curr_price < val_price:
        interaction = "BELOW_VAL_BREAKDOWN"
    elif dist_poc_pct <= 0.35:
        interaction = "AT_POC_LIQUIDITY_CORE"
        
    return {
        "poc": round(poc_price, 4),
        "vah": round(vah_price, 4),
        "val": round(val_price, 4),
        "dist_poc_pct": round(dist_poc_pct, 2),
        "interaction": interaction,
        "is_above_poc": curr_price > poc_price,
        "is_poc_retest": dist_poc_pct <= 0.40,
        "is_vah_breakout": curr_price >= vah_price * 0.998,
        "is_val_support": abs(curr_price - val_price) / curr_price * 100.0 <= 0.45
    }

vp_res = calculate_volume_profile(candles_15m)
print("\n2. Volume Profile Result:")
print("  ", vp_res)

# ==========================================
# 3. CAMARILLA INTRADAY PIVOTS
# ==========================================
def calculate_camarilla_pivots(candles: List[Dict], lookback_bars: int = 24) -> Dict:
    if len(candles) < 10:
        return {}
    
    # Standard: Use recent 24 bars (6 hours on 15m) or full day
    bars = candles[-min(len(candles), lookback_bars):]
    high = max(float(c["high"]) for c in bars[:-1]) if len(bars) > 1 else float(bars[0]["high"])
    low = min(float(c["low"]) for c in bars[:-1]) if len(bars) > 1 else float(bars[0]["low"])
    close = float(bars[-2]["close"]) if len(bars) > 1 else float(bars[-1]["close"])
    
    rng = high - low
    if rng <= 0:
        rng = close * 0.01
        
    pp = (high + low + close) / 3.0
    
    r4 = close + rng * (1.1 / 2.0)
    r3 = close + rng * (1.1 / 4.0)
    r2 = close + rng * (1.1 / 6.0)
    r1 = close + rng * (1.1 / 12.0)
    
    s1 = close - rng * (1.1 / 12.0)
    s2 = close - rng * (1.1 / 6.0)
    s3 = close - rng * (1.1 / 4.0)
    s4 = close - rng * (1.1 / 2.0)
    
    curr = float(candles[-1]["close"])
    
    return {
        "pp": round(pp, 4),
        "r4_breakout": round(r4, 4),
        "r3_reversal": round(r3, 4),
        "s3_reversal": round(s3, 4),
        "s4_breakdown": round(s4, 4),
        "is_above_h4": curr > r4,
        "is_near_h4_breakout": (curr >= r4 * 0.998) and (curr <= r4 * 1.01),
        "is_at_s3_support": abs(curr - s3) / curr * 100.0 <= 0.40,
        "is_below_s4": curr < s4,
        "is_near_s4_breakdown": (curr <= s4 * 1.002) and (curr >= s4 * 0.99)
    }

cam_res = calculate_camarilla_pivots(candles_15m)
print("\n3. Camarilla Pivots Result:")
print("  ", cam_res)
