import sys
import os
import time

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from sync_to_github import sync_file_to_github

files_to_sync = [
    ("core/advanced_indicators.py", "feat(ta): Add institutional advanced indicators (Linear Regression Channels, Volume Profile, Camarilla, RSI Divergence, ADX, Golden Pocket, SFP, SuperTrend)"),
    ("agents/ta_agent.py", "feat(ta): Integrate 8-module institutional TA engine & structure-aware dynamic stop-loss"),
    ("agents/fast_ta_agent.py", "feat(fast-ta): Add 1m Linear Regression Channel, Volume Profile POC & SFP liquidity sweep"),
    ("agents/super_fast_ta_agent.py", "feat(super-fast-ta): Add micro LR channel slope & Camarilla intraday pivot confirmation"),
    ("super_fast_engine.py", "refactor(super-fast): Extend 1m candle buffer to 30 for indicator calculations"),
    ("agents/chart_agent.py", "feat(charts): Render POC, Value Area, Camarilla, Golden Pocket & SuperTrend overlays on charts")
]

print("=" * 80)
print("🚀 GİTHUB VE RAILWAY SENKRONİZASYONU BAŞLATILIYOR (PATRON ONAYLI)")
print("=" * 80)

success_count = 0
for rel_path, msg in files_to_sync:
    print(f"\n📤 Yükleniyor: {rel_path}...")
    ok = sync_file_to_github(rel_path, msg)
    if ok:
        success_count += 1
    else:
        print(f"❌ {rel_path} yüklenemedi!")
    time.sleep(1.0) # Rate limit koruması

print("\n" + "=" * 80)
print(f"🏁 SENKRONİZASYON TAMAMLANDI: {success_count}/{len(files_to_sync)} dosya başarıyla GitHub'a aktarıldı.")
print("⚡ Railway CI/CD boru hattı otomatik olarak tetiklendi.")
print("=" * 80)
