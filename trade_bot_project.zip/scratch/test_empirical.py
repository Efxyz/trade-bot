import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.quant_simulation_agent import QuantSimulationAgent

client = BinanceFuturesClient()
coins = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "XRPUSDT", "BNBUSDT", "NEARUSDT", "SUIUSDT"]

for sym in coins:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    emp = QuantSimulationAgent.run_empirical_replay(c15m, "LONG", tp_pct=2.0, sl_pct=1.0, horizon_bars=24)
    print(f"{sym:<10}: Samples={emp['samples']}, TP={emp['tp_count']}, SL={emp['sl_count']}, GreenRate={emp['green_rate']}%, Approved={emp['is_approved']}")
