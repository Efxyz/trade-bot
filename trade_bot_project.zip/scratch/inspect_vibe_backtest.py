import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "Vibe-Trading-main", "Vibe-Trading-main", "agent", "backtest")

files = ["constraints.py", "correlation.py", "factor_costs.py", "perpetual_evidence.py"]
for f in files:
    fp = os.path.join(base, f)
    if os.path.exists(fp):
        print(f"=== {f} ===")
        with open(fp, 'r', encoding='utf-8', errors='ignore') as s:
            print(s.read()[:1500])
            print("\n----------------------------------------\n")

