import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
all_coins = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "NEARUSDT", "SUIUSDT",
    "AVAXUSDT", "XRPUSDT", "ADAUSDT", "LINKUSDT", "DOTUSDT", "BNBUSDT",
    "PEPEUSDT", "1000PEPEUSDT", "WIFUSDT", "FETUSDT", "RENDERUSDT", "TAOUSDT"
]

print("TARANAN PARİTELER VE GÜNCEL KALİBRE SKORLARI:")
print("=" * 60)

qualifying = []

for sym in all_coins:
    try:
        c15m = client.get_klines(sym, interval="15m", limit=60)
        c1h = client.get_klines(sym, interval="1h", limit=50)
        if not c15m or len(c15m) < 30:
            continue
            
        current_price = c15m[-1]["close"]
        closes_15m = [c["close"] for c in c15m]

        fvg = TechnicalAnalysisAgent.detect_fvg(c15m)
        ob = TechnicalAnalysisAgent.detect_order_blocks(c15m)
        squeeze = TechnicalAnalysisAgent.calculate_ttm_squeeze(c15m)
        ema20 = TechnicalAnalysisAgent.calculate_ema(closes_15m, 20)
        ema50 = TechnicalAnalysisAgent.calculate_ema(closes_15m, 50)
        rsi = TechnicalAnalysisAgent.calculate_rsi(closes_15m, 14)
        vwap = TechnicalAnalysisAgent.calculate_vwap(c15m)

        curr_ema20 = ema20[-1] if ema20 else 0
        curr_ema50 = ema50[-1] if ema50 else 0
        curr_rsi = rsi[-1] if rsi else 50
        curr_vwap = vwap[-1] if vwap else current_price

        # LONG SCORE
        l_score = 0
        if fvg.get("current_in_fvg") == "BULLISH_TEST":
            l_score += 15
        elif fvg.get("bullish_fvg"):
            age = fvg["bullish_fvg"].get("age_candles", 10)
            dist = abs(current_price - fvg["bullish_fvg"]["top"]) / current_price * 100.0
            if age <= 3:
                l_score += 15
            elif dist <= 1.20:
                l_score += 10

        if ob.get("current_at_ob") == "BULLISH_OB_RETEST":
            l_score += 12
        elif ob.get("bullish_ob"):
            dist_ob = abs(current_price - ob["bullish_ob"]["high"]) / current_price * 100.0
            if dist_ob <= 1.50:
                l_score += 8

        if squeeze.get("squeeze_fired") and squeeze.get("momentum") > 0:
            l_score += 25
        elif squeeze.get("momentum") > 0.5:
            l_score += 15

        if current_price > curr_vwap:
            l_score += 12

        prior_vols = [c["volume"] for c in c15m[-12:-2]]
        avg_v = sum(prior_vols) / len(prior_vols) if prior_vols else 1.0
        if c15m[-2]["volume"] >= avg_v * 0.85:
            l_score += 8

        if current_price > curr_ema20:
            l_score += 10 if curr_ema20 >= curr_ema50 else 7

        if 48 <= curr_rsi <= 68:
            l_score += 10

        status = "🔥 İŞLEM ONAYI (66+)" if l_score >= 66 else f"Normal ({l_score})"
        print(f"{sym:<12} | LONG Skor: {l_score:<3}/100 | {status}")
        if l_score >= 66:
            qualifying.append((sym, l_score))
    except Exception as e:
        pass

print("=" * 60)
print(f"66+ Barajını Geçen Fırsat Sayısı: {len(qualifying)}")
for s, sc in qualifying:
    print(f"  -> {s}: {sc} Puan")

