import urllib.request
import json
import time

url = "https://trade-bot-production-f1b1.up.railway.app/"
api_url = "https://trade-bot-production-f1b1.up.railway.app/api/data"

print(f"Polling Railway endpoint ({url})...")

for attempt in range(1, 13):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Antigravity"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            if resp.status == 200:
                print(f"🎉 Attempt {attempt}: RAILWAY ONLINE! Status: {resp.status} OK!")
                
                # Check api
                api_req = urllib.request.Request(api_url, headers={"User-Agent": "Antigravity"})
                with urllib.request.urlopen(api_req, timeout=8) as api_resp:
                    data = json.loads(api_resp.read().decode('utf-8'))
                    trades = data.get("trade_history", [])
                    stats = data.get("stats", {})
                    print(f"📊 Live API Check: {len(trades)} trades in history, Total Win Rate: {stats.get('win_rate', 'N/A')}%")
                break
    except Exception as e:
        print(f"Attempt {attempt} ({e}). Retrying in 5s...")
        time.sleep(5)

