import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config
config.MAX_VWAP_DISTANCE_PCT = 2.80

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

coins = ["ETHUSDT", "SUIUSDT", "NEARUSDT", "BNBUSDT", "FETUSDT", "DOGEUSDT", "BTCUSDT", "AVAXUSDT"]

for sym in coins:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    setup, reason = agent.analyze_setup(sym, c15m, c1h)
    
    status = "🔥 ONAYLANDI" if setup else "REDDEDİLDİ"
    score = setup["confluence_score"] if setup else "N/A"
    clean_r = reason.replace("📌", "").replace("⛔", "").replace("🎯", "").replace("<strong>", "").replace("</strong>", "").replace("<br>", " ")
    print(f"{sym:<10}: {status:<12} | Skor: {str(score):<4} | {clean_r[:80]}")
