import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.chart_agent import ChartAgent

client = BinanceFuturesClient()
ta_agent = TechnicalAnalysisAgent()
chart_agent = ChartAgent()

candles_15m = client.get_klines("BTCUSDT", "15m", limit=60)
candles_1h = client.get_klines("BTCUSDT", "1h", limit=30)
setup, reason = ta_agent.analyze_setup("BTCUSDT", candles_15m, candles_1h)

if setup:
    path = chart_agent.generate_chart(setup, candles_15m, suffix="test_overlay")
    print(f"✅ Grafik başarıyla üretildi: {path}")
    print(f"Dosya boyutu: {os.path.getsize(path)} bytes")
else:
    print(f"Setup üretilemedi: {reason}")
