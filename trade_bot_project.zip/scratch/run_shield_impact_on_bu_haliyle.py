import json
from pathlib import Path

path = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot\data\simulations\bu_haliyle_30d_sim_results.json")
with open(path, "r", encoding="utf-8") as f:
    data = json.load(f)

trades = data.get("trades", [])
print(f"Toplam İşlem Sayısı: {len(trades)}")

# Kara listedeki paritelerin etkisi
blacklist = ["LINKUSDT", "ARBUSDT", "INJUSDT", "APTUSDT"]
bl_trades = [t for t in trades if t['symbol'] in blacklist]
print(f"\nKara Listedeki Pariteler ({len(bl_trades)} işlem):")
bl_wins = [t for t in bl_trades if t['dollar_gain'] > 0]
bl_losses = [t for t in bl_trades if t['dollar_gain'] < 0]
bl_net = sum(t['dollar_gain'] for t in bl_trades)
print(f"  • Kazanılan: {len(bl_wins)}, Kaybedilen: {len(bl_losses)}, Net Zarar: ${bl_net:+.2f}")

# SHORT işlemlerin analizi
short_trades = [t for t in trades if t['direction'] == 'SHORT']
print(f"\nSHORT İşlemler ({len(short_trades)} işlem):")
short_wins = [t for t in short_trades if t['dollar_gain'] > 0]
short_losses = [t for t in short_trades if t['dollar_gain'] < 0]
short_net = sum(t['dollar_gain'] for t in short_trades)
print(f"  • Kazanılan: {len(short_wins)}, Kaybedilen: {len(short_losses)}, Net Zarar: ${short_net:+.2f}")

# LONG işlemlerin analizi
long_trades = [t for t in trades if t['direction'] == 'LONG']
print(f"\nLONG İşlemler ({len(long_trades)} işlem):")
long_wins = [t for t in long_trades if t['dollar_gain'] > 0]
long_losses = [t for t in long_trades if t['dollar_gain'] < 0]
long_net = sum(t['dollar_gain'] for t in long_trades)
print(f"  • Kazanılan: {len(long_wins)}, Kaybedilen: {len(long_losses)}, Net Kâr/Zarar: ${long_net:+.2f}")

# Freqtrade Kalkanı ve Kara Liste uygulandığında kalan portföy:
clean_trades = [t for t in trades if t['symbol'] not in blacklist]
clean_net = sum(t['dollar_gain'] for t in clean_trades)
clean_wins = [t for t in clean_trades if t['dollar_gain'] > 0]
clean_losses = [t for t in clean_trades if t['dollar_gain'] < 0]
clean_wr = len(clean_wins) / len(clean_trades) * 100 if clean_trades else 0
print(f"\n🛡️ Kara Liste Temizlendikten Sonra:")
print(f"  • Kalan İşlemler: {len(clean_trades)}")
print(f"  • Kazanılan: {len(clean_wins)} | Kaybedilen: {len(clean_losses)} | Win Rate: %{clean_wr:.1f}")
print(f"  • Net Finansal Sonuç: ${clean_net:+.2f} (Eski: ${data['net_dollar']:+.2f})")
print(f"  • Kurtarılan Sermaye: ${clean_net - data['net_dollar']:+.2f}")

