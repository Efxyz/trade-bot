import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent

client = BinanceFuturesClient()
ta_agent = TechnicalAnalysisAgent()
quant_agent = QuantSimulationAgent()

c15m = client.get_klines("BTCUSDT", interval="15m", limit=60)
c1h = client.get_klines("BTCUSDT", interval="1h", limit=50)

# Force bypass volume check for test
setup = {
    "symbol": "BTCUSDT",
    "direction": "LONG",
    "actual_entry_price": c15m[-1]["close"],
    "stop_loss": c15m[-1]["close"] * 0.9885, # -1.15%
    "take_profit_1": c15m[-1]["close"] * 1.0207, # +2.07%
    "sl_pct": 1.15,
    "tp1_pct": 2.07,
    "risk_reward": 1.8,
    "current_price": c15m[-1]["close"]
}

sim = quant_agent.simulate_setup("BTCUSDT", setup, c15m, num_simulations=10000)
print("Monte Carlo Simulation Results for BTCUSDT (1:1.8 R:R):")
print("  Win Probability (TP1):", sim.get("win_probability_pct"), "%")
print("  Loss Probability (SL):", sim.get("loss_probability_pct"), "%")
print("  Expected R:", sim.get("expected_r"), "R")
print("  Current win_threshold_pct:", quant_agent.win_threshold_pct, "%")
print("  Is Approved under 70% threshold:", sim.get("is_approved"))
