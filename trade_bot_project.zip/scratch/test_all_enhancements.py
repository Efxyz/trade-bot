import sys, os
sys.path.insert(0, os.getcwd())

import py_compile
from config import LADDER_STEPS, SIDE_STOPLOSS_GUARD_ENABLED, SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES, SIDE_STOPLOSS_COOLDOWN_MINUTES, EARLY_INVALIDATION_MINUTES, EARLY_INVALIDATION_LOSS_PCT
from core.database import check_side_stoploss_guard
from core.quant_knowledge_base import QuantKnowledgeBase

print("=== 1. Checking Configuration Values ===")
print(f"LADDER_STEPS (count: {len(LADDER_STEPS)}):")
for step in LADDER_STEPS:
    print(f"  Step {step['step']}: Trigger +{step['trigger_raw_pct']}% -> Lock +{step['lock_raw_pct']}% ({step['name']})")

print(f"\nSIDE_STOPLOSS_GUARD_ENABLED: {SIDE_STOPLOSS_GUARD_ENABLED}")
print(f"SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES: {SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES}")
print(f"SIDE_STOPLOSS_COOLDOWN_MINUTES: {SIDE_STOPLOSS_COOLDOWN_MINUTES}")
print(f"EARLY_INVALIDATION_MINUTES: {EARLY_INVALIDATION_MINUTES}")
print(f"EARLY_INVALIDATION_LOSS_PCT: {EARLY_INVALIDATION_LOSS_PCT}")

print("\n=== 2. Testing QuantKnowledgeBase ===")
locked, rem = QuantKnowledgeBase.calculate_frequency_stoploss_guard(consecutive_losses=2, max_allowed=2, cooldown_minutes=120)
print(f"Freqtrade Stoploss Guard check (2 losses): locked={locked}, remaining={rem} min")
imbalance = QuantKnowledgeBase.calculate_orderbook_imbalance(
    bids=[[100, 5], [99, 10]],
    asks=[[101, 1], [102, 2]]
)
print(f"Hummingbot Orderbook Imbalance (Bids 15 vs Asks 3): {imbalance:.2f} (Alıcı Baskısı)")

print("\n=== 3. Testing Side Guard in Database ===")
is_locked, reason = check_side_stoploss_guard("SHORT", 2, 120)
print(f"SHORT side guard: is_locked={is_locked}, reason={reason}")

is_locked_long, reason_long = check_side_stoploss_guard("LONG", 2, 120)
print(f"LONG side guard: is_locked={is_locked_long}, reason={reason_long}")

print("\n=== 4. Testing XMRUSDT Scenario Simulation ===")
entry = 547.94
lowest = 545.68 # XMRUSDT hit this!
raw_profit_pct = (entry - lowest) / entry * 100 # +0.4124%
print(f"Simulated XMRUSDT Entry: {entry}, Lowest: {lowest}, Peak Profit: +{raw_profit_pct:.4f}%")

triggered_step = None
for s in LADDER_STEPS:
    if raw_profit_pct >= s["trigger_raw_pct"]:
        triggered_step = s

if triggered_step:
    candidate_sl = round(entry * (1.0 - (triggered_step["lock_raw_pct"] / 100.0)), 6)
    print(f"SUCCESS! {triggered_step['name']} TRIGGERED!")
    print(f"New SL set to: {candidate_sl} (+{triggered_step['lock_raw_pct']}% BE+ profit)")
    print(f"When price rebounded back to entry ({entry}) or higher, it stopped out at {candidate_sl} -> PROTECTED at Breakeven!")
else:
    print("FAILED! No ladder step triggered.")

print("\n=== 5. Syntax Verification of All Modified Files ===")
files_to_check = [
    "config.py",
    "core/database.py",
    "core/quant_knowledge_base.py",
    "agents/risk_agent.py",
    "agents/ta_agent.py",
    "agents/tracker_agent.py",
    "main.py"
]
for f in files_to_check:
    py_compile.compile(f, doraise=True)
    print(f"✅ {f} compiled cleanly!")

print("\nALL VERIFICATIONS PASSED SUCCESSFULLY!")

