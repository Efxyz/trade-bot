import urllib.request
import time

url = "https://trade-bot-production-f1b1.up.railway.app/"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})

for i in range(12):
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            html = resp.read().decode("utf-8")
            if "formatTurkeyTime" in html and "topTrClock" in html:
                print(f"✅ Railway üzerinde YENİ PANEL YAYINDA! (Deneme {i+1})")
                break
            else:
                print(f"⏳ Railway derleniyor... (Deneme {i+1})")
    except Exception as e:
        print(f"⚠️ Bağlantı: {e} (Deneme {i+1})")
    time.sleep(5)
