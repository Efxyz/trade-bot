import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()

for sym in ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "NEARUSDT", "SUIUSDT"]:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    
    current_price = c15m[-1]["close"]
    closes_15m = [c["close"] for c in c15m]

    fvg = TechnicalAnalysisAgent.detect_fvg(c15m)
    ob = TechnicalAnalysisAgent.detect_order_blocks(c15m)
    squeeze = TechnicalAnalysisAgent.calculate_ttm_squeeze(c15m)
    ema20 = TechnicalAnalysisAgent.calculate_ema(closes_15m, 20)
    ema50 = TechnicalAnalysisAgent.calculate_ema(closes_15m, 50)
    rsi = TechnicalAnalysisAgent.calculate_rsi(closes_15m, 14)
    vwap = TechnicalAnalysisAgent.calculate_vwap(c15m)

    curr_ema20 = ema20[-1] if ema20 else 0
    curr_ema50 = ema50[-1] if ema50 else 0
    curr_rsi = rsi[-1] if rsi else 50
    curr_vwap = vwap[-1] if vwap else current_price

    # SIMULATE TUNED SCORING:
    score = 0
    factors = []

    # 1. FVG: Fresh (<4 candles) or within 1.2%
    if fvg.get("current_in_fvg") == "BULLISH_TEST":
        score += 15
        factors.append("FVG Test Desteği (+15)")
    elif fvg.get("bullish_fvg"):
        dist_pct = abs(current_price - fvg["bullish_fvg"]["top"]) / current_price * 100.0
        age = fvg["bullish_fvg"].get("age_candles", 10)
        if age <= 3:
            score += 15
            factors.append(f"Taze Bullish FVG Oluşumu (Yaş: {age} mum) (+15)")
        elif dist_pct <= 1.20:
            score += 10
            factors.append(f"Bullish FVG Yakınlığı (%{dist_pct:.2f}) (+10)")

    # 2. OB: Fresh or within 1.2%
    if ob.get("current_at_ob") == "BULLISH_OB_RETEST":
        score += 12
        factors.append("OB Retest (+12)")
    elif ob.get("bullish_ob"):
        dist_ob = abs(current_price - ob["bullish_ob"]["high"]) / current_price * 100.0
        if dist_ob <= 1.50:
            score += 8
            factors.append(f"OB Desteği Yakınlığı (%{dist_ob:.2f}) (+8)")

    # 3. Squeeze
    if squeeze.get("squeeze_fired") and squeeze.get("momentum") > 0:
        score += 25
        factors.append("Squeeze Patlaması (+25)")
    elif squeeze.get("momentum") > 0.5:
        score += 15
        factors.append("Volatilite İvmesi (+15)")

    # 4. VWAP
    if current_price > curr_vwap:
        score += 12
        factors.append("VWAP Üzeri (+12)")

    # 5. Volume: Check completed candle (c15m[-2]) or burst
    prior_vols = [c["volume"] for c in c15m[-12:-2]]
    avg_v = sum(prior_vols) / len(prior_vols) if prior_vols else 1.0
    if c15m[-2]["volume"] > avg_v * 0.90:
        score += 8
        factors.append("Sağlıklı Hacim (+8)")

    # 6. EMA
    if current_price > curr_ema20:
        if curr_ema20 >= curr_ema50:
            score += 10
            factors.append("EMA 20>50 Trend (+10)")
        else:
            score += 7
            factors.append("EMA 20 Üzeri İvme (+7)")

    # 7. RSI
    if 48 <= curr_rsi <= 68:
        score += 10
        factors.append(f"RSI İdeal ({curr_rsi:.1f}) (+10)")

    print(f"\n{sym}: ESKİ SKOR: ~25-37 | YENİ KALİBRE SKOR: {score}/100")
    print("  Faktörler:", ", ".join(factors))

