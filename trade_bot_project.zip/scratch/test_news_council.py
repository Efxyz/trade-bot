import sys
import os
import requests
import xml.etree.ElementTree as ET
import urllib.parse
from datetime import datetime

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

# Comprehensive crypto symbol mapping
SYMBOL_NAMES = {
    "BTC": "Bitcoin", "ETH": "Ethereum", "SOL": "Solana", "DOGE": "Dogecoin",
    "AVAX": "Avalanche", "XRP": "XRP Ripple", "ADA": "Cardano", "BNB": "Binance Coin",
    "LINK": "Chainlink", "SUI": "Sui Network", "NEAR": "NEAR Protocol", "PEPE": "Pepe",
    "SHIB": "Shiba Inu", "APT": "Aptos", "INJ": "Injective", "TIA": "Celestia",
    "KAVA": "Kava", "AR": "Arweave", "SEI": "Sei Network", "WIF": "dogwifhat",
    "RENDER": "Render Token", "FET": "Fetch.ai", "FETUSDT": "Fetch.ai",
    "LTC": "Litecoin", "BCH": "Bitcoin Cash", "ATOM": "Cosmos", "DOT": "Polkadot"
}

BLACK_SWAN_KEYWORDS = [
    "HACK", "EXPLOIT", "STOLEN", "DRAINED", "VULNERABILITY",
    "SEC LAWSUIT", "SEC CHARGES", "SUBPOENA", "FRAUD", "INDICTMENT",
    "BAN", "BANNED", "DELIST", "DELISTING", "BANKRUPT", "INSOLVENCY"
]

BULLISH_CATALYST_KEYWORDS = [
    "ETF APPROV", "PARTNERSHIP", "LISTED ON", "LISTING", "MAINNET",
    "TOKEN BURN", "BUYBACK", "UPGRADE", "WHALE ACCUMULATION", "ADOPTION"
]

BEARISH_KEYWORDS = [
    "DROP", "DUMP", "FALL", "CRASH", "BEARISH", "UNLOCK", "DILUTION",
    "OUTFLOW", "LIQUIDATION", "SELLING PRESSURE", "INVESTIGATION"
]

BULLISH_KEYWORDS = [
    "SURGE", "RALLY", "BREAKOUT", "BULLISH", "GAINS", "INFLOW",
    "REBOUND", "RECOVERY", "GROWTH", "ALL-TIME HIGH", "ATH"
]

def fetch_coin_news_raw(symbol: str):
    clean = symbol.replace("USDT", "").replace("USDC", "").replace(".P", "")
    full_name = SYMBOL_NAMES.get(clean, clean)
    
    query = f"{clean} OR {full_name} crypto when:24h"
    url = f"https://news.google.com/rss/search?q={urllib.parse.quote(query)}&hl=en-US&gl=US&ceid=US:en"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    
    articles = []
    try:
        resp = requests.get(url, headers=headers, timeout=4)
        if resp.status_code == 200:
            root = ET.fromstring(resp.content)
            for item in root.findall(".//item")[:10]:
                title = item.find("title").text if item.find("title") is not None else ""
                source = item.find("source").text if item.find("source") is not None else "Haber Kaynağı"
                link = item.find("link").text if item.find("link") is not None else ""
                pub_date = item.find("pubDate").text if item.find("pubDate") is not None else ""
                if title:
                    articles.append({
                        "title": title,
                        "source": source,
                        "link": link,
                        "date": pub_date
                    })
    except Exception as e:
        print(f"Fetch error: {e}")
        
    return articles, clean, full_name

def evaluate_news_council(symbol: str, direction: str, funding_data=None):
    articles, clean, full_name = fetch_coin_news_raw(symbol)
    
    base_score = 50.0 # Nötr taban
    black_swan_detected = False
    bullish_catalyst_detected = False
    bearish_fud_detected = False
    detected_reasons = []
    
    for a in articles:
        t_upper = a["title"].upper()
        # 1. Kara Kuğu Denetimi
        for kw in BLACK_SWAN_KEYWORDS:
            if kw in t_upper:
                black_swan_detected = True
                base_score -= 30
                detected_reasons.append(f"🚨 KRİTİK: {a['source']} - '{a['title']}' ({kw})")
                break
                
        # 2. Güçlü Boğa Katalizörü
        for kw in BULLISH_CATALYST_KEYWORDS:
            if kw in t_upper:
                bullish_catalyst_detected = True
                base_score += 20
                detected_reasons.append(f"🚀 BOĞA: {a['source']} - '{a['title']}' ({kw})")
                break
                
        # 3. Ayı FUD / Düşüş
        for kw in BEARISH_KEYWORDS:
            if kw in t_upper:
                bearish_fud_detected = True
                base_score -= 8
                break
                
        # 4. Genel Boğa
        for kw in BULLISH_KEYWORDS:
            if kw in t_upper:
                base_score += 8
                break

    # Puanı 0-100 arasına sınırla
    news_score = max(0, min(100, int(base_score)))
    
    # Konsey Masalarının Değerlendirmeleri (3 Uzman Masa)
    # Masa 1: Regülasyon & Hukuk Şefi
    if any("SEC" in r or "LAWSUIT" in r or "BAN" in r for r in detected_reasons):
        reg_verdict = "⚠️ Regülasyon ve yasal soruşturma baskısı var. Risk çok yüksek."
    elif any("ETF" in r for r in detected_reasons):
        reg_verdict = "🏛️ Kurumsal onay ve ETF rüzgarı lehimize esiyor."
    else:
        reg_verdict = "✅ Yasal ve regülatif cephede majör bir engel tespit edilmedi."

    # Masa 2: Protokol & Güvenlik Şefi
    if black_swan_detected:
        sec_verdict = "🚨 KRİTİK ALARM: Akıllı sözleşme açığı, hack veya tasfiye şüphesi! LONG ASLA AÇILAMAZ."
    elif bullish_catalyst_detected:
        sec_verdict = "⚡ Protokolde güçlü güncelleme, yakım veya ekosistem ortaklığı teyit edildi."
    else:
        sec_verdict = "🛡️ Protokol güvenliği stabil, olağandışı kilit açılımı veya açık görünmüyor."

    # Masa 3: Balina & Sosyal Hype Masası (X / Twitter)
    if news_score >= 65:
        hype_verdict = f"📈 Sosyal medyada ve X üzerinde {clean} için pozitif ivme ve FOMO hakim."
    elif news_score <= 35:
        hype_verdict = f"🩸 X ve kripto çevrelerinde negatif panik satışı ve FUD baskısı mevcut."
    else:
        hype_verdict = "⚖️ Sosyal hacim dengeli, yapay spekülasyon veya toplu panik yok."

    # Kararlandırma ve Yüzdelik Pozisyon Büyüklüğü (Position Size Multiplier)
    is_vetoed = False
    veto_reason = ""
    pos_multiplier = 1.0 # %100 standart marjin
    
    if direction == "LONG":
        if black_swan_detected or news_score < 30:
            is_vetoed = True
            pos_multiplier = 0.0
            veto_reason = f"Haber Konseyi Veto Etti (Skor: {news_score}/100): Kritik Ayı / Kara Kuğu Haberi Mevcut!"
            verdict = "🚨 KRİTİK KARA KUĞU VETOSU"
        elif news_score >= 75:
            pos_multiplier = 1.25 # Marjini %25 artır (+%25 Hacim)
            verdict = "GÜÇLÜ BOĞA KATALİZÖRÜ (+%25 Hacim)"
        elif news_score >= 60:
            pos_multiplier = 1.10 # Marjini %10 artır
            verdict = "POZİTİF HABER RÜZGARI"
        elif news_score < 45:
            pos_multiplier = 0.60 # Marjini %40 kıs (Defansif)
            verdict = "ŞÜPHELİ AYI BASKISI (-%40 Defansif Kasa)"
        else:
            pos_multiplier = 1.0
            verdict = "ORGANİK TEKNİK AKIŞ / NÖTR"
    else: # SHORT
        if bullish_catalyst_detected and news_score > 70:
            is_vetoed = True
            pos_multiplier = 0.0
            veto_reason = f"Haber Konseyi Veto Etti (Skor: {news_score}/100): Güçlü Boğa Katalizörü Varken SHORT Açılmaz!"
            verdict = "🚨 BOĞA RALLİSİ VETOSU"
        elif black_swan_detected or news_score <= 30:
            pos_multiplier = 1.25 # Kötü haberde SHORT'u güçlendir!
            verdict = "AYI ÇÖKÜŞ KATALİZÖRÜ (+%25 SHORT Hacmi)"
        elif news_score <= 45:
            pos_multiplier = 1.10
            verdict = "NEGATİF HABER DESTEĞİ"
        elif news_score > 55:
            pos_multiplier = 0.60 # Ters rüzgarda SHORT marjinini kıs
            verdict = "BOĞA BASKISI (-%40 Defansif Kasa)"
        else:
            pos_multiplier = 1.0
            verdict = "ORGANİK TEKNİK AKIŞ / NÖTR"

    return {
        "symbol": symbol,
        "coin_name": full_name,
        "direction": direction,
        "news_score": news_score,
        "verdict": verdict,
        "is_vetoed": is_vetoed,
        "veto_reason": veto_reason,
        "pos_multiplier": pos_multiplier,
        "article_count": len(articles),
        "top_articles": articles[:4],
        "council_debate": [
            f"🏛️ [Regülasyon Şefi]: {reg_verdict}",
            f"🔐 [Protokol & Güvenlik]: {sec_verdict}",
            f"🐋 [Balina & X/Twitter Masası]: {hype_verdict}"
        ],
        "summary": f"Konsey Skoru: {news_score}/100 | {verdict} (Kasa Çarpanı: {pos_multiplier}x)"
    }

if __name__ == "__main__":
    print("=" * 80)
    print("🧪 HABER KARARLANDIRMA KONSEYİ TESTİ")
    print("=" * 80)
    for sym, d in [("SOLUSDT", "LONG"), ("ETHUSDT", "SHORT"), ("KAVAUSDT", "LONG")]:
        res = evaluate_news_council(sym, d)
        print(f"\n📊 {res['symbol']} ({res['coin_name']}) | Yön: {res['direction']}")
        print(f"   Karar: {res['verdict']} | Konsey Skoru: {res['news_score']}/100 | Çarpan: {res['pos_multiplier']}x")
        print(f"   Veto Edildi mi?: {'❌ EVET: ' + res['veto_reason'] if res['is_vetoed'] else '✅ HAYIR (İşlem Onaylı)'}")
        print("   Konsey Masası Tartışması:")
        for quote in res["council_debate"]:
            print("     ", quote)
        print(f"   İncelenen {res['article_count']} Haberden Örnekler:")
        for a in res["top_articles"][:2]:
            print(f"      - [{a['source']}] {a['title'][:70]}")
