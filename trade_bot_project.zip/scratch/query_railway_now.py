import urllib.request
import json

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        d = json.loads(resp.read().decode())
        print("=== STATS ===")
        print(json.dumps(d.get("stats", {}), indent=2))
        print("\n=== BTC REGIME ===")
        print(json.dumps(d.get("btc_regime", {}), indent=2))
        print("\n=== RECENT 15 SCANNER LOGS ===")
        for l in d.get("scanner_logs", [])[:15]:
            t = l.get("time")
            s = l.get("symbol")
            st = l.get("status")
            r = l.get("reason", "")
            print(f"[{t}] {s} | {st} | {r}")
except Exception as e:
    print("Error:", e)

