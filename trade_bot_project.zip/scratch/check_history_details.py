import urllib.request, json
url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req) as resp:
    data = json.loads(resp.read().decode("utf-8"))
trades = data.get("trade_history", [])
print(f"Total trades: {len(trades)}")
for i, t in enumerate(trades):
    sym = t.get("symbol")
    status = t.get("status")
    pnl = t.get("pnl_pct")
    dt = t.get("closed_at") or t.get("created_at")
    print(f"{i+1:2d}. [{dt}] {sym:<12} | Status: {status:<18} | pnl_pct: {pnl}")

