import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "AI-Trader-main", "AI-Trader-main")

with open(os.path.join(base, "docs", "README_AGENT.md"), 'r', encoding='utf-8', errors='ignore') as f:
    print("=== README_AGENT.md ===")
    print(f.read()[:2000])

with open(os.path.join(base, "research", "scripts", "build_agent_features.py"), 'r', encoding='utf-8', errors='ignore') as f:
    print("\n=== build_agent_features.py ===")
    print(f.read()[:2000])

