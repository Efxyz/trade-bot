import requests
import xml.etree.ElementTree as ET

feeds = [
    ("Cointelegraph", "https://cointelegraph.com/rss"),
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"),
    ("Decrypt", "https://decrypt.co/feed"),
    ("The Block", "https://www.theblock.co/rss.xml"),
    ("CryptoPanic Public RSS", "https://cryptopanic.com/news/rss/")
]

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

print("=" * 80)
print("Testing Major Crypto News Feeds:")
print("=" * 80)

for name, url in feeds:
    try:
        resp = requests.get(url, headers=headers, timeout=4)
        if resp.status_code == 200:
            root = ET.fromstring(resp.content)
            items = root.findall(".//item")
            print(f"✅ {name}: {len(items)} haber bulundu.")
            if items:
                first_title = items[0].find("title").text if items[0].find("title") is not None else ""
                print(f"   Son Başlık: {first_title[:75]}...")
        else:
            print(f"⚠️ {name}: HTTP {resp.status_code}")
    except Exception as e:
        print(f"❌ {name}: Hata ({e})")
