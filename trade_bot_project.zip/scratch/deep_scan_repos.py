import os
import json

base_dir = os.path.join(os.getcwd(), "scratch", "extracted_repos")

def scan_repo(name, subpath):
    full_path = os.path.join(base_dir, name, subpath)
    if not os.path.exists(full_path):
        full_path = os.path.join(base_dir, name)
    
    print(f"\n=======================================================")
    print(f"REPO: {name} (Path: {full_path})")
    print(f"=======================================================")
    
    file_list = []
    py_files = []
    md_files = []
    json_files = []
    
    for root, dirs, files in os.walk(full_path):
        for f in files:
            p = os.path.join(root, f)
            rel = os.path.relpath(p, full_path)
            file_list.append(rel)
            if f.endswith('.py'):
                py_files.append(rel)
            elif f.endswith('.md'):
                md_files.append(rel)
            elif f.endswith('.json') or f.endswith('.yaml') or f.endswith('.yml'):
                json_files.append(rel)
                
    print(f"Total files: {len(file_list)} | Python: {len(py_files)} | Markdown: {len(md_files)} | Configs: {len(json_files)}")
    print(f"Sample Markdown files: {md_files[:6]}")
    print(f"Sample Python files: {py_files[:15]}")
    return full_path, py_files, md_files

repos = [
    ("AI-Trader-main", "AI-Trader-main"),
    ("Vibe-Trading-main", "Vibe-Trading-main"),
    ("binance-trade-bot-master", "binance-trade-bot-master"),
    ("day-trader-skill-main", "day-trader-skill-main"),
    ("freqtrade-develop", "freqtrade-develop"),
    ("hummingbot-master", "hummingbot-master")
]

for rname, rsub in repos:
    scan_repo(rname, rsub)

