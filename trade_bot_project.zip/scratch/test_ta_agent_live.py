import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

test_coins = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "XRPUSDT", "SUIUSDT", "DASHUSDT", "NEARUSDT", "AVAXUSDT"]

print(f"{'SYMBOL':<12} | {'SETUP':<10} | {'SCORE':<6} | {'REASON / DETAILS'}")
print("-" * 80)

for sym in test_coins:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    setup, reason = agent.analyze_setup(sym, c15m, c1h)
    
    score = setup["confluence_score"] if setup else "N/A"
    direction = setup["direction"] if setup else "REJECTED"
    clean_reason = reason.replace("📌", "").replace("⛔", "").replace("🎯", "").replace("<strong>", "").replace("</strong>", "").replace("<br>", " ")
    print(f"{sym:<12} | {direction:<10} | {str(score):<6} | {clean_reason[:80]}")
