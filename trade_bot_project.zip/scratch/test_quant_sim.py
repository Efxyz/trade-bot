import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent

client = BinanceFuturesClient()
ta_agent = TechnicalAnalysisAgent()
quant_agent = QuantSimulationAgent()

for sym in ["BTCUSDT", "ETHUSDT", "BNBUSDT"]:
    c15m = client.get_klines(sym, interval="15m", limit=60)
    c1h = client.get_klines(sym, interval="1h", limit=50)
    setup, reason = ta_agent.analyze_setup(sym, c15m, c1h)
    print(f"{sym}: setup={bool(setup)}, reason={reason[:60]}")
    if setup:
        sim = quant_agent.simulate_setup(sym, setup, c15m, num_simulations=10000)
        print(f"  Win Prob: {sim.get('win_probability_pct')}%")
        print(f"  Expected R: {sim.get('expected_r'):+.3f}R")
        print(f"  Approved: {sim.get('is_approved')}")
