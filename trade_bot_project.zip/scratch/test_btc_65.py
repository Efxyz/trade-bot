import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config
config.MIN_CONFLUENCE_SCORE = 65

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

c15m = client.get_klines("BTCUSDT", interval="15m", limit=60)
c1h = client.get_klines("BTCUSDT", interval="1h", limit=50)
setup, reason = agent.analyze_setup("BTCUSDT", c15m, c1h)
print("BTC Setup:", bool(setup))
if setup:
    print("Direction:", setup["direction"])
    print("Score:", setup["confluence_score"])
    print("Entry Price:", setup["actual_entry_price"])
    print("Stop Loss:", setup["stop_loss"], f"(-%{setup['sl_pct']}%)")
    print("Take Profit:", setup["take_profit_1"], f"(+%{setup['tp1_pct']}%)")
    print("Risk/Reward:", setup["risk_reward"])
    print("TA Reason:", setup["ta_reasons"])
else:
    print("Reason:", reason)

