import json
import os

with open(r'data\simulations\sim_current_bot_30d_results.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

trades = data.get('trades', [])
early_exits = [t for t in trades if t['status'] == 'EARLY_INVALIDATION_EXIT']

with open(r'scratch\cached_30d_candles.json', 'r', encoding='utf-8') as f:
    cache = json.load(f)

print("Checking what happened to early invalidation trades if held to normal SL/TP/Timeout:")
tp_recovered = 0
sl_hit = 0
timeout_win = 0
be_recovered = 0

for t in early_exits:
    sym = t['symbol']
    d = t['direction']
    entry = t['entry_price']
    candles = cache.get(sym, [])
    # find entry candle
    entry_idx = None
    for i, c in enumerate(candles):
        if abs(c['close'] - entry) < 1e-5 or abs(c['open'] - entry) < 1e-5:
            entry_idx = i
            break
    if entry_idx is None:
        continue
    
    # check next 12 candles (3 hours)
    future = candles[entry_idx+1:entry_idx+13]
    if not future:
        continue
    
    # check if high reached +1.5% or +2.0%
    if d == 'LONG':
        max_future = max(c['high'] for c in future)
        min_future = min(c['low'] for c in future)
        max_pct = (max_future - entry) / entry * 100
        min_pct = (entry - min_future) / entry * 100
    else:
        max_future = min(c['low'] for c in future)
        min_future = max(c['high'] for c in future)
        max_pct = (entry - max_future) / entry * 100
        min_pct = (min_future - entry) / entry * 100
        
    print(f"{sym} {d} max gain in next 3h: +{max_pct:.2f}% | max dip: -{min_pct:.2f}%")
    if max_pct >= 1.5:
        tp_recovered += 1
    elif max_pct >= 0.5:
        be_recovered += 1
    elif min_pct >= 1.15:
        sl_hit += 1
    else:
        timeout_win += 1

print(f"\nSummary of 22 premature exits:")
print(f"Reached +1.5% or TP: {tp_recovered}")
print(f"Reached +0.5% (BE+ Lock): {be_recovered}")
print(f"Actually hit full SL (-1.15%): {sl_hit}")

