import sqlite3

conn = sqlite3.connect(r'data\trading_bot.db')
cursor = conn.cursor()
tables = cursor.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
print("Tables in data/trading_bot.db:", tables)

for t in tables:
    name = t[0]
    count = cursor.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
    print(f"Table {name}: {count} rows")
    if name in ['signals', 'trades', 'positions', 'history']:
        last_rows = cursor.execute(f"SELECT * FROM {name} ORDER BY rowid DESC LIMIT 3").fetchall()
        cols = [d[0] for d in cursor.description]
        print(f"--- Last 3 in {name} ---")
        for r in last_rows:
            d = dict(zip(cols, r))
            # print concise
            print({k: d[k] for k in ['id', 'symbol', 'direction', 'actual_entry_price', 'exit_price', 'status', 'simulated_pnl_pct', 'gross_pnl_pct', 'closed_at'] if k in d})

conn.close()

