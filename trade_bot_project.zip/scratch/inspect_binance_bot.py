import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "binance-trade-bot-master", "binance-trade-bot-master", "binance_trade_bot")

print("=== BINANCE TRADE BOT SCAN ===")
print("Files:", os.listdir(base))

# Read strategies/README.md or strategies/*.py
strat_dir = os.path.join(base, "strategies")
if os.path.exists(strat_dir):
    print("Strategies:", os.listdir(strat_dir))
    for s in os.listdir(strat_dir):
        if s.endswith('.py') and not s.startswith('__'):
            print(f"\n--- Strategy: {s} ---")
            with open(os.path.join(strat_dir, s), 'r', encoding='utf-8') as fp:
                print(fp.read()[:1000])

# Read crypto_trading.py or auto_trader.py
at_file = os.path.join(base, "auto_trader.py")
if os.path.exists(at_file):
    print("\n--- auto_trader.py snippet ---")
    with open(at_file, 'r', encoding='utf-8') as fp:
        print(fp.read()[:1200])

