import sys
from pathlib import Path

env_file = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot\.env")
if env_file.exists():
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            v = v.strip()
            masked = v[:4] + "..." + v[-4:] if len(v) > 8 else "***"
            print(f"Local Key: {k} | Masked: {masked} | Length: {len(v)}")
