import json
import os
import sys
from bisect import bisect_right
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
os.chdir(str(project_root))

from config import EXCLUDED_SYMBOLS_BLACKLIST
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

from benchmark_precompute import build_full_1h_candles

ta_agent = TechnicalAnalysisAgent()
quant_sim_agent = QuantSimulationAgent(default_simulations=2000, win_threshold_pct=50.0)

results = []
for sym, c_list in list(raw_cache.items())[:5]:
    if sym in EXCLUDED_SYMBOLS_BLACKLIST:
        continue
    c_1h = build_full_1h_candles(c_list)
    h_close_ts = [c['timestamp'] + 3600*1000 for c in c_1h]
    for idx, c in enumerate(c_list):
        if idx < 45:
            continue
        ts = c['timestamp']
        win_15m = c_list[max(0, idx-59) : idx+1]
        h_end_idx = bisect_right(h_close_ts, ts)
        win_1h = c_1h[max(0, h_end_idx-35) : h_end_idx] if h_end_idx >= 15 else None
        
        setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
        if setup:
            q_res = quant_sim_agent.simulate_setup(sym, setup, win_15m, num_simulations=2000)
            emp = q_res.get("empirical_resonance", {})
            results.append({
                'symbol': sym,
                'direction': setup['direction'],
                'sl_pct': setup['sl_pct'],
                'tp1_pct': setup['tp1_pct'],
                'win_prob': q_res.get('win_probability_pct'),
                'loss_prob': q_res.get('loss_probability_pct'),
                'expected_r': q_res.get('expected_r'),
                'empirical_approved': emp.get('is_approved'),
                'green_rate': emp.get('green_rate'),
                'samples': emp.get('samples')
            })

for r in results[:10]:
    print(r)

