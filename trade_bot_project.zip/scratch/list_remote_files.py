import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

import json
import urllib.request
from sync_to_github import get_token, REPO_OWNER, REPO_NAME, BRANCH

token = get_token()
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github.v3+json",
    "User-Agent": "Antigravity-SecurityAudit"
}

tree_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/trees/{BRANCH}?recursive=1"
req = urllib.request.Request(tree_url, headers=headers, method="GET")
with urllib.request.urlopen(req) as resp:
    tree_data = json.loads(resp.read().decode("utf-8"))
    files = [item["path"] for item in tree_data.get("tree", []) if item["type"] == "blob"]
    for f in sorted(files):
        print("  -", f)
