import urllib.request
import json

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req) as resp:
    d = json.loads(resp.read().decode())
    print("Total scanner logs:", len(d.get("scanner_logs", [])))
    for log in d.get("scanner_logs", [])[:10]:
        clean_r = log.get("reason", "").replace("<strong>", "").replace("</strong>", "").replace("<br>", " | ")
        print(f"[{log.get('symbol')}] {log.get('status')}: {clean_r[:100]}")
    print("Active positions count:", len(d.get("active_positions", [])))
