import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from sync_to_github import sync_file_to_github

files_to_sync = [
    ("config.py", "fix: calibrate 15m confluence to 68 and BTC chop to 0.70%"),
    ("core/self_tuning_engine.py", "fix: add immutable confluence & chop ceilings to prevent 80-score freeze"),
    ("data/adaptive_hyperparams.json", "config: set active hyperparams to 68 confluence and 0.70% chop"),
    ("core/database.py", "feat: add daily fee calculation for FAST and SUPER_FAST bots"),
    ("fast_config.py", "feat: set FAST daily trade quota to 15, fee cap to $15 and profit target to 0.95%"),
    ("fast_engine.py", "feat: enforce FAST daily trade quota and fee cap in scan cycle"),
    ("super_fast_config.py", "feat: set SUPER_FAST daily trade quota to 25, fee cap to $20 and profit target to 0.75%"),
    ("super_fast_engine.py", "feat: enforce SUPER_FAST daily trade quota and fee cap in scan cycle")
]

print(f"🚀 Toplam {len(files_to_sync)} dosya GitHub'a senkronize ediliyor...")

results = {}
for path, msg in files_to_sync:
    print(f"\n📤 Yükleniyor: {path}...")
    success = sync_file_to_github(path, msg)
    results[path] = success

print("\n" + "="*50)
all_ok = all(results.values())
if all_ok:
    print("✅ TÜM DOSYALAR BAŞARIYLA GITHUB'A YÜKLENDİ!")
    print("⚡ Railway otomatik olarak yeni commitleri algılayıp canlıya alıyor.")
else:
    print("⚠️ Bazı dosyalarda senkronizasyon hatası oluştu:")
    for p, s in results.items():
        print(f"  - {p}: {'✅ Başarılı' if s else '❌ HATA'}")
