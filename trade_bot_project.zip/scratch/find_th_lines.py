with open("dashboard.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i in range(1300, 1700):
    l = lines[i]
    if "<th" in l or "<table" in l:
        print(f"L{i+1}: {l.strip()[:100]}")
