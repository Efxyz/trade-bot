import urllib.request
import json

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode("utf-8"))
        print("--- 15M STANDART BOT STATS ---")
        print(json.dumps(data.get("stats", {}), indent=2))
        print("--- FAST BOT STATS ---")
        print(json.dumps(data.get("fast_stats", {}), indent=2))
        print("--- SÜPER FAST BOT STATS ---")
        print(json.dumps(data.get("super_fast_stats", {}), indent=2))
        print("--- FAST SCANNER LOGS (First 3) ---")
        for l in data.get("fast_scanner_logs", [])[:3]:
            print(f"  [{l.get('symbol')}] {l.get('status')}: {l.get('reason')}")
        print("--- SÜPER FAST SCANNER LOGS (First 3) ---")
        for l in data.get("super_fast_scanner_logs", [])[:3]:
            print(f"  [{l.get('symbol')}] {l.get('status')}: {l.get('reason')}")
except Exception as e:
    print(f"Error: {e}")
