import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

from agents.news_agent import NewsAgent
from agents.risk_agent import RiskOfficerAgent
from agents.ai_analyst_agent import AIAnalystAgent

def test_full_news_pipeline():
    print("=" * 80)
    print("🚀 HABER KARARLANDIRMA KONSEYİ VE ÇOK KAYNAKLI DERİN ARAŞTIRMA TESTİ")
    print("=" * 80)

    news_agent = NewsAgent()
    risk_officer = RiskOfficerAgent()
    ai_analyst = AIAnalystAgent()

    # 1. Genel Piyasa Haberlerini Çek (Cointelegraph, CoinDesk, Decrypt, The Block)
    print("\n[1] BÜYÜK HABER ŞİRKETLERİNDEN GENEL AKIŞ TOPLANIYOR...")
    market_news = news_agent.fetch_latest_market_news()
    print(f"✅ Toplam {len(market_news)} genel haber çekildi ve ofis haber masasına aktarıldı.")
    for n in market_news[:3]:
        print(f"   - [{n['source']}] {n['title'][:70]}... ({n['sentiment']})")

    # 2. Coine Özel Araştırma & Kararlandırma Konseyi
    test_cases = [
        ("SOLUSDT", "LONG", 0.0001),
        ("ETHUSDT", "SHORT", -0.0002),
        ("KAVAUSDT", "LONG", 0.0005) # Hacklenen token testi
    ]

    for symbol, direction, funding in test_cases:
        print("\n" + "-" * 75)
        print(f"🔍 SEMBOLE ÖZEL DERİN ARAŞTIRMA: {symbol} ({direction})")
        print("-" * 75)

        funding_data = {"lastFundingRate": funding}
        news_analysis = news_agent.investigate_coin_news(symbol, direction, funding_data)

        print(f"  🏛️ Konsey Kararı: {news_analysis['verdict']} | Skor: {news_analysis['news_score']}/100")
        print(f"  📊 Kasa Büyüklüğü Çarpanı: {news_analysis['pos_multiplier']}x")
        print(f"  🛑 Veto Edildi mi?: {'❌ EVET (İŞLEM İPTAL)' if news_analysis['is_vetoed'] else '✅ HAYIR (ONAYLI)'}")
        print("  🗣️ Konsey Masaları Tartışması:")
        for quote in news_analysis["council_debate"]:
            print(f"     {quote}")

        # Risk Officer Değerlendirmesi
        ta_mock = {
            "symbol": symbol,
            "direction": direction,
            "current_price": 100.0,
            "stop_loss": 99.0 if direction == "LONG" else 101.0,
            "take_profit_1": 102.0 if direction == "LONG" else 98.0,
            "take_profit_2": 103.0 if direction == "LONG" else 97.0,
            "sl_pct": 1.0,
            "tp1_pct": 2.0,
            "tp2_pct": 3.0,
            "risk_reward": 2.0,
            "confluence_score": 75,
            "leverage": 10
        }
        ticker_mock = {"lastPrice": 100.0, "quoteVolume": 50000000}
        btc_mock = {"status": "BULLISH", "summary": "BTC stabil", "block_longs": False, "block_shorts": False}

        is_approved, risk_report = risk_officer.evaluate(
            ta_mock, news_analysis, ticker_mock, btc_mock,
            funding_data=funding_data, current_equity=1000.0
        )
        print(f"  🛡️ Risk Şefi Kararı: {'✅ ONAYLANDI' if is_approved else '❌ REDDEDİLDİ'}")
        if is_approved:
            print(f"     Ayrılan Marjin: ${risk_report['allocated_margin_usdt']} (Haber Çarpanı: {news_analysis['pos_multiplier']}x)")
            print(f"     Risk Sınıfı: {risk_report['risk_grade']}")
        else:
            print(f"     Red Gerekçesi: {risk_report.get('reason')}")

    print("\n" + "=" * 80)
    print("🏁 TÜM TESTLER BAŞARIYLA TAMAMLANDI")
    print("=" * 80)

if __name__ == "__main__":
    test_full_news_pipeline()
