import json
import os
import sys
import time
from bisect import bisect_right
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

project_root = Path(r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot")
sys.path.insert(0, str(project_root))
os.chdir(str(project_root))

from config import (
    BINANCE_ROUNDTRIP_FEE_PCT,
    EXCLUDED_SYMBOLS_BLACKLIST,
    LADDER_DYNAMIC_CHANNEL_PCT,
    LADDER_STEPS,
    LEVERAGE_HIGH,
    LEVERAGE_STANDARD,
    MAX_HOLD_MINUTES,
    MAX_SL_PCT_10X,
    MAX_SL_PCT_20X,
    MIN_RR_RATIO,
    SIDE_STOPLOSS_COOLDOWN_MINUTES,
    SIDE_STOPLOSS_GUARD_ENABLED,
    SIDE_STOPLOSS_MAX_CONSECUTIVE_LOSSES,
)
from agents.ta_agent import TechnicalAnalysisAgent
from agents.quant_simulation_agent import QuantSimulationAgent

cache_path = os.path.join(str(project_root), "scratch", "cached_30d_candles.json")
with open(cache_path, "r", encoding="utf-8") as f:
    raw_cache = json.load(f)

def build_full_1h_candles(candles_15m):
    candles_1h = []
    bucket = []
    current_hour = None
    for c in candles_15m:
        hour_ts = (c['timestamp'] // (3600 * 1000)) * (3600 * 1000)
        if current_hour is None:
            current_hour = hour_ts
        if hour_ts != current_hour and bucket:
            candles_1h.append({
                'timestamp': current_hour,
                'open': bucket[0]['open'],
                'high': max(b['high'] for b in bucket),
                'low': min(b['low'] for b in bucket),
                'close': bucket[-1]['close'],
                'volume': sum(b['volume'] for b in bucket)
            })
            bucket = [c]
            current_hour = hour_ts
        else:
            bucket.append(c)
    if bucket:
        candles_1h.append({
            'timestamp': current_hour,
            'open': bucket[0]['open'],
            'high': max(b['high'] for b in bucket),
            'low': min(b['low'] for b in bucket),
            'close': bucket[-1]['close'],
            'volume': sum(b['volume'] for b in bucket)
        })
    return candles_1h

print("1. 30 Günlük Veriler Yükleniyor...", flush=True)
coin_data = {}
all_ts = set()
for sym, c_list in raw_cache.items():
    if sym in EXCLUDED_SYMBOLS_BLACKLIST:
        continue
    c_1h = build_full_1h_candles(c_list)
    h_close_ts = [c['timestamp'] + 3600*1000 for c in c_1h]
    coin_data[sym] = {
        'list_15m': c_list,
        'by_ts': {x['timestamp']: x for x in c_list},
        'idx_by_ts': {x['timestamp']: i for i, x in enumerate(c_list)},
        'list_1h': c_1h,
        'h_close_ts': h_close_ts
    }
    all_ts.update(x['timestamp'] for x in c_list)

sorted_ts = sorted(list(all_ts))

print("2. TA + Monte Carlo Kuant Ajanı Birlikte Taranıyor...", flush=True)
ta_agent = TechnicalAnalysisAgent()
quant_sim_agent = QuantSimulationAgent(default_simulations=2000, win_threshold_pct=65.0)

signals_by_ts = {ts: [] for ts in sorted_ts}
raw_ta_count = 0
quant_approved_count = 0

for sym, d in coin_data.items():
    c15 = d['list_15m']
    c1h = d['list_1h']
    h_close_ts = d['h_close_ts']
    for idx, c in enumerate(c15):
        if idx < 45:
            continue
        ts = c['timestamp']
        win_15m = c15[max(0, idx-59) : idx+1]
        h_end_idx = bisect_right(h_close_ts, ts)
        win_1h = c1h[max(0, h_end_idx-35) : h_end_idx] if h_end_idx >= 15 else None
        
        setup, reason = ta_agent.analyze_setup(sym, win_15m, candles_1h=win_1h)
        if setup:
            raw_ta_count += 1
            # Monte Carlo + Ampirik Kuant Filtresi
            q_res = quant_sim_agent.simulate_setup(sym, setup, win_15m, num_simulations=2000)
            if q_res.get("is_approved", False):
                quant_approved_count += 1
                signals_by_ts[ts].append((sym, setup, q_res))

print(f"Toplam Ham TA Sinyali: {raw_ta_count} | Monte Carlo Kuant Onaylı: {quant_approved_count}", flush=True)

