"""
Prototype & Test Script for Autonomous Self-Training Engine
Tests:
- Gathering completed trades across signals, fast_signals, super_fast_signals
- Causal loss attribution
- Market regime diagnosis
- Counterfactual parameter adaptation
- Safety guardrails verification
- Distilled hypotheses generation
- Auto-approve and DB persistence
"""
import sys, os
sys.path.insert(0, os.path.abspath("."))
import json
import sqlite3
from config import DB_PATH

def test_trade_gathering():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    all_trades = []
    sources = [
        ("signals", "15m_STANDARD"),
        ("fast_signals", "1m_FAST"),
        ("super_fast_signals", "HFT_SUPER_FAST")
    ]
    
    for table, bot_name in sources:
        try:
            cursor.execute(f"""
                SELECT id, symbol, direction, status, simulated_pnl_pct, gross_pnl_pct, fee_pct,
                       ladder_step, created_at, closed_at
                FROM {table}
                WHERE status NOT IN ('ACTIVE', 'PENDING_ENTRY', 'ACTIVE_BE', 'ACTIVE_LADDER')
                  AND simulated_pnl_pct IS NOT NULL
                ORDER BY id DESC
                LIMIT 30
            """)
            for r in cursor.fetchall():
                d = dict(r)
                d["bot_source"] = bot_name
                all_trades.append(d)
        except Exception as e:
            print(f"Error querying {table}: {e}")
            
    print(f"Total gathered closed trades across all bots: {len(all_trades)}")
    for t in all_trades[:5]:
        print(f"  [{t['bot_source']}] {t['symbol']} {t['direction']} {t['status']} {t['simulated_pnl_pct']}%")
    return all_trades

if __name__ == "__main__":
    trades = test_trade_gathering()
    assert len(trades) >= 10, f"Expected at least 10 trades, got {len(trades)}"
    print("Trade gathering test PASSED successfully!")
