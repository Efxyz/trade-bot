with open("dashboard.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

keywords = ["created_at", "closed_at", "entered_at", "timestamp", "time", "date", "saat", "clock", "calibrated_at", "updated_at"]

print("--- Matches in dashboard.py ---")
for i, line in enumerate(lines):
    l_lower = line.lower()
    for kw in ["created_at", "closed_at", "entered_at", "calibrated_at", "timestamp", "tolocalestring", "tolocaletimestring", "formatdate"]:
        if kw in l_lower:
            print(f"L{i+1}: {line.strip()[:140]}")
            break
