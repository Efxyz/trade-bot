import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from sync_to_github import sync_file_to_github

files_to_sync = [
    ("agents/ta_agent.py", "feat: calibrate SMC scoring (fresh FVG/OB, volume burst, early EMA momentum & premium filter)"),
    ("config.py", "config: calibrate 15m confluence threshold to 65 (short 68)"),
    ("data/adaptive_hyperparams.json", "config: set active hyperparams to 65 confluence score"),
    ("core/self_tuning_engine.py", "fix: set confluence ceiling to 68 and floor to 62 to prevent freeze")
]

print(f"🚀 Toplam {len(files_to_sync)} dosya GitHub'a senkronize ediliyor...")

results = {}
for path, msg in files_to_sync:
    print(f"\n📤 Yükleniyor: {path}...")
    success = sync_file_to_github(path, msg)
    results[path] = success

print("\n" + "="*50)
all_ok = all(results.values())
if all_ok:
    print("✅ TÜM DOSYALAR BAŞARIYLA GITHUB'A YÜKLENDİ!")
    print("⚡ Railway otomatik olarak yeni commitleri algılayıp canlıya alıyor.")
else:
    print("⚠️ Bazı dosyalarda senkronizasyon hatası oluştu:")
    for p, s in results.items():
        print(f"  - {p}: {'✅ Başarılı' if s else '❌ HATA'}")
