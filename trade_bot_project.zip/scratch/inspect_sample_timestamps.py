import urllib.request
import json

url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req) as resp:
    data = json.loads(resp.read().decode())

print("=== SAMPLE TIMESTAMPS FROM RAILWAY /api/data ===")
# 1. Scanner logs
for l in data.get("scanner_logs", [])[:2]:
    print(f"scanner_log time: {l.get('time')}")
for l in data.get("fast_scanner_logs", [])[:2]:
    print(f"fast_scanner_log time: {l.get('time')}")

# 2. Trade history
for t in data.get("trade_history", [])[:2]:
    print(f"trade_history: created_at={t.get('created_at')}, closed_at={t.get('closed_at')}")
for t in data.get("fast_trade_history", [])[:2]:
    print(f"fast_trade_history: created_at={t.get('created_at')}, closed_at={t.get('closed_at')}")
for t in data.get("super_fast_trade_history", [])[:2]:
    print(f"super_fast_trade_history: created_at={t.get('created_at')}, closed_at={t.get('closed_at')}")

# 3. Debates
for d in data.get("committee_debates", [])[:2]:
    print(f"committee_debate time_str: {d.get('time_str')}")

# 4. Reflections
for r in data.get("trade_reflections", [])[:2]:
    print(f"trade_reflection time_str: {r.get('time_str')}")

# 5. News
for n in data.get("news_feed", [])[:2]:
    print(f"news_feed time: {n.get('time')}")

# 6. Tuning info
tuning = data.get("tuning_info", {})
print(f"tuning calibrated_at: {tuning.get('calibrated_at')}")
