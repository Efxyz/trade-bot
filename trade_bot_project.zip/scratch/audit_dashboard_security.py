import sys
import os

WORKSPACE_DIR = r"c:\Users\isiks\OneDrive\Belgeler\antygravity\trade_bot"
if WORKSPACE_DIR not in sys.path:
    sys.path.insert(0, WORKSPACE_DIR)

import re

dashboard_path = os.path.join(WORKSPACE_DIR, "dashboard.py")
content = open(dashboard_path, "r", encoding="utf-8", errors="ignore").read()

route_matches = re.findall(r"@app\.route\((['\"][^'\"]+['\"])(?:,\s*methods=\[([^\]]+)\])?\)\s*\ndef\s+([a-zA-Z0-9_]+)", content)

print("=" * 80)
print("🌐 DASHBOARD WEB ENDPOINTLERİ VE GÜVENLİK ANALİZİ")
print("=" * 80)
print(f"Toplam {len(route_matches)} adet Flask endpoint bulundu:\n")

for route, methods, func in route_matches:
    m = methods if methods else "'GET'"
    print(f"  Route: {route:<30} | Metodlar: {m:<20} | Fonksiyon: {func}")

# Check if HTTP Basic Auth or session check exists
has_auth = "auth" in content.lower() or "login" in content.lower() or "password" in content.lower() or "session" in content.lower()
print("\n" + "-" * 80)
print("Kimlik Doğrulama (Authentication) Kontrolü:")
if "@auth.login_required" in content or "HTTPBasicAuth" in content or "session.get('user')" in content:
    print("✅ Kimlik doğrulama mevcut.")
else:
    print("⚠️ UYARI: Dashboard'da herhangi bir parola veya kimlik doğrulama (HTTP Basic Auth / Login) BULUNAMADI!")
    print("   Herkes 'https://trade-bot-production-f1b1.up.railway.app' adresine girip tüm verileri ve paneli görebilir.")
