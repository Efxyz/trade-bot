import os

base = os.path.join(os.getcwd(), "scratch", "extracted_repos", "hummingbot-master", "hummingbot-master")

print("=== HUMMINGBOT SCAN ===")
controllers_dir = os.path.join(base, "controllers")
if os.path.exists(controllers_dir):
    print("Controllers:", os.listdir(controllers_dir))
    dir_trading = os.path.join(controllers_dir, "directional_trading")
    if os.path.exists(dir_trading):
        print("Directional trading controllers:", os.listdir(dir_trading))
        # Inspect directional_trading_controller_base.py or similar
        for f in os.listdir(dir_trading):
            if "base" in f or "bollinger" in f or "ai" in f or "trend" in f:
                print(f"\n--- {f} ---")
                with open(os.path.join(dir_trading, f), 'r', encoding='utf-8', errors='ignore') as fp:
                    print(fp.read()[:1200])

# Also check strategy or execution
strat_dir = os.path.join(base, "hummingbot", "strategy")
if os.path.exists(strat_dir):
    print("\nHummingbot strategies:", os.listdir(strat_dir))

