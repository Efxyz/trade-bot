import urllib.request
import json
import sqlite3
from pathlib import Path

print("=== 1. RAILWAY CANLI SUNUCU DENETİMİ ===")
url = "https://trade-bot-production-f1b1.up.railway.app/api/data"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        d = json.loads(resp.read().decode("utf-8"))
        print("✅ Railway API Bağlantısı: BAŞARILI")
        print("  - WebSocket Streamer:", "🟢 AKTİF" if d.get("ws_connected") else "🔴 KOPUK")
        print("  - BTC Rejimi:", d.get("btc_regime", {}).get("summary"))
        print("  - 15m Standart Kasa:", f"${d.get('stats', {}).get('portfolio_balance')} (Win Rate: %{d.get('stats', {}).get('win_rate')} - Toplam İşlem: {d.get('stats', {}).get('total_trades')})")
        print("  - FAST Scalper Kasa:", f"${d.get('fast_stats', {}).get('portfolio_balance')} (Bugün: ${d.get('fast_stats', {}).get('today_dollar_gain')})")
        print("  - SÜPER FAST Kasa:", f"${d.get('super_fast_stats', {}).get('portfolio_balance')} (Bugün Net Kâr: +${d.get('super_fast_stats', {}).get('today_dollar_gain')} - Win Rate: %{d.get('super_fast_stats', {}).get('today_win_rate')})")
        
        # Check active positions
        print("  - Aktif Pozisyonlar (Standart):", len(d.get("active_positions", [])))
        print("  - Aktif Pozisyonlar (FAST):", len(d.get("fast_active_positions", [])))
        print("  - Aktif Pozisyonlar (SÜPER FAST):", len(d.get("super_fast_active_positions", [])))
        
        # Check latest scanner log
        logs = d.get("scanner_logs", [])
        if logs:
            first = logs[0]
            print(f"  - Son Standart Tarama: [{first.get('symbol')}] {first.get('status')} -> {first.get('reason')[:80]}")
except Exception as e:
    print(f"❌ Railway API Hatası: {e}")

print("\n=== 2. YEREL VERİTABANI VE DOSYA BÜTÜNLÜĞÜ DENETİMİ ===")
db_path = Path("data/trading_bot.db")
if db_path.exists():
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [r[0] for r in cur.fetchall()]
    print(f"✅ SQLite Veritabanı Mevcut ({len(tables)} tablo):", ", ".join(tables))
    conn.close()
else:
    print("ℹ️ Yerel SQLite veritabanı henüz oluşturulmamış (Canlı sunucu Railway üzerinde çalışıyor).")

print("\n=== 3. ADAPTİF PARAMETRELER KONTROLÜ ===")
param_path = Path("data/adaptive_hyperparams.json")
if param_path.exists():
    with open(param_path, "r", encoding="utf-8") as f:
        params = json.load(f)
    print("✅ data/adaptive_hyperparams.json:", json.dumps(params, indent=2, ensure_ascii=False))

print("\nDenetim tamamlandı.")
