import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.binance_client import BinanceFuturesClient
from agents.ta_agent import TechnicalAnalysisAgent

client = BinanceFuturesClient()
agent = TechnicalAnalysisAgent()

coins = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "DOGEUSDT", "XRPUSDT", "SUIUSDT",
    "NEARUSDT", "AVAXUSDT", "LINKUSDT", "ADAUSDT", "BNBUSDT", "1000PEPEUSDT",
    "FETUSDT", "RENDERUSDT", "TAOUSDT", "WIFUSDT", "TIAUSDT", "DOTUSDT"
]

results = []
for sym in coins:
    try:
        c15m = client.get_klines(sym, interval="15m", limit=60)
        c1h = client.get_klines(sym, interval="1h", limit=50)
        setup, reason = agent.analyze_setup(sym, c15m, c1h)
        if setup:
            results.append((sym, setup["direction"], setup["confluence_score"], "APPROVED", setup["ta_reasons"]))
        else:
            # extract score from reason
            import re
            m = re.search(r"skoru (\d+)/100", reason)
            score = int(m.group(1)) if m else 0
            results.append((sym, "NONE", score, "REJECTED", reason[:70]))
    except Exception as e:
        pass

results.sort(key=lambda x: x[2], reverse=True)
print(f"{'SYMBOL':<12} | {'DIR':<5} | {'SCORE':<5} | {'STATUS':<10} | {'DETAILS'}")
print("=" * 80)
for r in results:
    print(f"{r[0]:<12} | {r[1]:<5} | {r[2]:<5} | {r[3]:<10} | {r[4]}")
