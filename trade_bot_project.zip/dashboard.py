"""
All-in-One Trading Office Dashboard for Binance Futures Trade Bot (v2.2.0)
Visualizes the active trading desk like a real office:
- Live Interactive Binance Futures Bitcoin Candlestick Chart (15m, 1h, 4h, 1D)
- Active Scalps with Real SVG Candlestick Charts & Exact Green TP / Red SL levels
- Scanner & Analysis Desk: Live feed of coins examined and why approved/rejected
- News & Sentiment Desk (Sağ Alt): Live market news with Bullish/Bearish tags
- Bottom PnL Ledger & Realized Vault
"""
import os
import sys
import json
import webbrowser
import threading
from datetime import datetime
from pathlib import Path
from flask import Flask, jsonify, render_template_string, send_from_directory, request
import functools

from config import (
    CHARTS_DIR,
    DB_PATH,
    MAX_CONCURRENT_TRADES,
    BINANCE_ROUNDTRIP_FEE_PCT,
    PORTFOLIO_EQUITY_USDT
)
from core.binance_client import BinanceFuturesClient
from core.database import (
    get_all_signals,
    get_active_and_pending_signals,
    get_performance_stats
)
from agents.scanner_agent import get_scanner_logs, add_scanner_log
from agents.news_agent import get_live_news_feed, NewsAgent

app = Flask(__name__)
client = BinanceFuturesClient()
news_agent = NewsAgent()

ADMIN_PIN = os.getenv("ADMIN_PIN", "1923")

def require_admin_pin(func):
    """
    Kritik yönetim ve silme endpointlerini yetkisiz web tarayıcıları ve botlardan korur.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        pin = request.headers.get("X-Admin-Pin") or request.args.get("pin") or (request.get_json(silent=True) or {}).get("pin")
        if not pin or str(pin).strip() != str(ADMIN_PIN).strip():
            return jsonify({
                "status": "error",
                "message": "🔒 Yetkisiz Erişim: Bu kritik işlemi gerçekleştirmek için geçerli Yönetici Güvenlik PIN kodu gereklidir!"
            }), 401
        return func(*args, **kwargs)
    return wrapper

_orchestrator = None

HTML_OFFICE_TEMPLATE = """
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>⚡ AI Fon Ofisi - Canlı İşlem Masası</title>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    <style>
        :root {
            --bg-body: #090d16;
            --panel-bg: #111622;
            --panel-border: #1f2738;
            --card-bg: #151c2c;
            --card-hover: #1a2337;
            --green: #10b981;
            --green-bg: rgba(16, 185, 129, 0.12);
            --red: #ef4444;
            --red-bg: rgba(239, 68, 68, 0.12);
            --cyan: #38bdf8;
            --cyan-bg: rgba(56, 189, 248, 0.12);
            --yellow: #f59e0b;
            --text-main: #f1f5f9;
            --text-muted: #8492a6;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-body);
            color: var(--text-main);
            font-family: 'Inter', -apple-system, sans-serif;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            user-select: none;
        }

        /* Top Header */
        /* 2-Katmanlı Üst Panel Mimarisi: 1. Bar Sistem & Takip, 2. Bar Finans & PnL */
        .topbar-container {
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            background: var(--panel-bg);
            border-bottom: 1px solid var(--panel-border);
            width: 100%;
        }
        .topbar-system {
            min-height: 42px;
            height: 42px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            gap: 12px;
            flex-shrink: 0;
            white-space: nowrap;
            overflow-x: auto;
            overflow-y: hidden;
            scrollbar-width: none;
        }
        .topbar-system::-webkit-scrollbar { display: none; }

        .topbar-finance {
            min-height: 38px;
            height: 38px;
            background: rgba(9, 14, 24, 0.95);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 14px;
            gap: 14px;
            flex-shrink: 0;
            white-space: nowrap;
            overflow-x: auto;
            overflow-y: hidden;
            scrollbar-width: none;
        }
        .topbar-finance::-webkit-scrollbar { display: none; }

        .brand {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
            font-size: 13.5px;
            flex-shrink: 0;
            white-space: nowrap;
        }
        .brand-badge {
            background: linear-gradient(135deg, #0284c7, #2563eb);
            color: #fff; width: 24px; height: 24px; border-radius: 6px;
            display: flex; align-items: center; justify-content: center; font-size: 13px;
            flex-shrink: 0;
        }
        .top-stat-group {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 11.5px;
            flex-wrap: nowrap;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .top-stat {
            display: flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .top-stat .lbl {
            color: var(--text-muted);
            font-size: 9.5px;
            text-transform: uppercase;
            white-space: nowrap;
            letter-spacing: 0.2px;
        }
        .top-stat .val {
            font-family: 'JetBrains Mono', monospace;
            font-weight: 700;
            white-space: nowrap;
            font-size: 11px;
        }
        .btn-scan {
            background: #2563eb; color: #fff; border: none; padding: 4px 10px;
            border-radius: 5px; font-size: 11px; font-weight: 600; cursor: pointer;
            transition: 0.15s;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .btn-scan:hover { background: #1d4ed8; }

        /* Office Workspace: Sol İşlem Penceresi Sağa Doğru Genişletildi (2.15fr 1fr) */
        .workspace {
            display: grid;
            grid-template-columns: 2.15fr 1fr;
            grid-template-rows: 1fr 210px;
            gap: 10px;
            padding: 10px;
            flex: 1;
            overflow: hidden;
        }

        .panel {
            background: var(--panel-bg);
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .panel-header {
            padding: 8px 14px;
            border-bottom: 1px solid var(--panel-border);
            font-size: 11px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: rgba(255,255,255,0.015);
            flex-shrink: 0;
            letter-spacing: 0.3px;
        }
        .panel-header .counter {
            background: var(--panel-border);
            color: var(--text-muted);
            padding: 2px 6px;
            border-radius: 8px;
            font-size: 10px;
        }

        /* Sol Sütun: Aktif Scalp Kartları & Gerçek Mini Mum Grafiği */
        .cards-list {
            padding: 10px;
            overflow-y: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .pos-card {
            background: var(--card-bg);
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            padding: 12px 14px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            transition: 0.15s;
        }
        .pos-card:hover { border-color: var(--cyan); }
        .card-header {
            display: flex; justify-content: space-between; align-items: center;
        }
        .card-title { display: flex; align-items: center; gap: 8px; font-size: 15px; font-weight: 700; }
        .tag {
            font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 4px; text-transform: uppercase;
        }
        .tag-long { background: var(--green-bg); color: var(--green); border: 1px solid var(--green); }
        .tag-short { background: var(--red-bg); color: var(--red); border: 1px solid var(--red); }
        .tag-lev { background: var(--cyan-bg); color: var(--cyan); border: 1px solid var(--cyan); }

        .card-pnl {
            font-family: 'JetBrains Mono', monospace; font-size: 18px; font-weight: 700;
        }
        .pnl-pos { color: var(--green); }
        .pnl-neg { color: var(--red); }

        .btn-manual-close {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.45);
            border-radius: 5px;
            padding: 3px 8px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 3px;
            font-family: 'Inter', sans-serif;
            white-space: nowrap;
        }
        .btn-manual-close:hover {
            background: #ef4444;
            color: #ffffff;
            border-color: #ef4444;
            box-shadow: 0 0 10px rgba(239, 68, 68, 0.45);
            transform: translateY(-1px);
        }
        .btn-manual-close:active {
            transform: translateY(0);
        }

        .btn-group-close {
            font-size: 11px;
            font-weight: 700;
            padding: 3px 9px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-family: 'Inter', sans-serif;
            white-space: nowrap;
        }
        .btn-close-profit {
            background: rgba(34, 197, 94, 0.15);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.45);
        }
        .btn-close-profit:hover {
            background: #22c55e;
            color: #ffffff;
            border-color: #22c55e;
            box-shadow: 0 0 10px rgba(34, 197, 94, 0.45);
            transform: translateY(-1px);
        }
        .btn-close-profit:active {
            transform: translateY(0);
        }
        .btn-close-loss {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.45);
        }
        .btn-close-loss:hover {
            background: #ef4444;
            color: #ffffff;
            border-color: #ef4444;
            box-shadow: 0 0 10px rgba(239, 68, 68, 0.45);
            transform: translateY(-1px);
        }
        .btn-close-loss:active {
            transform: translateY(0);
        }

        /* Aktif İşlemler İki Kısımlı Bölüm ve Özet Barı */
        .active-summary-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 8px 12px;
            background: #141926;
            border-bottom: 1px solid var(--panel-border);
            font-size: 11px;
            font-weight: 600;
        }
        .sum-badge {
            padding: 2px 8px;
            border-radius: 4px;
            font-family: 'JetBrains Mono', monospace;
        }
        .sum-badge.all { background: #1a2337; color: #f1f5f9; }
        .sum-badge.green { background: rgba(16, 185, 129, 0.15); color: #10b981; }
        .sum-badge.red { background: rgba(239, 68, 68, 0.15); color: #ef4444; }

        .pos-section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 7px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            margin-top: 4px;
        }
        .pos-section-header.green-sec {
            background: rgba(16, 185, 129, 0.1);
            border-left: 3px solid #10b981;
            color: #10b981;
        }
        .pos-section-header.red-sec {
            background: rgba(239, 68, 68, 0.1);
            border-left: 3px solid #ef4444;
            color: #ef4444;
        }
        .pos-section-sub {
            font-size: 9px;
            font-weight: 500;
            color: var(--text-muted);
        }

        /* Yan Yana İki Sütunlu Grid: Sol = Kar, Sağ = Zarar */
        .active-two-cols {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            flex: 1;
            overflow: hidden;
            padding: 8px;
        }
        .active-sub-col {
            display: flex;
            flex-direction: column;
            overflow: hidden;
            background: rgba(13, 18, 28, 0.4);
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            padding: 6px;
        }
        .cards-sub-list {
            flex: 1;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
            padding: 4px;
            margin-top: 6px;
        }

        .card-elapsed {
            font-size: 10px;
            font-family: 'JetBrains Mono', monospace;
            font-weight: 600;
            background: rgba(255, 255, 255, 0.06);
            color: #94a3b8;
            padding: 2px 7px;
            border-radius: 4px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .btn-clear {
            background: rgba(239, 68, 68, 0.12);
            border: 1px solid rgba(239, 68, 68, 0.35);
            color: #ef4444;
            padding: 3px 10px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-clear:hover {
            background: rgba(239, 68, 68, 0.25);
            border-color: #ef4444;
            transform: translateY(-1px);
        }
        .btn-panic {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #ef4444;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-panic:hover {
            background: #ef4444;
            color: #fff;
            transform: translateY(-1px);
        }

        /* Gerçek Mini SVG Mum Grafiği Kutusu */
        .mini-chart-box {
            background: #0d121c;
            border: 1px solid var(--panel-border);
            border-radius: 6px;
            padding: 8px 10px;
            position: relative;
        }
        .chart-svg {
            width: 100%; height: 110px; display: block; overflow: visible;
        }

        /* Proximity Badges Row */
        .proximity-row {
            display: flex; justify-content: space-between; font-size: 11px;
            font-family: 'JetBrains Mono', monospace; font-weight: 600;
            background: rgba(0,0,0,0.2); padding: 6px 10px; border-radius: 4px;
        }
        .prox-sl { color: var(--red); }
        .prox-tp { color: var(--green); }

        /* Sağ Taraf Split: Üstte Tarama Masası, Altta Haber Masası */
        .right-split {
            display: grid;
            grid-template-rows: 1.1fr 1fr;
            gap: 10px;
            overflow: hidden;
        }

        /* 📡 Tarama Masası (Neden Elendi / Uygun Bulundu) */
        .log-list {
            padding: 8px;
            overflow-y: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .log-item {
            background: #141926;
            border: 1px solid var(--panel-border);
            border-radius: 6px;
            padding: 8px 10px;
            font-size: 11px;
            display: flex;
            flex-direction: column;
            gap: 3px;
        }
        .log-item.approved { border-left: 3px solid var(--green); }
        .log-item.rejected { border-left: 3px solid #64748b; }
        .log-item.protected { border-left: 3px solid #38bdf8; background: rgba(56, 189, 248, 0.04); }

        .log-top { display: flex; justify-content: space-between; align-items: center; }
        .log-sym { font-weight: 700; font-family: 'JetBrains Mono', monospace; }
        .log-time { color: var(--text-muted); font-size: 10px; }
        .log-reason { font-size: 11px; color: #cbd5e1; line-height: 1.55; margin-top: 3px; }
        .log-reason strong { color: #f1f5f9; }
        .badge-appr { color: var(--green); font-weight: 700; }
        .badge-rej { color: #94a3b8; font-weight: 600; }
        .badge-prot { color: #38bdf8; font-weight: 700; background: rgba(56,189,248,0.12); padding: 1px 7px; border-radius: 4px; font-size: 10px; }

        /* 📰 Sağ Altta Haber & Duygu Masası */
        .news-list {
            padding: 8px;
            overflow-y: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .news-item {
            background: #141926;
            border: 1px solid var(--panel-border);
            border-radius: 6px;
            padding: 7px 10px;
            font-size: 11px;
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .news-meta {
            display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: var(--text-muted);
        }
        .news-title {
            font-size: 11px; font-weight: 500; line-height: 1.35; color: #e2e8f0;
        }

        /* 🏛️ Coine Özel Kararlandırma Konseyi & Alt Tablar */
        .news-sub-header {
            padding: 7px 10px;
            background: rgba(255, 255, 255, 0.02);
            border-bottom: 1px solid var(--panel-border);
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .news-subtab-btn {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--panel-border);
            color: var(--text-muted);
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .news-subtab-btn.active {
            background: rgba(245, 158, 11, 0.16);
            border-color: #f59e0b;
            color: #f59e0b;
        }
        .bubble-reg {
            background: rgba(168, 85, 247, 0.07);
            border-left: 3px solid #a855f7;
            color: #f3e8ff;
        }
        .bubble-sec-safe {
            background: rgba(16, 185, 129, 0.07);
            border-left: 3px solid #10b981;
            color: #d1fae5;
        }
        .bubble-sec-alert {
            background: rgba(239, 68, 68, 0.12);
            border-left: 3px solid #ef4444;
            color: #fee2e2;
        }
        .bubble-whale {
            background: rgba(245, 158, 11, 0.07);
            border-left: 3px solid #f59e0b;
            color: #fef3c7;
        }

        /* 🏛️ Ajanlar Yatırım Komitesi Tartışma Odası */
        .debate-tabs {
            display: flex; gap: 6px; align-items: center;
        }
        .debate-tab-btn {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid var(--panel-border);
            color: var(--text-muted);
            padding: 3px 9px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .debate-tab-btn.active {
            background: rgba(56, 189, 248, 0.16);
            border-color: #38bdf8;
            color: #38bdf8;
        }
        .debate-list {
            padding: 8px;
            overflow-y: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .debate-card {
            background: #101622;
            border: 1px solid var(--panel-border);
            border-radius: 8px;
            padding: 9px 11px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .debate-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            padding-bottom: 6px;
        }
        .debate-sym {
            font-weight: 800;
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .debate-score {
            font-family: 'JetBrains Mono', monospace;
            font-size: 10.5px;
            font-weight: 800;
            padding: 2px 7px;
            border-radius: 4px;
        }
        .debate-score-approved {
            background: rgba(34, 197, 94, 0.15);
            border: 1px solid #22c55e;
            color: #22c55e;
        }
        .debate-score-rejected {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid #ef4444;
            color: #ef4444;
        }
        .dialogue-bubble {
            padding: 6px 9px;
            border-radius: 6px;
            font-size: 10.5px;
            line-height: 1.4;
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .bubble-bull {
            background: rgba(34, 197, 94, 0.06);
            border-left: 3px solid #22c55e;
            color: #dcfce7;
        }
        .bubble-bear {
            background: rgba(239, 68, 68, 0.06);
            border-left: 3px solid #ef4444;
            color: #fee2e2;
        }
        .bubble-macro {
            background: rgba(56, 189, 248, 0.06);
            border-left: 3px solid #38bdf8;
            color: #e0f2fe;
        }
        .bubble-quant {
            background: rgba(99, 102, 241, 0.08);
            border-left: 3px solid #818cf8;
            color: #e0e7ff;
            font-weight: 500;
        }
        .bubble-chief {
            background: rgba(245, 158, 11, 0.08);
            border-left: 3px solid #f59e0b;
            color: #fef3c7;
            font-weight: 600;
        }
        .speaker-title {
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.9;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .sent-bull { color: var(--green); font-weight: 700; }
        .sent-bear { color: var(--red); font-weight: 700; }
        .sent-neut { color: var(--cyan); font-weight: 600; }

        /* Tauric Research Episodik Hafıza & Refleksiyon Kartları */
        .reflection-card {
            background: rgba(15, 23, 42, 0.7);
            border: 1px solid rgba(148, 163, 184, 0.15);
            border-radius: 6px;
            padding: 9px 12px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            transition: all 0.2s;
        }
        .reflection-card:hover {
            border-color: rgba(56, 189, 248, 0.35);
            background: rgba(15, 23, 42, 0.9);
        }
        .reflection-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .reflection-lesson {
            font-size: 11px;
            line-height: 1.45;
            color: #e2e8f0;
        }

        /* Alt Kısım: PnL Kasası & Geçmiş */
        .bottom-panel {
            grid-column: 1 / -1;
        }
        .table-scroll { flex: 1; overflow-y: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th {
            background: #151b28; color: var(--text-muted); font-size: 10px; text-transform: uppercase;
            padding: 8px 12px; text-align: left; position: sticky; top: 0; border-bottom: 1px solid var(--panel-border);
        }
        td { padding: 8px 12px; border-bottom: 1px solid rgba(255,255,255,0.03); }
        tr:hover td { background: rgba(255,255,255,0.02); }
        .mono { font-family: 'JetBrains Mono', monospace; font-weight: 600; }

        /* 📈 Canlı TradingView BTC Futures Grafiği ve Görünüm Seçici Stilleri */
        .view-tab-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--panel-border);
            color: var(--text-muted);
            padding: 4px 10px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .view-tab-btn:hover {
            background: rgba(255, 255, 255, 0.09);
            color: #fff;
        }
        .view-tab-btn.active {
            background: rgba(56, 189, 248, 0.18);
            border-color: #38bdf8;
            color: #38bdf8;
        }

        /* Zaman Dilimi Butonları (15D, 1S, 4S, 1G) */
        .tf-btn {
            background: transparent;
            border: 1px solid transparent;
            color: var(--text-muted);
            padding: 2px 7px;
            border-radius: 3px;
            font-size: 10px;
            font-family: 'JetBrains Mono', monospace;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
        }
        .tf-btn:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.08);
        }
        .tf-btn.active {
            background: #2563eb;
            border-color: #3b82f6;
            color: #fff;
        }

        /* Tam Ekran Butonları */
        .btn-fullscreen {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--panel-border);
            color: var(--text-muted);
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-fullscreen:hover {
            background: rgba(56, 189, 248, 0.15);
            border-color: #38bdf8;
            color: #38bdf8;
        }
        .btn-exit-fullscreen {
            position: absolute;
            top: 14px;
            right: 14px;
            z-index: 1000000;
            background: rgba(239, 68, 68, 0.9);
            color: #fff;
            border: none;
            padding: 6px 14px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0,0,0,0.5);
            transition: 0.2s;
        }
        .btn-exit-fullscreen:hover {
            background: #dc2626;
            transform: scale(1.05);
        }

        /* Canlı BTC Futures Grafik Kapsayıcısı */
        .btc-chart-wrapper {
            flex: 1;
            width: 100%;
            height: 100%;
            min-height: 380px;
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            background: #090d16;
        }
        .btc-chart-wrapper.is-fullscreen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 999999;
            padding: 10px;
            background: #090d16;
        }

        /* 📱 Mobil ve Tablet Cihazlar İçin Tam Duyarlı (Responsive) Tasarım */
        @media (max-width: 1024px) {
            body {
                height: auto;
                min-height: 100vh;
                overflow-y: auto;
                user-select: auto;
            }
            .topbar-container {
                height: auto;
            }
            .topbar-system, .topbar-finance {
                height: auto;
                min-height: 42px;
                padding: 8px 12px;
                flex-wrap: wrap;
                gap: 8px;
            }
            .topbar-right {
                width: 100%;
                justify-content: space-between;
                flex-wrap: wrap;
                gap: 6px;
            }
            .workspace {
                display: flex;
                flex-direction: column;
                height: auto;
                overflow: visible;
                padding: 8px;
                gap: 12px;
            }
            .active-two-cols {
                grid-template-columns: 1fr;
                height: auto;
                max-height: 480px;
            }
            .bottom-panel {
                height: auto;
                min-height: 280px;
            }
            .panel {
                min-height: 260px;
            }
        }

        /* ==================== 🎮 3D SİMS OFİS & PATRON EFE STİLLERİ ==================== */
        .office-3d-wrapper {
            position: relative;
            width: 100%;
            height: 100%;
            flex: 1;
            overflow: hidden;
            background: radial-gradient(circle at 50% 40%, #151d2c 0%, #080c14 100%);
            border-radius: 4px;
        }

        /* 3D Ofis Tam Ekran (Fullscreen) Modu (Mobil & Masaüstü) */
        .office-3d-wrapper.is-fullscreen {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            z-index: 999999 !important;
            border-radius: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #090e18 !important;
        }

        #officeCanvasTarget {
            width: 100%;
            height: 100%;
            position: absolute;
            inset: 0;
            outline: none;
            touch-action: none;
        }

        .office-bubbles-overlay {
            position: absolute;
            inset: 0;
            pointer-events: none;
            z-index: 10;
            overflow: hidden;
        }

        /* Sims Tarzı Şeffaf & Dinamik Konuşma / Düşünce Baloncuğu (Cam Efekti) */
        .sims-bubble {
            position: absolute;
            transform: translate(-50%, -90%) scale(0.92);
            background: rgba(10, 16, 28, 0.62) !important;
            border: 1.5px solid rgba(255, 255, 255, 0.22) !important;
            border-radius: 12px;
            padding: 8px 12px;
            color: #f1f5f9;
            font-size: 11px;
            max-width: 220px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5), 0 0 15px rgba(255, 255, 255, 0.06);
            backdrop-filter: blur(14px) !important;
            -webkit-backdrop-filter: blur(14px) !important;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.4s ease, transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
            cursor: pointer;
            line-height: 1.35;
            user-select: text;
        }

        /* Konuşma anında yumuşakça belirir */
        .sims-bubble.speaking {
            opacity: 1 !important;
            pointer-events: auto !important;
            transform: translate(-50%, -100%) scale(1) !important;
        }

        .sims-bubble::after {
            content: '';
            position: absolute;
            bottom: -7px;
            left: 50%;
            transform: translateX(-50%);
            border-width: 7px 6px 0 6px;
            border-style: solid;
            border-color: rgba(10, 16, 28, 0.75) transparent transparent transparent;
        }

        /* Karakterlere Özel Renk ve Parlama Efektleri (Cam Efektli Şeffaf Zeminler) */
        .sims-bubble.boss {
            border-color: rgba(245, 158, 11, 0.65) !important;
            box-shadow: 0 0 22px rgba(245, 158, 11, 0.3), 0 8px 25px rgba(0,0,0,0.6) !important;
            background: rgba(28, 20, 8, 0.68) !important;
        }
        .sims-bubble.boss::after {
            border-top-color: rgba(245, 158, 11, 0.75);
        }

        .sims-bubble.scanner {
            border-color: rgba(56, 189, 248, 0.65) !important;
            box-shadow: 0 0 20px rgba(56, 189, 248, 0.3) !important;
            background: rgba(8, 22, 38, 0.68) !important;
        }
        .sims-bubble.scanner::after {
            border-top-color: rgba(56, 189, 248, 0.75);
        }

        .sims-bubble.ta {
            border-color: rgba(168, 85, 247, 0.65) !important;
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.3) !important;
            background: rgba(24, 10, 38, 0.68) !important;
        }
        .sims-bubble.ta::after {
            border-top-color: rgba(168, 85, 247, 0.75);
        }

        .sims-bubble.news {
            border-color: rgba(251, 146, 60, 0.65) !important;
            box-shadow: 0 0 20px rgba(251, 146, 60, 0.3) !important;
            background: rgba(32, 16, 8, 0.68) !important;
        }
        .sims-bubble.news::after {
            border-top-color: rgba(251, 146, 60, 0.75);
        }

        .sims-bubble.risk {
            border-color: rgba(239, 68, 68, 0.65) !important;
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.3) !important;
            background: rgba(34, 8, 8, 0.68) !important;
        }
        .sims-bubble.risk::after {
            border-top-color: rgba(239, 68, 68, 0.75);
        }

        .sims-bubble.quant {
            border-color: rgba(99, 102, 241, 0.5) !important;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5), 0 0 15px rgba(99, 102, 241, 0.25) !important;
        }
        .sims-bubble.quant::after {
            border-top-color: rgba(99, 102, 241, 0.7);
        }
        .sims-bubble.chief {
            border-color: rgba(16, 185, 129, 0.65) !important;
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.3) !important;
            background: rgba(8, 30, 20, 0.68) !important;
        }
        .sims-bubble.chief::after {
            border-top-color: rgba(16, 185, 129, 0.75);
        }

        .sims-bubble.friend-mehmet {
            border-color: rgba(45, 212, 191, 0.65) !important;
            box-shadow: 0 0 20px rgba(45, 212, 191, 0.3) !important;
            background: rgba(8, 28, 26, 0.68) !important;
        }
        .sims-bubble.friend-mehmet::after {
            border-top-color: rgba(45, 212, 191, 0.75);
        }

        .sims-bubble.friend-berat {
            border-color: rgba(96, 165, 250, 0.65) !important;
            box-shadow: 0 0 20px rgba(96, 165, 250, 0.3) !important;
            background: rgba(12, 22, 38, 0.68) !important;
        }
        .sims-bubble.friend-berat::after {
            border-top-color: rgba(96, 165, 250, 0.75);
        }

        .sims-bubble-header {
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: 800;
            font-size: 10px;
            text-transform: uppercase;
            margin-bottom: 4px;
            letter-spacing: 0.5px;
        }
        .sims-bubble.boss .sims-bubble-header { color: #facc15; }
        .sims-bubble.scanner .sims-bubble-header { color: #38bdf8; }
        .sims-bubble.ta .sims-bubble-header { color: #c084fc; }
        .sims-bubble.news .sims-bubble-header { color: #fb923c; }
        .sims-bubble.risk .sims-bubble-header { color: #f87171; }
        .sims-bubble.chief .sims-bubble-header { color: #34d399; }

        .sims-bubble-body {
            font-size: 11px;
            color: #f1f5f9;
            font-family: 'Inter', sans-serif;
            font-weight: 500;
        }

        /* Bilgisayar Monitörü Üstündeki Canlı İşlem Baloncuğu */
        .sims-trade-bubble {
            position: absolute;
            transform: translate(-50%, -100%);
            background: rgba(10, 15, 26, 0.95);
            border-radius: 8px;
            padding: 7px 11px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 10.5px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.7);
            pointer-events: auto;
            cursor: pointer;
            white-space: nowrap;
            z-index: 12;
            transition: all 0.2s ease;
        }
        .sims-trade-bubble.profit {
            border: 1.5px solid #10b981;
            box-shadow: 0 0 22px rgba(16, 185, 129, 0.5);
            color: #10b981;
            animation: pulse-trade-glow 2s infinite ease-in-out;
        }
        .sims-trade-bubble.loss {
            border: 1.5px solid #ef4444;
            box-shadow: 0 0 22px rgba(239, 68, 68, 0.5);
            color: #ef4444;
            animation: pulse-trade-glow 2s infinite ease-in-out;
        }
        .sims-trade-bubble.idle {
            border: 1px dashed rgba(132, 146, 166, 0.4);
            color: var(--text-muted);
            font-size: 10px;
        }
        @keyframes pulse-trade-glow {
            0%, 100% { transform: translate(-50%, -100%) scale(1); }
            50% { transform: translate(-50%, -108%) scale(1.05); }
        }

        /* 3D Office HUD Controls Bar */
        .office-hud-bar {
            position: absolute;
            top: 10px;
            left: 10px;
            right: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 12px;
            background: rgba(15, 22, 36, 0.88);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            backdrop-filter: blur(10px);
            z-index: 20;
            pointer-events: auto;
            gap: 8px;
            flex-wrap: wrap;
        }
        .office-hud-left {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .office-badge {
            background: linear-gradient(135deg, #f59e0b, #ec4899);
            color: #fff;
            font-weight: 800;
            font-size: 9.5px;
            padding: 3px 7px;
            border-radius: 5px;
            letter-spacing: 0.5px;
        }
        .office-title {
            font-size: 11px;
            color: #e2e8f0;
        }
        .office-title strong {
            color: #facc15;
            letter-spacing: 0.5px;
        }
        .office-hud-controls {
            display: flex;
            gap: 4px;
            align-items: center;
            flex-wrap: wrap;
        }
        .office-hud-btn {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: #cbd5e1;
            font-size: 10px;
            font-weight: 600;
            padding: 4px 9px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .office-hud-btn:hover {
            background: rgba(255, 255, 255, 0.16);
            color: #fff;
        }
        .office-hud-btn.active {
            background: rgba(245, 158, 11, 0.25);
            border-color: #f59e0b;
            color: #facc15;
        }
        .office-status-pill {
            font-size: 10px;
            color: #94a3b8;
            background: rgba(0, 0, 0, 0.35);
            padding: 3px 8px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        /* 📱 Mobil ve Tablet Cihazlar İçin Özel İyileştirmeler (Responsive Adaptation) */
        @media (max-width: 1024px) {
            #leftPanel.office-view-active {
                height: 68vh !important;
                min-height: 480px !important;
            }
            .office-3d-wrapper {
                min-height: 480px;
                height: 100%;
            }
            .office-hud-bar {
                top: 6px;
                left: 6px;
                right: 6px;
                padding: 4px 6px;
                gap: 4px;
                background: rgba(10, 16, 28, 0.94);
            }
            .office-title {
                display: none;
            }
            .office-status-pill {
                display: none;
            }
            .office-hud-btn {
                font-size: 9px;
                padding: 3px 6px;
            }
            .sims-bubble {
                max-width: 155px;
                font-size: 9.5px;
                padding: 5px 8px;
                border-radius: 8px;
            }
            .sims-bubble-header {
                font-size: 8.5px;
                margin-bottom: 2px;
            }
            .sims-bubble-body {
                font-size: 9px;
                line-height: 1.25;
            }
            .sims-trade-bubble {
                font-size: 9px;
                padding: 4px 8px;
            }
        }
        .bot-mode-btn {
            background: transparent;
            border: none;
            color: #94a3b8;
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.15s;
        }
        .bot-mode-btn:hover { color: #fff; }
        .bot-mode-btn.active {
            background: #2563eb;
            color: #fff;
            box-shadow: 0 0 10px rgba(37,99,235,0.4);
        }
        .bot-mode-btn#btnModeFast.active {
            background: linear-gradient(135deg, #f59e0b, #ea580c);
            color: #fff;
            box-shadow: 0 0 12px rgba(245,158,11,0.5);
        }
        .bot-mode-btn#btnModeSuperFast.active {
            background: linear-gradient(135deg, #ec4899, #8b5cf6);
            color: #fff;
            box-shadow: 0 0 12px rgba(236,72,153,0.5);
        }
    </style>
</head>
<body>

    <!-- 2-Katmanlı Üst Panel: Üstte Takip & Sistem Barı, Altta Finans & PnL Barı -->
    <div class="topbar-container">
        <!-- 1. BAR: Sistem & Takip Barı (Sol: Marka & Saat, Orta: BTC & Kotalar, Sağ: Aksiyon Butonları) -->
        <div class="topbar-system">
            <div class="brand">
                <div class="brand-badge">⚡</div>
                <span>3-Vadeli Quant Terminali</span>
                <span style="font-size: 10px; background: rgba(16,185,129,0.15); color: #10b981; padding: 2px 7px; border-radius: 10px; font-weight: 600;">● CANLI</span>
                <span id="wsBadge" style="font-size: 10px; background: rgba(56,189,248,0.15); color: #38bdf8; padding: 2px 7px; border-radius: 10px; font-weight: 600;">⚡ WSS AKTİF</span>
                <span id="topTrClock" style="font-size: 10.5px; background: rgba(239,68,68,0.15); color: #f87171; border: 1px solid rgba(239,68,68,0.3); padding: 2px 8px; border-radius: 10px; font-weight: 700; font-family: 'JetBrains Mono', monospace;" title="Türkiye Saati (TSİ / UTC+3)">🇹🇷 TSİ --:--:--</span>

                <!-- 3-Zaman Dilimli Çoklu-Vade Durum Rozeti -->
                <div style="display: flex; align-items: center; gap: 4px; background: rgba(15,23,42,0.85); padding: 2px 7px; border-radius: 20px; border: 1px solid rgba(56,189,248,0.25); margin-left: 6px; white-space: nowrap;">
                    <span style="font-size: 9px; font-weight: 800; color: #94a3b8;">VADELER:</span>
                    <span style="background:rgba(56,189,248,0.2); color:#38bdf8; border:1px solid rgba(56,189,248,0.4); padding: 1px 5px; border-radius: 4px; font-size: 9.5px; font-weight: 700;">15m</span>
                    <span style="background:rgba(168,85,247,0.2); color:#c084fc; border:1px solid rgba(168,85,247,0.4); padding: 1px 5px; border-radius: 4px; font-size: 9.5px; font-weight: 700;">30m</span>
                    <span style="background:rgba(245,158,11,0.2); color:#fbbf24; border:1px solid rgba(245,158,11,0.4); padding: 1px 5px; border-radius: 4px; font-size: 9.5px; font-weight: 700;">1h</span>
                </div>
            </div>

            <!-- Takip ve Koruma İstatistikleri -->
            <div class="top-stat-group">
                <div class="top-stat" style="cursor: pointer;" onclick="switchLeftView('btc')" title="Tıkla: Canlı BTC Mum Grafiğini Aç">
                    <span class="lbl">BTC Rejimi:</span>
                    <span class="val" id="topBtc" style="color: var(--yellow);">TARANIYOR</span>
                </div>
                <div class="top-stat" title="Anlık Eşzamanlı Açık Pozisyon Slotu (Azami 8 Slot)">
                    <span class="lbl">Kasa Kalkanı:</span>
                    <span class="val" id="topShieldQuota" style="color: var(--green);">0/8 Slot</span>
                </div>
                <div class="top-stat" style="border: 1px solid rgba(168, 85, 247, 0.35); background: rgba(168, 85, 247, 0.08); border-radius: 6px; padding: 2px 8px;" title="Bugünkü Toplam İşlem Kotası ve Vade Dağılımı (TSİ 00:00 - 23:59 Sıfırlanır)">
                    <span class="lbl">Günlük Kota:</span>
                    <span class="val" id="topTimelineQuota" style="color: #c084fc; font-weight: 700; font-size: 11px; white-space: nowrap;">0/12 Toplam (⚡0/5 • 🎯0/4 • 👑0/3)</span>
                </div>
            </div>

            <!-- Aksiyon Butonları -->
            <div style="display: flex; gap: 5px; align-items: center; flex-shrink: 0;">
                <button class="btn-scan" style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.25), rgba(168, 85, 247, 0.25)); color: #facc15; border: 1px solid rgba(245, 158, 11, 0.5); font-weight: 700;" onclick="switchLeftView('office')" title="Sims Tarzı 3D Yapay Zeka İşlem Ofisi">🎮 3D Ofis</button>
                <button class="btn-scan" style="background: rgba(245,158,11,0.18); color: #f59e0b; border: 1px solid rgba(245,158,11,0.4);" onclick="switchLeftView('btc')" title="Canlı BTC Vadeli Mum Grafiğini Aç">📈 BTC Grafik</button>
                <button class="btn-scan" onclick="triggerScan()">⚡ Tara</button>
            </div>
        </div>

        <!-- 2. BAR: Finans, PnL & Kasa Barı (Cüzdan, Kâr/Zarar ve Performans) -->
        <div class="topbar-finance">
            <!-- Sol: Cüzdan ve Kâr / Zarar Durumu -->
            <div class="top-stat-group">
                <div class="top-stat" title="Güncel Toplam Fon Sermayesi">
                    <span class="lbl">Fon Kasası:</span>
                    <span class="val" id="topEquity" style="color: #38bdf8;">$1,000.00</span>
                </div>
                <div class="top-stat" title="Kapanan İşlemlerden Elde Edilen Net Kâr Oranı">
                    <span class="lbl">Genel Kâr:</span>
                    <span class="val" id="topRealized" style="color: var(--green);">+0.0%</span>
                </div>
                <div class="top-stat" style="border: 1px solid rgba(16, 185, 129, 0.35); background: rgba(16, 185, 129, 0.1); border-radius: 6px; padding: 2px 8px;" title="Türkiye Saati (TRT 00:00 - 23:59 arası). 23:59:59'da otomatik sıfırlanır ve arşivlenir.">
                    <span class="lbl">Bugünkü PnL:</span>
                    <span class="val" id="topTodayPnl" style="color: var(--green); font-weight: 700;">+$0.00 (%0.0)</span>
                </div>
                <div class="top-stat" style="border: 1px solid rgba(56, 189, 248, 0.35); background: rgba(56, 189, 248, 0.08); border-radius: 6px; padding: 2px 8px;" title="Şu An Açık Olan Pozisyonların Canlı Gerçekleşmemiş Net PnL Tutarı">
                    <span class="lbl">Canlı PnL:</span>
                    <span class="val" id="topUnrealized" style="color: var(--text-muted); font-weight: 700;">+$0.00 (%0.0)</span>
                </div>
            </div>

            <!-- Sağ: İstatistikler ve Metrikler -->
            <div class="top-stat-group">
                <div class="top-stat" title="Ödenen Tahmini Borsa Komisyonu">
                    <span class="lbl">Komisyon:</span>
                    <span class="val" id="topFees" style="color: #f59e0b;">-%0.0</span>
                </div>
                <div class="top-stat" title="Başarılı İşlem Oranı (Win Rate)">
                    <span class="lbl">Win Rate:</span>
                    <span class="val" id="topWinRate" style="color: var(--yellow);">%0.0</span>
                </div>
                <div class="top-stat" title="Toplam Brüt Kazanç / Toplam Kayıp">
                    <span class="lbl">Kâr Faktörü:</span>
                    <span class="val" id="topProfitFactor" style="color: #38bdf8;">0.0</span>
                </div>
                <div class="top-stat" style="border: 1px solid rgba(255, 255, 255, 0.1); background: rgba(255, 255, 255, 0.04); border-radius: 6px; padding: 2px 7px;">
                    <span class="lbl" style="color: #94a3b8;">🛡️ Risk Kalkanı:</span>
                    <span class="val" style="color: #e2e8f0; font-size: 10px;">%2.0 / $20 Sabit</span>
                </div>
            </div>
        </div>
    </div>

    <!-- ⚡ FAST Modu Bilgilendirme ve Kasa Ayrım Şeridi -->
    <div id="fastModeBanner" style="display: none; background: linear-gradient(90deg, rgba(245,158,11,0.18), rgba(234,88,12,0.12)); border-bottom: 1px solid rgba(245,158,11,0.35); padding: 5px 16px; font-size: 11px; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 8px;">
            <span style="background: #f59e0b; color: #000; font-weight: 800; font-size: 10px; padding: 2px 6px; border-radius: 4px;">⚡ FAST MODU</span>
            <span style="color: #fde047; font-weight: 600;">1 Dakikalık Mumlar & Seri Scalp Motoru</span>
            <span style="color: var(--text-muted);">|</span>
            <span style="color: #94a3b8;">Bağımsız Kasa: <strong style="color: #38bdf8;">$1,000.00 USDT</strong></span>
            <span style="color: var(--text-muted);">|</span>
            <span style="color: #94a3b8;">Hedef: <strong style="color: var(--green);">+%0.65</strong> | Stop: <strong style="color: var(--red);">-%0.40</strong> | Max Süre: <strong style="color: var(--yellow);">15 dk</strong></span>
        </div>
        <div style="color: #f59e0b; font-weight: 600; font-size: 10px;">⚡ YÜKSEK FREKANSLI MİKRO İŞLEMLER (BOL İŞLEMLİ)</div>
    </div>

    <!-- Main Workspace -->
    <div class="workspace">

        <!-- 1. SOL SÜTUN: Canlı BTC Futures Grafiği & Aktif Pozisyonlar Masası -->
        <div class="panel" id="leftPanel">
            <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 6px;">
                    <button class="view-tab-btn active" id="tabViewBtc" onclick="switchLeftView('btc')">
                        📈 CANLI BTC (FUTURES)
                    </button>
                    <button class="view-tab-btn" id="tabViewPositions" onclick="switchLeftView('positions')">
                        ⚡ POZİSYONLAR (<span id="activeCountBtn">0</span>)
                    </button>
                    <button class="view-tab-btn" id="tabViewSplit" onclick="switchLeftView('split')">
                        🔲 İKİLİ GÖRÜNÜM
                    </button>
                    <button class="view-tab-btn" id="tabViewOffice" onclick="switchLeftView('office')" style="border-color: rgba(245, 158, 11, 0.4); color: #facc15;">
                        🎮 3D OFİS (PATRON: EFE)
                    </button>
                    <span class="counter" id="activeCount" style="display: none;">0 Aktif</span>
                </div>
                
                <div style="display: flex; align-items: center; gap: 6px;">
                    <!-- 15D, 1S, 4S, 1G Zaman Dilimi Seçici -->
                    <div id="btcTfGroup" style="display: flex; gap: 3px; align-items: center; background: rgba(0,0,0,0.3); padding: 2px 6px; border-radius: 4px; border: 1px solid var(--panel-border);">
                        <span style="font-size: 9.5px; color: var(--text-muted); font-weight: 700;">PERİYOT:</span>
                        <button class="tf-btn active" id="tf-15" onclick="changeBtcTimeframe('15')">15D</button>
                        <button class="tf-btn" id="tf-60" onclick="changeBtcTimeframe('60')">1S</button>
                        <button class="tf-btn" id="tf-240" onclick="changeBtcTimeframe('240')">4S</button>
                        <button class="tf-btn" id="tf-D" onclick="changeBtcTimeframe('D')">1G</button>
                    </div>
                    <button class="btn-fullscreen" onclick="toggleBtcFullscreen()" title="Grafiği Tam Ekran Yap">⛶ Tam Ekran</button>
                </div>
            </div>

            <!-- CANLI TRADINGVIEW BITCOIN FUTURES GRAFİĞİ -->
            <div id="btcChartContainer" class="btc-chart-wrapper">
                <button class="btn-exit-fullscreen" id="btnExitFs" onclick="toggleBtcFullscreen()" style="display: none;">✕ Tam Ekrandan Çık (ESC)</button>
                <div id="tv_chart_target" style="width: 100%; height: 100%;"></div>
            </div>

            <!-- AKTİF POZİSYONLAR ALANI -->
            <div id="positionsContainer" style="display: none; flex-direction: column; flex: 1; overflow: hidden;">
                <!-- En Üst: Ne kadar aktif işlem olduğu özeti -->
                <div class="active-summary-bar">
                    <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                        <span class="sum-badge all">🎯 Toplam: <strong id="totalActiveCount">0</strong> Aktif (<strong id="totalActiveDollar">$0.00</strong>)</span>
                        <span class="sum-badge quota" style="background: rgba(168,85,247,0.15); border: 1px solid rgba(168,85,247,0.35); color: #c084fc;" title="Bugünkü Toplam İşlem Kotası ve Vade Dağılımı">
                            📊 Günlük Kota: <strong id="barDailyQuota" style="color: #38bdf8;">0/12 İşlem</strong> 
                            <span id="barDailyQuotaDetails" style="font-size: 10px; color: var(--text-muted); margin-left: 4px;">(⚡0/5 • 🎯0/4 • 👑0/3)</span>
                        </span>
                    </div>
                    <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                        <span class="sum-badge green">🟢 Kârda: <strong id="greenActiveCount">0</strong> (<strong id="greenActiveDollar">+$0.00</strong>)</span>
                        <span class="sum-badge red">🔴 Zararda: <strong id="redActiveCount">0</strong> (<strong id="redActiveDollar">-$0.00</strong>)</span>
                        <button class="btn-group-close btn-close-profit" onclick="closePositionsGroup('profit')" title="KÂRDAKİ tüm açık pozisyonları anında piyasa fiyatından kapat">💰 Kârdakileri Kapat</button>
                        <button class="btn-group-close btn-close-loss" onclick="closePositionsGroup('loss')" title="ZARARDAKİ tüm açık pozisyonları anında piyasa fiyatından kapat">🛑 Zarardakileri Kapat</button>
                        <button class="btn-panic" onclick="closeAllPositions()" title="Tüm açık işlemleri anlık fiyattan kapat">🚫 Tümünü Kapat</button>
                    </div>
                </div>
                <!-- Yan Yana İki Sütunlu Grid: Sol = KÂR, Sağ = ZARAR -->
                <div class="active-two-cols">
                    <!-- SOL SÜTUN: 🟢 KÂRDAKİ POZİSYONLAR -->
                    <div class="active-sub-col">
                        <div class="pos-section-header green-sec" style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span>🟢 KÂRDAKİLER (<span id="profitColCount">0</span>)</span>
                                <span class="pos-section-sub" id="profitColTotalDollar" style="margin-left: 6px; font-weight: 700; color: #22c55e;">+$0.00</span>
                            </div>
                            <button class="btn-group-close btn-close-profit" onclick="closePositionsGroup('profit')" title="KÂRDAKİ tüm açık pozisyonları piyasa fiyatından hemen kapat">
                                💰 Kârdakileri Kapat
                            </button>
                        </div>
                        <div class="cards-sub-list" id="profitList">
                            <div style="text-align: center; color: var(--text-muted); padding: 30px 10px; font-size: 11px;">
                                Kârda pozisyon aranıyor...
                            </div>
                        </div>
                    </div>

                    <!-- SAĞ SÜTUN: 🔴 ZARARDAKİ POZİSYONLAR -->
                    <div class="active-sub-col">
                        <div class="pos-section-header red-sec" style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span>🔴 ZARARDAKİLER (<span id="lossColCount">0</span>)</span>
                                <span class="pos-section-sub" id="lossColTotalDollar" style="margin-left: 6px; font-weight: 700; color: #ef4444;">-$0.00</span>
                            </div>
                            <button class="btn-group-close btn-close-loss" onclick="closePositionsGroup('loss')" title="ZARARDAKİ tüm açık pozisyonları piyasa fiyatından hemen kapat">
                                🛑 Zarardakileri Kapat
                            </button>
                        </div>
                        <div class="cards-sub-list" id="lossList">
                            <div style="text-align: center; color: var(--text-muted); padding: 30px 10px; font-size: 11px;">
                                Zararda pozisyon yok.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 3D SİMS TARZI OFİS ALANI (PATRON: EFE & AJANLAR) -->
            <div id="office3dContainer" class="office-3d-wrapper" style="display: none;">
                <button class="btn-exit-fullscreen" id="btnExitOfficeFs" onclick="toggleOfficeFullscreen()" style="display: none;">✕ Tam Ekrandan Çık (ESC)</button>
                <div id="officeCanvasTarget"></div>
                
                <!-- 2D Sims Konuşma Baloncukları & Canlı İşlem Göstergesi Katmanı -->
                <div id="officeOverlay" class="office-bubbles-overlay">
                    <!-- Boss Efe Bubble -->
                    <div id="bubble-boss" class="sims-bubble boss" onclick="setOfficeCamera('boss')" title="Tıkla: Patron Efe'ye Odaklan">
                        <div class="sims-bubble-header">👑 PATRON: EFE</div>
                        <div class="sims-bubble-body" id="text-boss">Piyasayı tarayın beyler, acele yok, sermaye koruma önceliğimiz!</div>
                    </div>
                    <!-- Scanner Agent Bubble -->
                    <div id="bubble-scanner" class="sims-bubble scanner" onclick="setOfficeCamera('table')" title="Tıkla: Masaya Odaklan">
                        <div class="sims-bubble-header">📡 SCANNER AGENT</div>
                        <div class="sims-bubble-body" id="text-scanner">200+ parite taranıyor...</div>
                    </div>
                    <!-- TA Analyst Bubble -->
                    <div id="bubble-ta" class="sims-bubble ta" onclick="setOfficeCamera('table')" title="Tıkla: Masaya Odaklan">
                        <div class="sims-bubble-header">📊 TEKNİK ANALİST</div>
                        <div class="sims-bubble-body" id="text-ta">BTC 4s bant daralması inceleniyor.</div>
                    </div>
                    <!-- News Agent Bubble -->
                    <div id="bubble-news" class="sims-bubble news" onclick="setOfficeCamera('table')" title="Tıkla: Masaya Odaklan">
                        <div class="sims-bubble-header">📰 HABER & MAKRO</div>
                        <div class="sims-bubble-body" id="text-news">Funding rate stabil, kritik haber yok.</div>
                    </div>
                    <!-- Risk Officer Bubble -->
                    <div id="bubble-risk" class="sims-bubble risk" onclick="setOfficeCamera('table')" title="Tıkla: Masaya Odaklan">
                        <div class="sims-bubble-header">🛡️ RİSK ŞEFİ</div>
                        <div class="sims-bubble-body" id="text-risk">Kasa Kalkanı devrede: Maks 5x kaldıraç.</div>
                    </div>
                    <!-- Quant Simulation Agent Bubble -->
                    <div id="bubble-quant" class="sims-bubble quant" onclick="setOfficeCamera('table')" title="Tıkla: Masaya Yaklaş">
                        <div class="sims-bubble-header" style="color: #818cf8;">🎲 KUANT SİMÜLASYON</div>
                        <div class="sims-bubble-body" id="text-quant">10,000 Monte Carlo fiyat yolu koşturuldu, TP olasılığı %70+ filtrede!</div>
                    </div>
                    <!-- Chief Analyst Bubble -->
                    <div id="bubble-chief" class="sims-bubble chief" onclick="setOfficeCamera('table')" title="Tıkla: Masaya Odaklan">
                        <div class="sims-bubble-header">🏛️ BAŞ STRATEJİST</div>
                        <div class="sims-bubble-body" id="text-chief">Efe Bey, piyasa şu an chop bölgesinde, bekliyoruz.</div>
                    </div>
                    <!-- Mehmet Bubble (Arkadaş) -->
                    <div id="bubble-mehmet" class="sims-bubble friend-mehmet" onclick="setOfficeCamera('chill')" title="Tıkla: Mehmet Konuşsun">
                        <div class="sims-bubble-header" style="color: #2dd4bf;">🏓 MEHMET (ARKADAŞ)</div>
                        <div class="sims-bubble-body" id="text-mehmet">Berat çay koysana kanka ya, semaver kaynıyor!</div>
                    </div>
                    <!-- Berat Bubble (Arkadaş) -->
                    <div id="bubble-berat" class="sims-bubble friend-berat" onclick="setOfficeCamera('chill')" title="Tıkla: Berat Konuşsun">
                        <div class="sims-bubble-header" style="color: #60a5fa;">⚽ BERAT (ARKADAŞ)</div>
                        <div class="sims-bubble-body" id="text-berat">Mehmet masa tenisinde dün şansın yaver gitti, gel rövanşa!</div>
                    </div>
                    <!-- Bilgisayar Ekranı Canlı İşlem Baloncuğu -->
                    <div id="tradeMonitorBubble" class="sims-trade-bubble idle" onclick="switchLeftView('positions')" title="Tıkla: Pozisyon Detaylarını Aç">
                        💤 AKTİF İŞLEM YOK (200 Parite Radarda)
                    </div>
                </div>

                <!-- 3D Ofis Üst Kontrol HUD Çubuğu -->
                <div class="office-hud-bar">
                    <div class="office-hud-left">
                        <span class="office-badge">🎮 3D OFİS</span>
                        <span class="office-title">PATRON: <strong>EFE</strong></span>
                    </div>
                    <div class="office-hud-controls">
                        <button class="office-hud-btn active" id="btnCamBoss" onclick="setOfficeCamera('boss')" title="Patron Efe'ye Odaklan">👑 Patron Efe</button>
                        <button class="office-hud-btn" id="btnCamTable" onclick="setOfficeCamera('table')" title="Ajanların Masasına Odaklan">📊 Masa</button>
                        <button class="office-hud-btn" id="btnCamIso" onclick="setOfficeCamera('iso')" title="İzometrik Kuşbakışı">🏢 Kuşbakışı</button>
                        <button class="office-hud-btn" id="btnCamChill" onclick="setOfficeCamera('chill')" title="Mehmet & Berat Oyun & Çay Alanı">🏓 Oyun & Çay</button>
                        <button class="office-hud-btn" id="btnToggleBubbles" onclick="cycleBubbleMode()" title="Baloncuk Görünümünü Değiştir (Akıllı/Tümü/Patron/Gizli)">💬 Balon</button>
                        <button class="office-hud-btn" id="btnOfficeFs" onclick="toggleOfficeFullscreen()" title="Tam Ekran Modu">⛶ Tam Ekran</button>
                        <button class="office-hud-btn" id="btnConfetti" onclick="triggerOfficeConfetti()" title="Kutlama & Konfeti Patlat">🎉 Konfeti</button>
                        <button class="office-hud-btn" id="btnOfficeAudio" onclick="toggleOfficeSound()" title="Ofis Sesi">🔊</button>
                    </div>
                    <div class="office-hud-right">
                        <span id="officeStatusPill" class="office-status-pill">👑 Efe Masada | Piyasayı Gözlüyor</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. SAĞ SÜTUN: Ofis Çalışanları Masası (Tarama & Haber) -->
        <div class="right-split">

            <!-- Üst: 📡 Analiz Masası (Neden Elendi / Uygun Bulundu & Kontrol Sıklığı) -->
            <div class="panel">
                <div class="panel-header">
                    <span id="scanPanelTitle">📡 15M TARAMA & SCALP MASASI (200+ PARİTE ROTASYONU)</span>
                    <span class="counter" id="logCount">Canlı Rotasyon</span>
                </div>
                <div class="log-list" id="logList">
                    <div style="text-align: center; color: var(--text-muted); padding: 20px; font-size: 11px;">
                        Taranan coinler inceleniyor...
                    </div>
                </div>
            </div>

            <!-- Alt (Sağ Alt): 🏛️ Ajanlar Yatırım Komitesi & Haber Masası & AI Hafıza & Otonom Kalibrasyon -->
            <div class="panel">
                <div class="panel-header">
                    <div class="debate-tabs">
                        <button class="debate-tab-btn active" id="tabDebateBtn" onclick="switchRightTab('debate')">🏛️ KOMİTE</button>
                        <button class="debate-tab-btn" id="tabReflectBtn" onclick="switchRightTab('reflections')">🧠 HAFIZA</button>
                        <button class="debate-tab-btn" id="tabTuningBtn" onclick="switchRightTab('tuning')">🧬 OTONOM ÖĞRENME</button>
                        <button class="debate-tab-btn" id="tabNewsBtn" onclick="switchRightTab('news')">📰 HABER</button>
                    </div>
                    <span class="counter" id="debateCounter" style="color: #38bdf8;">Canlı Tartışma Odası</span>
                </div>
                
                <!-- Canlı Ajanlar Tartışma Odası (Tab 1) -->
                <div class="debate-list" id="debateList">
                    <div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">
                        🏛️ Ajanlar taranan pariteleri karşılıklı tartışmak üzere hazır bekliyor...
                    </div>
                </div>

                <!-- 🧠 Tauric Research Episodik Hafıza Defteri (Tab 2) -->
                <div class="debate-list" id="reflectionsList" style="display: none; flex-direction: column; gap: 8px;">
                    <div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">
                        🧠 AI Hafıza Defteri yükleniyor...
                    </div>
                </div>

                <!-- 🧬 Otonom Kendi Kendini Geliştirme & Parametre Kalibrasyonu (Tab 3) -->
                <div class="debate-list" id="tuningList" style="display: none; flex-direction: column; gap: 8px;">
                    <div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">
                        🧬 Otonom Öğrenme Motoru yükleniyor...
                    </div>
                </div>

                <!-- 📰 Haber Akışı & Haber Kararlandırma Konseyi (Tab 4) -->
                <div id="newsContainer" style="display: none; flex-direction: column; height: 100%; overflow: hidden; flex: 1;">
                    <!-- Üst Kontrol & Hızlı Arama Çubuğu -->
                    <div class="news-sub-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div style="display: flex; gap: 5px;">
                                <button class="news-subtab-btn active" id="btnSubCouncil" onclick="switchNewsSubTab('council')">
                                    🏛️ Coine Özel Konsey <span id="councilBadgeCount" style="opacity: 0.8; font-size: 9px;">(0)</span>
                                </button>
                                <button class="news-subtab-btn" id="btnSubRss" onclick="switchNewsSubTab('rss')">
                                    🌐 Küresel RSS <span id="rssBadgeCount" style="opacity: 0.8; font-size: 9px;">(0)</span>
                                </button>
                            </div>
                            <span style="font-size: 10px; color: #f59e0b; font-family: 'JetBrains Mono'; font-weight: 700;" id="newsCouncilStatus">🛡️ 3 Masalı Konsey</span>
                        </div>
                        
                        <!-- Hızlı Coin Araştırma Çubuğu -->
                        <div style="display: flex; gap: 5px; align-items: center; background: #0c101b; padding: 4px 6px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.08);">
                            <span style="font-size: 11px;">🪙</span>
                            <input type="text" id="coinNewsInput" placeholder="Coin Araştır (örn: SOL, BTC, KAVA, PEPE)" 
                                   style="background: transparent; border: none; color: #fff; font-size: 11px; flex: 1; outline: none; font-family: 'JetBrains Mono';"
                                   onkeydown="if(event.key === 'Enter') triggerManualNewsInvestigation();">
                            <select id="coinNewsDir" style="background: #141926; border: 1px solid var(--panel-border); color: #38bdf8; font-size: 10px; font-weight: 700; border-radius: 4px; padding: 2px 4px; outline: none; cursor: pointer;">
                                <option value="LONG">🟢 LONG</option>
                                <option value="SHORT">🔴 SHORT</option>
                            </select>
                            <button onclick="triggerManualNewsInvestigation()" id="btnInvestigateCoin"
                                    style="background: #38bdf8; color: #090d16; border: none; font-size: 10px; font-weight: 800; padding: 4px 9px; border-radius: 4px; cursor: pointer; display: flex; align-items: center; gap: 3px; transition: 0.2s;">
                                <span id="investigateSpinner" style="display: none;">⏳</span> <span>🔍 Konseyi Çalıştır</span>
                            </button>
                        </div>
                    </div>

                    <!-- 1. Coine Özel Konsey Raporları Akışı -->
                    <div class="news-list" id="councilReportList" style="flex: 1; overflow-y: auto; padding: 8px; display: flex; flex-direction: column; gap: 8px;">
                        <div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">
                            🏛️ Coine özel haber konseyi raporları yükleniyor...
                        </div>
                    </div>

                    <!-- 2. Küresel Piyasa RSS Akışı (Mevcut Liste) -->
                    <div class="news-list" id="newsList" style="flex: 1; overflow-y: auto; padding: 8px; display: none; flex-direction: column; gap: 6px;">
                        <div style="text-align: center; color: var(--text-muted); padding: 20px; font-size: 11px;">
                            Piyasa haberleri çekiliyor...
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- 3. ALT BÖLÜM: PnL Kasası & Tamamlanan İşlemler -->
        <div class="panel bottom-panel">
            <div class="panel-header">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span>💰 PnL KASASI & TAMAMLANAN İŞLEM DEFTERİ</span>
                    <button class="btn-clear" onclick="clearTradeHistory()">🗑️ Geçmişi Temizle</button>
                </div>
                <span class="counter" id="historyCount">0 İşlem</span>
            </div>
            <div class="table-scroll">
                <table>
                    <thead>
                        <tr>
                            <th>Kapanış (TSİ)</th>
                            <th>Parite</th>
                            <th>Yön</th>
                            <th>Kaldıraç</th>
                            <th>Vade / Grafik</th>
                            <th>Giriş Fiyatı</th>
                            <th>Çıkış Fiyatı</th>
                            <th>Sonuç</th>
                            <th>Net Marjin PnL</th>
                        </tr>
                    </thead>
                    <tbody id="historyBody">
                        <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 20px;">Kapanan işlem kaydı yok.</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script>
        let prevProfitHtml = '';
        let prevLossHtml = '';
        let prevLogsHtml = '';
        let prevDebatesHtml = '';
        let prevReflectHtml = '';
        let prevTuningHtml = '';
        let prevNewsHtml = '';
        let prevCouncilHtml = '';
        let prevHistHtml = '';

        // Sol Panel Görünüm Modları: 'btc' (Sadece BTC), 'positions' (Sadece Pozisyonlar), 'split' (İkili)
        let currentLeftView = localStorage.getItem('leftViewMode') || 'btc';
        let currentBtcInterval = localStorage.getItem('btcInterval') || '15';
        let tvWidget = null;
        let lastRenderedInterval = null;

        // 3D Ofis Başlatma Köprüsü (Hata Korumalı)
        function initOrResizeOffice3D() {
            try {
                if (typeof init3DOffice === 'function' && !officeInitialized) {
                    init3DOffice();
                } else if (typeof resizeOffice3D === 'function') {
                    resizeOffice3D();
                }
            } catch (e) {
                console.error("Office init safeguard error:", e);
            }
        }

        let currentBotMode = localStorage.getItem('botMode') || 'standard';

        function switchBotMode(mode) {
            currentBotMode = mode;
            localStorage.setItem('botMode', mode);

            const btnStd = document.getElementById('btnModeStandard');
            const btnFast = document.getElementById('btnModeFast');
            const btnSuper = document.getElementById('btnModeSuperFast');
            const banner = document.getElementById('fastModeBanner');
            const brandBadge = document.querySelector('.brand-badge');

            if (btnStd) btnStd.classList.toggle('active', mode === 'standard');
            if (btnFast) btnFast.classList.toggle('active', mode === 'fast');
            if (btnSuper) btnSuper.classList.toggle('active', mode === 'superfast');

            const scanTitle = document.getElementById('scanPanelTitle');
            if (mode === 'superfast') {
                if (banner) {
                    banner.style.display = 'flex';
                    banner.style.borderColor = 'rgba(236,72,153,0.3)';
                    banner.style.background = 'linear-gradient(90deg, rgba(236,72,153,0.12), rgba(139,92,246,0.12))';
                    banner.innerHTML = '⚡⚡ <strong>SÜPER FAST Modu Aktif</strong> (Saniyelik Mumlar & HFT Tick Akışı | Bağımsız $1000 USDT Kasası | Maksimum 20 İşlem Sınırı)';
                }
                if (brandBadge) {
                    brandBadge.innerText = '⚡⚡';
                    brandBadge.style.background = 'linear-gradient(135deg, #ec4899, #8b5cf6)';
                }
                if (scanTitle) {
                    scanTitle.innerHTML = '⚡⚡ SANİYELİK HFT TARAMA MASASI (15 LİKİT PARİTE)';
                }
            } else if (mode === 'fast') {
                if (banner) {
                    banner.style.display = 'flex';
                    banner.style.borderColor = 'rgba(245,158,11,0.3)';
                    banner.style.background = 'linear-gradient(90deg, rgba(245,158,11,0.12), rgba(234,88,12,0.12))';
                    banner.innerHTML = '⚡ <strong>FAST Scalper Modu Aktif</strong> (1m Mumlar | Bağımsız $1000 USDT Kasası | Maksimum 10 İşlem Sınırı)';
                }
                if (brandBadge) {
                    brandBadge.innerText = '⚡';
                    brandBadge.style.background = 'linear-gradient(135deg, #f59e0b, #ea580c)';
                }
                if (scanTitle) {
                    scanTitle.innerHTML = '⚡ 1M TARAMA & FAST SCALP MASASI (15 LİKİT PARİTE)';
                }
            } else {
                if (banner) banner.style.display = 'none';
                if (brandBadge) {
                    brandBadge.innerText = '🏛️';
                    brandBadge.style.background = 'linear-gradient(135deg, #0284c7, #2563eb)';
                }
                if (scanTitle) {
                    scanTitle.innerHTML = '📡 15M TARAMA & SCALP MASASI (200+ PARİTE ROTASYONU)';
                }
            }

            prevProfitHtml = '';
            prevLossHtml = '';
            prevLogsHtml = '';
            prevHistHtml = '';

            if (window.lastTerminalData) {
                renderAll(window.lastTerminalData);
            }
        }

        function switchLeftView(mode) {
            currentLeftView = mode;
            localStorage.setItem('leftViewMode', mode);

            const btcContainer = document.getElementById('btcChartContainer');
            const posContainer = document.getElementById('positionsContainer');
            const officeContainer = document.getElementById('office3dContainer');
            const tfGroup = document.getElementById('btcTfGroup');
            const tabBtc = document.getElementById('tabViewBtc');
            const tabPos = document.getElementById('tabViewPositions');
            const tabSplit = document.getElementById('tabViewSplit');
            const tabOffice = document.getElementById('tabViewOffice');

            if (tabBtc) tabBtc.classList.toggle('active', mode === 'btc');
            if (tabPos) tabPos.classList.toggle('active', mode === 'positions');
            if (tabSplit) tabSplit.classList.toggle('active', mode === 'split');
            if (tabOffice) tabOffice.classList.toggle('active', mode === 'office');

            if (mode === 'btc') {
                if (btcContainer) {
                    btcContainer.style.display = 'flex';
                    btcContainer.style.flex = '1';
                    btcContainer.style.height = '100%';
                    btcContainer.style.borderBottom = 'none';
                }
                if (posContainer) posContainer.style.display = 'none';
                if (officeContainer) officeContainer.style.display = 'none';
                if (tfGroup) tfGroup.style.display = 'flex';
                renderTradingView();
            } else if (mode === 'positions') {
                if (btcContainer) btcContainer.style.display = 'none';
                if (officeContainer) officeContainer.style.display = 'none';
                if (posContainer) {
                    posContainer.style.display = 'flex';
                    posContainer.style.flex = '1';
                    posContainer.style.height = '100%';
                }
                if (tfGroup) tfGroup.style.display = 'none';
            } else if (mode === 'split') {
                if (officeContainer) officeContainer.style.display = 'none';
                if (btcContainer) {
                    btcContainer.style.display = 'flex';
                    btcContainer.style.flex = '1.1';
                    btcContainer.style.height = '52%';
                    btcContainer.style.borderBottom = '1px solid var(--panel-border)';
                }
                if (posContainer) {
                    posContainer.style.display = 'flex';
                    posContainer.style.flex = '1';
                    posContainer.style.height = '48%';
                }
                if (tfGroup) tfGroup.style.display = 'flex';
                renderTradingView();
            } else if (mode === 'office') {
                if (btcContainer) btcContainer.style.display = 'none';
                if (posContainer) posContainer.style.display = 'none';
                if (officeContainer) {
                    officeContainer.style.display = 'flex';
                    officeContainer.style.flex = '1';
                    officeContainer.style.height = '100%';
                }
                if (tfGroup) tfGroup.style.display = 'none';
                const leftPanel = document.getElementById('leftPanel');
                if (leftPanel) leftPanel.classList.add('office-view-active');
                try {
                    initOrResizeOffice3D();
                } catch (e) {
                    console.error("switchLeftView office error:", e);
                }
            }
            if (mode !== 'office') {
                const leftPanel = document.getElementById('leftPanel');
                if (leftPanel) leftPanel.classList.remove('office-view-active');
            }
        }

        function changeBtcTimeframe(tf) {
            currentBtcInterval = tf;
            localStorage.setItem('btcInterval', tf);
            ['15', '60', '240', 'D'].forEach(t => {
                const btn = document.getElementById('tf-' + t);
                if (btn) btn.classList.toggle('active', t === tf);
            });
            renderTradingView(true);
        }

        function renderTradingView(force = false) {
            const target = document.getElementById('tv_chart_target');
            if (!target) return;
            
            if (!force && lastRenderedInterval === currentBtcInterval && target.innerHTML.trim() !== '') {
                return;
            }

            ['15', '60', '240', 'D'].forEach(t => {
                const btn = document.getElementById('tf-' + t);
                if (btn) btn.classList.toggle('active', t === currentBtcInterval);
            });

            if (typeof TradingView !== 'undefined') {
                target.innerHTML = '';
                lastRenderedInterval = currentBtcInterval;
                try {
                    tvWidget = new TradingView.widget({
                        "autosize": true,
                        "symbol": "BINANCE:BTCUSDT.P",
                        "interval": currentBtcInterval,
                        "timezone": "Europe/Istanbul",
                        "theme": "dark",
                        "style": "1",
                        "locale": "tr",
                        "toolbar_bg": "#111622",
                        "enable_publishing": false,
                        "hide_top_toolbar": false,
                        "hide_legend": false,
                        "save_image": false,
                        "container_id": "tv_chart_target",
                        "studies": [
                            "MASimple@tv-basicstudies",
                            "RSI@tv-basicstudies"
                        ],
                        "allow_symbol_change": true,
                        "calendar": false,
                        "support_host": "https://www.tradingview.com"
                    });
                } catch(e) {
                    console.error("TradingView widget init error:", e);
                }
            } else {
                target.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#8492a6;font-size:12px;">📈 TradingView Canlı Mum Akışı Yükleniyor...</div>';
                setTimeout(() => renderTradingView(force), 500);
            }
        }

        function toggleBtcFullscreen() {
            const chartWrapper = document.getElementById('btcChartContainer');
            const exitBtn = document.getElementById('btnExitFs');
            if (!chartWrapper) return;
            const isFs = chartWrapper.classList.toggle('is-fullscreen');
            if (exitBtn) exitBtn.style.display = isFs ? 'block' : 'none';
            if (isFs) {
                chartWrapper.style.display = 'flex';
            } else {
                switchLeftView(currentLeftView);
            }
            setTimeout(() => renderTradingView(true), 150);
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const chartWrapper = document.getElementById('btcChartContainer');
                if (chartWrapper && chartWrapper.classList.contains('is-fullscreen')) {
                    toggleBtcFullscreen();
                }
            }
        });

        let activeRightTab = 'debate';
        function switchRightTab(tab) {
            activeRightTab = tab;
            const debateList = document.getElementById('debateList');
            const reflectList = document.getElementById('reflectionsList');
            const tuningList = document.getElementById('tuningList');
            const newsContainer = document.getElementById('newsContainer');

            const tabDebateBtn = document.getElementById('tabDebateBtn');
            const tabReflectBtn = document.getElementById('tabReflectBtn');
            const tabTuningBtn = document.getElementById('tabTuningBtn');
            const tabNewsBtn = document.getElementById('tabNewsBtn');
            const counter = document.getElementById('debateCounter');

            if (debateList) debateList.style.display = (tab === 'debate' ? 'flex' : 'none');
            if (reflectList) reflectList.style.display = (tab === 'reflections' ? 'flex' : 'none');
            if (tuningList) tuningList.style.display = (tab === 'tuning' ? 'flex' : 'none');
            if (newsContainer) newsContainer.style.display = (tab === 'news' ? 'flex' : 'none');

            if (tabDebateBtn) tabDebateBtn.classList.toggle('active', tab === 'debate');
            if (tabReflectBtn) tabReflectBtn.classList.toggle('active', tab === 'reflections');
            if (tabTuningBtn) tabTuningBtn.classList.toggle('active', tab === 'tuning');
            if (tabNewsBtn) tabNewsBtn.classList.toggle('active', tab === 'news');

            if (counter) {
                if (tab === 'debate') {
                    counter.innerText = 'Canlı Tartışma Odası';
                    counter.style.color = '#38bdf8';
                } else if (tab === 'reflections') {
                    counter.innerText = 'Tauric Episodik Hafıza';
                    counter.style.color = '#a855f7';
                } else if (tab === 'tuning') {
                    counter.innerText = 'Otonom Kalibrasyon';
                    counter.style.color = '#10b981';
                } else {
                    counter.innerText = 'Haber Konseyi & RSS';
                    counter.style.color = '#f59e0b';
                }
            }
        }

        let activeNewsSubTab = 'council';
        function switchNewsSubTab(subTab) {
            activeNewsSubTab = subTab;
            const councilList = document.getElementById('councilReportList');
            const rssList = document.getElementById('newsList');
            const btnCouncil = document.getElementById('btnSubCouncil');
            const btnRss = document.getElementById('btnSubRss');

            if (councilList) councilList.style.display = (subTab === 'council' ? 'flex' : 'none');
            if (rssList) rssList.style.display = (subTab === 'rss' ? 'flex' : 'none');

            if (btnCouncil) btnCouncil.classList.toggle('active', subTab === 'council');
            if (btnRss) btnRss.classList.toggle('active', subTab === 'rss');
        }

        async function triggerManualNewsInvestigation() {
            const inputEl = document.getElementById('coinNewsInput');
            const dirEl = document.getElementById('coinNewsDir');
            const spinner = document.getElementById('investigateSpinner');
            const btn = document.getElementById('btnInvestigateCoin');

            const symbol = (inputEl ? inputEl.value : '').trim().toUpperCase();
            const direction = dirEl ? dirEl.value : 'LONG';

            if (!symbol) {
                alert('Lütfen analiz edilecek coin sembolünü girin (örn: SOL, BTC, KAVA, PEPE).');
                return;
            }

            if (spinner) spinner.style.display = 'inline-block';
            if (btn) btn.disabled = true;

            try {
                const res = await fetch(`/api/news/investigate?symbol=${encodeURIComponent(symbol)}&direction=${encodeURIComponent(direction)}`);
                const data = await res.json();
                if (data && data.success && data.data) {
                    // Konsey alt sekmesine geç ve veriyi anında tazele
                    switchNewsSubTab('council');
                    fetchTerminal();
                } else {
                    alert('Haber konseyi sorgulama hatası: ' + (data ? data.error : 'Bilinmeyen hata'));
                }
            } catch (err) {
                console.error('Haber konseyi API hatası:', err);
                alert('Bağlantı hatası: ' + err.message);
            } finally {
                if (spinner) spinner.style.display = 'none';
                if (btn) btn.disabled = false;
            }
        }

        async function fetchTerminal() {
            try {
                const res = await fetch('/api/data');
                if (!res.ok) {
                    console.warn('/api/data HTTP status:', res.status);
                    return;
                }
                const data = await res.json();
                if (!data || data.error || !Array.isArray(data.active_positions)) {
                    console.warn('Geçersiz veri paketi:', data);
                    return;
                }
                renderAll(data);
            } catch (err) {
                console.error("fetchTerminal exception:", err);
            }
        }

        function fmtP(val) {
            const num = Number(val);
            if (isNaN(num)) return '0';
            if (num >= 100) return num.toFixed(2);
            if (num >= 1) return num.toFixed(4);
            return num.toPrecision(5);
        }

        // 🇹🇷 Türkiye Saati (TSİ / UTC+3) Formatlayıcı
        // Sunucudaki UTC saat ve tarih damgalarına +3 saat ekleyerek Türkiye saatine uyarlar
        function formatTurkeyTime(timeStr) {
            if (!timeStr) return '';
            try {
                const s = String(timeStr).trim();
                // 1. Tam Tarih-Saat (YYYY-MM-DD HH:MM:SS veya YYYY-MM-DD HH:MM)
                const matchDt = s.match(/^(\\d{4}-\\d{2}-\\d{2})[ T](\\d{1,2}):(\\d{2})(?::(\\d{2}))?/);
                if (matchDt) {
                    const [y, m, d] = matchDt[1].split('-').map(Number);
                    const hh = Number(matchDt[2]);
                    const mm = Number(matchDt[3]);
                    const ss = matchDt[4] ? Number(matchDt[4]) : 0;
                    const utc = new Date(Date.UTC(y, m - 1, d, hh + 3, mm, ss));
                    const ry = utc.getUTCFullYear();
                    const rm = String(utc.getUTCMonth() + 1).padStart(2, '0');
                    const rd = String(utc.getUTCDate()).padStart(2, '0');
                    const rh = String(utc.getUTCHours()).padStart(2, '0');
                    const rmin = String(utc.getUTCMinutes()).padStart(2, '0');
                    const rsec = String(utc.getUTCSeconds()).padStart(2, '0');
                    return `${ry}-${rm}-${rd} ${rh}:${rmin}:${rsec}`;
                }
                // 2. Yalnızca Saat (HH:MM:SS veya HH:MM)
                const matchTime = s.match(/^(\\d{1,2}):(\\d{2})(?::(\\d{2}))?$/);
                if (matchTime) {
                    const hh = Number(matchTime[1]);
                    const mm = matchTime[2];
                    const ss = matchTime[3];
                    const newH = String((hh + 3) % 24).padStart(2, '0');
                    if (ss !== undefined) {
                        return `${newH}:${mm}:${ss}`;
                    }
                    return `${newH}:${mm}`;
                }
            } catch (e) {
                console.warn('formatTurkeyTime error:', e);
            }
            return timeStr;
        }

        function updateTurkeyClock() {
            try {
                const now = new Date();
                const trDate = new Date(now.getTime() + (3 * 3600 * 1000));
                const h = String(trDate.getUTCHours()).padStart(2, '0');
                const m = String(trDate.getUTCMinutes()).padStart(2, '0');
                const s = String(trDate.getUTCSeconds()).padStart(2, '0');
                const clockEl = document.getElementById('topTrClock');
                if (clockEl) {
                    clockEl.innerText = `🇹🇷 TSİ ${h}:${m}:${s}`;
                }
            } catch (e) {}
        }
        setInterval(updateTurkeyClock, 1000);
        setTimeout(updateTurkeyClock, 50);

        // SVG Mini Çizgi Grafiği Renderer (Line Chart with Area Gradient & Exact Green TP / Red SL Lines)
        function renderMiniLineChart(candles, entry, live, sl, tp, isLong, symbol) {
            const width = 360;
            const height = 115;
            const pad = 14;

            // Fiyat noktalarını hazırla (kullanıcı her pozisyonda akıcı çizgi grafik görsün)
            let prices = [];
            if (candles && candles.length >= 3) {
                prices = candles.map(c => Number(c.close));
            } else {
                const steps = 12;
                const diff = (live - entry) / steps;
                for (let i = 0; i < steps; i++) {
                    const base = entry + (diff * i);
                    const noise = (i % 2 === 0 ? 1 : -1) * (base * 0.001);
                    prices.push(base + noise);
                }
            }
            // En son noktayı anlık canlı fiyata bağla
            prices.push(live);

            const n = prices.length;

            // Fiyat sınırlarını belirle ve taşmayı önlemek için %10 tampon ekle
            let minP = Math.min(sl, tp, ...prices, live, entry);
            let maxP = Math.max(sl, tp, ...prices, live, entry);
            const rawRange = (maxP - minP) || 1;
            const padVal = rawRange * 0.10;
            minP -= padVal;
            maxP += padVal;
            const range = maxP - minP;

            const scaleY = p => Math.max(pad, Math.min(height - pad, height - pad - (((p - minP) / range) * (height - (pad * 2)))));

            const ySl = scaleY(sl);
            const yTp = scaleY(tp);
            const yEntry = scaleY(entry);
            const yLive = scaleY(live);

            const stepX = (width - 70) / (n - 1);
            const startX = 25;

            // Çizgi noktalarını ve alan doldurma yolunu oluştur
            let pathD = '';
            let areaD = '';
            const points = [];

            prices.forEach((p, i) => {
                const x = startX + (i * stepX);
                const y = scaleY(p);
                points.push({ x, y });
                if (i === 0) {
                    pathD += `M ${x.toFixed(1)} ${y.toFixed(1)}`;
                    areaD += `M ${x.toFixed(1)} ${y.toFixed(1)}`;
                } else {
                    pathD += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
                    areaD += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
                }
            });

            const lastPt = points[points.length - 1];
            const bottomY = height - pad;
            areaD += ` L ${lastPt.x.toFixed(1)} ${bottomY} L ${points[0].x.toFixed(1)} ${bottomY} Z`;

            // Çizgi rengi: Long ise gök mavisi, Short ise parlak turuncu
            const lineColor = isLong ? '#38bdf8' : '#fb923c';
            const gradId = `grad_${symbol}_${Math.floor(Math.random() * 10000)}`;

            return `
                <svg class="chart-svg" viewBox="0 0 ${width} ${height}">
                    <defs>
                        <linearGradient id="${gradId}" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="${lineColor}" stop-opacity="0.32"/>
                            <stop offset="100%" stop-color="${lineColor}" stop-opacity="0.02"/>
                        </linearGradient>
                    </defs>

                    <!-- Background Grid -->
                    <line x1="0" y1="${height/2}" x2="${width}" y2="${height/2}" stroke="#1f2738" stroke-dasharray="3,3" />

                    <!-- 🟢 Yeşil Take Profit (Hedef) Çizgisi -->
                    <line x1="0" y1="${yTp}" x2="${width}" y2="${yTp}" stroke="#10b981" stroke-width="1.5" stroke-dasharray="4,3" />
                    <text x="${width - 5}" y="${yTp > 15 ? yTp - 3 : yTp + 10}" fill="#10b981" font-size="9" font-family="JetBrains Mono" font-weight="700" text-anchor="end">🎯 TP: $${fmtP(tp)}</text>

                    <!-- 🔴 Kırmızı Stop Loss (Zarar Kes) Çizgisi -->
                    <line x1="0" y1="${ySl}" x2="${width}" y2="${ySl}" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4,3" />
                    <text x="${width - 5}" y="${ySl > 15 ? ySl - 3 : ySl + 10}" fill="#ef4444" font-size="9" font-family="JetBrains Mono" font-weight="700" text-anchor="end">🛑 SL: $${fmtP(sl)}</text>

                    <!-- ⚪ Beyaz Giriş Çizgisi -->
                    <line x1="0" y1="${yEntry}" x2="${width}" y2="${yEntry}" stroke="#94a3b8" stroke-width="1" stroke-dasharray="2,2" />
                    <text x="5" y="${yEntry > 15 ? yEntry - 3 : yEntry + 10}" fill="#94a3b8" font-size="9" font-family="JetBrains Mono">💰 Giriş: $${fmtP(entry)}</text>

                    <!-- Alan Doldurma Gradient -->
                    <path d="${areaD}" fill="url(#${gradId})" />

                    <!-- 📈 Ana Fiyat Çizgisi (Smooth Line Chart) -->
                    <path d="${pathD}" fill="none" stroke="${lineColor}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" />

                    <!-- 🔵 Canlı Fiyat İşaretçisi (Mavi Parlayan Pin) -->
                    <line x1="0" y1="${yLive}" x2="${lastPt.x}" y2="${yLive}" stroke="${lineColor}" stroke-width="1" stroke-dasharray="2,2" opacity="0.3" />
                    <circle cx="${lastPt.x}" cy="${lastPt.y}" r="4" fill="${lineColor}" />
                    <circle cx="${lastPt.x}" cy="${lastPt.y}" r="8" fill="none" stroke="${lineColor}" opacity="0.5">
                        <animate attributeName="r" values="5;10;5" dur="1.8s" repeatCount="indefinite"/>
                        <animate attributeName="opacity" values="0.6;0.1;0.6" dur="1.8s" repeatCount="indefinite"/>
                    </circle>
                    <text x="${width - 10}" y="${lastPt.y + 3}" fill="${lineColor}" font-size="10" font-family="JetBrains Mono" font-weight="700" text-anchor="end">📍 $${fmtP(live)}</text>
                </svg>
            `;
        }

        function renderAll(data) {
            if (!data) return;
            window.lastTerminalData = data;

            const isSuperFast = (typeof currentBotMode !== 'undefined' && currentBotMode === 'superfast');
            const isFast = (typeof currentBotMode !== 'undefined' && currentBotMode === 'fast');
            const stats = isSuperFast ? (data.super_fast_stats || {}) : (isFast ? (data.fast_stats || {}) : (data.stats || {}));
            const activeList = isSuperFast ? (data.super_fast_active_positions || []) : (isFast ? (data.fast_active_positions || []) : (data.active_positions || []));
            const historyList = isSuperFast ? (data.super_fast_trade_history || []) : (isFast ? (data.fast_trade_history || []) : (data.trade_history || []));
            const logsList = isSuperFast ? (data.super_fast_scanner_logs || []) : (isFast ? (data.fast_scanner_logs || []) : (data.scanner_logs || []));
            const unPnlVal = isSuperFast ? (data.super_fast_total_unrealized_pnl !== undefined ? data.super_fast_total_unrealized_pnl : 0.0) : (isFast ? (data.fast_total_unrealized_pnl !== undefined ? data.fast_total_unrealized_pnl : 0.0) : (data.total_unrealized_pnl !== undefined ? data.total_unrealized_pnl : 0.0));
            const unDollarVal = isSuperFast ? (data.super_fast_total_unrealized_dollar !== undefined ? data.super_fast_total_unrealized_dollar : 0.0) : (isFast ? (data.fast_total_unrealized_dollar !== undefined ? data.fast_total_unrealized_dollar : 0.0) : (data.total_unrealized_dollar !== undefined ? data.total_unrealized_dollar : 0.0));
            const maxTrades = isSuperFast ? (data.super_fast_max_concurrent_trades || 20) : (isFast ? (data.fast_max_concurrent_trades || 10) : (data.max_concurrent_trades || 5));

            // 1. Topbar
            const wsBadge = document.getElementById('wsBadge');
            if (wsBadge) {
                if (data.ws_connected) {
                    wsBadge.innerText = '⚡ WSS CANLI';
                    wsBadge.style.color = '#38bdf8';
                    wsBadge.style.background = 'rgba(56,189,248,0.15)';
                } else {
                    wsBadge.innerText = '● WSS HAZIR';
                    wsBadge.style.color = '#8492a6';
                    wsBadge.style.background = 'rgba(132,146,166,0.15)';
                }
            }

            const btc = data.btc_regime || {};
            if (btc.status) {
                const btcEl = document.getElementById('topBtc');
                const btcTxt = btc.status + ' ($' + (btc.btc_price ? Number(btc.btc_price).toLocaleString() : '0') + ')';
                if (btcEl && btcEl.innerText !== btcTxt) btcEl.innerText = btcTxt;
                if (btcEl) btcEl.style.color = btc.status === 'BULLISH' ? 'var(--green)' : (btc.status === 'DUMP_ALERT' ? 'var(--red)' : 'var(--yellow)');
            }

            const unPnlEl = document.getElementById('topUnrealized');
            if (unPnlEl) {
                const unPnl = Number(unPnlVal).toFixed(1);
                const unDol = Number(unDollarVal);
                const unDolSign = unDol >= 0 ? '+$' : '-$';
                const unTxt = `${unDolSign}${Math.abs(unDol).toFixed(2)} (${unPnl >= 0 ? '+' : ''}${unPnl}%)`;
                if (unPnlEl.innerText !== unTxt) {
                    unPnlEl.innerText = unTxt;
                    unPnlEl.className = 'val ' + (unDol >= 0 ? 'pnl-pos' : 'pnl-neg');
                }
            }

            // Kasa Kalkanı Kotası
            const shieldEl = document.getElementById('topShieldQuota');
            const currentTrades = activeList.length;
            if (shieldEl) {
                shieldEl.innerText = `${currentTrades}/${maxTrades} Slot`;
                shieldEl.style.color = currentTrades >= maxTrades ? 'var(--red)' : (currentTrades >= 2 ? 'var(--yellow)' : 'var(--green)');
            }

            // Vade Kotaları & Toplam Günlük Kota (15m • 30m • 1h ve Toplam Tavan)
            const tlQuotaEl = document.getElementById('topTimelineQuota');
            if (tlQuotaEl && data.timeline_quotas) {
                const tq = data.timeline_quotas;
                const q15 = tq['15m'] || { used: 0, max: 5 };
                const q30 = tq['30m'] || { used: 0, max: 4 };
                const q1h = tq['1h'] || { used: 0, max: 3 };
                const qTot = tq['total'] || { used: (q15.used + q30.used + q1h.used), max: 12 };

                const is15Full = q15.used >= q15.max;
                const is30Full = q30.used >= q30.max;
                const is1hFull = q1h.used >= q1h.max;
                const isTotFull = qTot.used >= qTot.max;

                const c15 = is15Full ? 'color: #ef4444; font-weight:800;' : 'color: #38bdf8;';
                const c30 = is30Full ? 'color: #ef4444; font-weight:800;' : 'color: #c084fc;';
                const c1h = is1hFull ? 'color: #ef4444; font-weight:800;' : 'color: #fbbf24;';
                const cTot = isTotFull ? 'color: #ef4444; font-weight:800;' : 'color: #38bdf8; font-weight:800;';

                tlQuotaEl.innerHTML = `<span style="${cTot}">${qTot.used}/${qTot.max} Toplam</span> <span style="color: var(--text-muted); font-size: 10px; margin-left: 3px;">(<span style="${c15}">⚡${q15.used}/${q15.max}</span> • <span style="${c30}">🎯${q30.used}/${q30.max}</span> • <span style="${c1h}">👑${q1h.used}/${q1h.max}</span>)</span>`;
            }

            const barQuotaEl = document.getElementById('barDailyQuota');
            const barQuotaDetails = document.getElementById('barDailyQuotaDetails');
            if (barQuotaEl && data.timeline_quotas) {
                const tq = data.timeline_quotas;
                const q15 = tq['15m'] || { used: 0, max: 5 };
                const q30 = tq['30m'] || { used: 0, max: 4 };
                const q1h = tq['1h'] || { used: 0, max: 3 };
                const qTot = tq['total'] || { used: (q15.used + q30.used + q1h.used), max: 12 };
                barQuotaEl.innerText = `${qTot.used}/${qTot.max} İşlem`;
                barQuotaEl.style.color = (qTot.used >= qTot.max) ? 'var(--red)' : '#38bdf8';
                if (barQuotaDetails) {
                    barQuotaDetails.innerHTML = `(⚡${q15.used}/${q15.max} • 🎯${q30.used}/${q30.max} • 👑${q1h.used}/${q1h.max})`;
                }
            }

            // Fon Kasası ($)
            const equityEl = document.getElementById('topEquity');
            if (equityEl && stats.portfolio_balance !== undefined) {
                equityEl.innerText = '$' + Number(stats.portfolio_balance).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            }

            // Net Kasa Kârı ($ ve %)
            if (stats.net_dollar_gain !== undefined) {
                const dollarVal = Number(stats.net_dollar_gain);
                const dollarSign = dollarVal >= 0 ? '+$' : '-$';
                const totPnl = stats.total_pnl_pct !== undefined ? Number(stats.total_pnl_pct).toFixed(1) : '0';
                const realEl = document.getElementById('topRealized');
                const totTxt = `${dollarSign}${Math.abs(dollarVal).toFixed(2)} (${totPnl >= 0 ? '+' : ''}${totPnl}%)`;
                if (realEl && realEl.innerText !== totTxt) realEl.innerText = totTxt;
                if (realEl) realEl.style.color = dollarVal >= 0 ? 'var(--green)' : 'var(--red)';
            }

            // Bugünkü Net PnL ($ ve %) (TRT 23:59 Sıfırlanan)
            const todayPnlEl = document.getElementById('topTodayPnl');
            if (todayPnlEl && stats.today_dollar_gain !== undefined) {
                const tDollar = Number(stats.today_dollar_gain);
                const tPct = Number(stats.today_net_pnl_pct || 0);
                const tSign = tDollar >= 0 ? '+$' : '-$';
                const tTxt = `${tSign}${Math.abs(tDollar).toFixed(2)} (${tPct >= 0 ? '+' : ''}${tPct.toFixed(1)}%)`;
                if (todayPnlEl.innerText !== tTxt) todayPnlEl.innerText = tTxt;
                todayPnlEl.style.color = tDollar >= 0 ? 'var(--green)' : 'var(--red)';
            }

            // Ödenen Toplam Komisyon
            const feesEl = document.getElementById('topFees');
            if (feesEl) {
                const fees = Number(stats.total_fee_pct || 0).toFixed(1);
                feesEl.innerText = '-%' + fees;
            }

            // Win Rate
            const winEl = document.getElementById('topWinRate');
            if (winEl) {
                winEl.innerText = '%' + Number(stats.win_rate || 0).toFixed(1);
            }

            // Kâr Faktörü
            const pfEl = document.getElementById('topProfitFactor');
            if (pfEl) {
                pfEl.innerText = Number(stats.profit_factor || 0).toFixed(2);
            }

            // 2. Sol Sütun: İki Kısımlı Aktif Kartlar & Çizgi Grafiği (Kârdakiler vs Zarardakiler)
            if (Array.isArray(activeList)) {
                const totalCount = activeList.length;
                const activeCountEl = document.getElementById('activeCount');
                if (activeCountEl) activeCountEl.innerText = totalCount + ' İşlem';
                const activeBtnEl = document.getElementById('activeCountBtn');
                if (activeBtnEl) activeBtnEl.innerText = totalCount;
                const totalEl = document.getElementById('totalActiveCount');
                if (totalEl) totalEl.innerText = totalCount;

                const profitListEl = document.getElementById('profitList');
                const lossListEl = document.getElementById('lossList');

                if (totalCount === 0) {
                    const emptyMsg = '<div style="text-align: center; color: var(--text-muted); padding: 30px 10px; font-size: 11px;">Aktif scalp pozisyonu aranıyor...</div>';
                    if (profitListEl) profitListEl.innerHTML = emptyMsg;
                    if (lossListEl) lossListEl.innerHTML = emptyMsg;
                    prevProfitHtml = '';
                    prevLossHtml = '';
                    const grEl = document.getElementById('greenActiveCount');
                    const rdEl = document.getElementById('redActiveCount');
                    const pColEl = document.getElementById('profitColCount');
                    const lColEl = document.getElementById('lossColCount');
                    if (grEl) grEl.innerText = '0';
                    if (rdEl) rdEl.innerText = '0';
                    if (pColEl) pColEl.innerText = '0';
                    if (lColEl) lColEl.innerText = '0';
                    const totDolEl = document.getElementById('totalActiveDollar');
                    const grDolEl = document.getElementById('greenActiveDollar');
                    const rdDolEl = document.getElementById('redActiveDollar');
                    const pColDolEl = document.getElementById('profitColTotalDollar');
                    const lColDolEl = document.getElementById('lossColTotalDollar');
                    if (totDolEl) totDolEl.innerText = '$0.00';
                    if (grDolEl) grDolEl.innerText = '+$0.00';
                    if (rdDolEl) rdDolEl.innerText = '-$0.00';
                    if (pColDolEl) pColDolEl.innerText = '+$0.00';
                    if (lColDolEl) lColDolEl.innerText = '-$0.00';
                } else {
                    // Pozisyonların net ve brüt PnL ve mesafe hesaplamaları
                    const processed = activeList.map(pos => {
                        const isLong = pos.direction === 'LONG';
                        const entry = Number(pos.actual_entry_price || pos.entry_min);
                        const live = Number(pos.live_price || entry);
                        const sl = Number(pos.stop_loss);
                        const tp = Number(pos.take_profit_1 || pos.take_profit_2);
                        const lev = Number(pos.leverage || 10);

                        const rawDiff = isLong ? (live - entry) / entry : (entry - live) / entry;
                        const grossPnlPct = rawDiff * lev * 100;
                        const feePct = (pos.fee_pct !== undefined && pos.fee_pct !== 0.0) ? Number(pos.fee_pct) : (0.10 * lev);
                        const netPnlPct = grossPnlPct - feePct;
                        const isProfit = netPnlPct >= 0;

                        const posMargin = Number(pos.allocated_margin_usdt || 200.0);
                        const posDollarGain = (pos.unrealized_pnl_dollar !== undefined) ? Number(pos.unrealized_pnl_dollar) : (posMargin * (netPnlPct / 100.0));

                        const distTp = isLong ? ((tp - live) / live) * 100 : ((live - tp) / live) * 100;
                        const distSl = isLong ? ((live - sl) / live) * 100 : ((sl - live) / live) * 100;

                        return {
                            ...pos,
                            isLong, entry, live, sl, tp, lev,
                            grossPnlPct, feePct, netPnlPct, isProfit, distTp, distSl,
                            posMargin, posDollarGain
                        };
                    });

                    // 1. KÂRDAKİ POZİSYONLAR: En yüksek net kârdan en aza doğru sıralı
                    const profitPositions = processed
                        .filter(p => p.isProfit)
                        .sort((a, b) => b.netPnlPct - a.netPnlPct);

                    // 2. ZARARDAKİ POZİSYONLAR: En çok net zarardan en aza doğru sıralı
                    const lossPositions = processed
                        .filter(p => !p.isProfit)
                        .sort((a, b) => a.netPnlPct - b.netPnlPct);

                    let sumProfitDollar = 0.0;
                    profitPositions.forEach(p => { sumProfitDollar += p.posDollarGain; });

                    let sumLossDollar = 0.0;
                    lossPositions.forEach(p => { sumLossDollar += p.posDollarGain; });

                    const sumTotalDollar = sumProfitDollar + sumLossDollar;

                    const grEl = document.getElementById('greenActiveCount');
                    const rdEl = document.getElementById('redActiveCount');
                    const pColEl = document.getElementById('profitColCount');
                    const lColEl = document.getElementById('lossColCount');
                    if (grEl) grEl.innerText = profitPositions.length;
                    if (rdEl) rdEl.innerText = lossPositions.length;
                    if (pColEl) pColEl.innerText = profitPositions.length;
                    if (lColEl) lColEl.innerText = lossPositions.length;

                    const totDolEl = document.getElementById('totalActiveDollar');
                    const grDolEl = document.getElementById('greenActiveDollar');
                    const rdDolEl = document.getElementById('redActiveDollar');
                    const pColDolEl = document.getElementById('profitColTotalDollar');
                    const lColDolEl = document.getElementById('lossColTotalDollar');

                    if (totDolEl) totDolEl.innerText = (sumTotalDollar >= 0 ? '+$' : '-$') + Math.abs(sumTotalDollar).toFixed(2);
                    if (grDolEl) grDolEl.innerText = '+$' + Math.abs(sumProfitDollar).toFixed(2);
                    if (rdDolEl) rdDolEl.innerText = '-$' + Math.abs(sumLossDollar).toFixed(2);
                    if (pColDolEl) pColDolEl.innerText = '+$' + Math.abs(sumProfitDollar).toFixed(2);
                    if (lColDolEl) lColDolEl.innerText = '-$' + Math.abs(sumLossDollar).toFixed(2);

                    function renderCardHtml(pos) {
                        const lineSvg = renderMiniLineChart(pos.recent_candles || [], pos.entry, pos.live, pos.sl, pos.tp, pos.isLong, pos.symbol);
                        const elapsed = pos.elapsed_str || '1 dk';

                        let protectionBadge = '';
                        if (pos.status === 'ACTIVE_PARTIAL_TP1') {
                            protectionBadge = '<span class="tag" style="background:rgba(160,185,129,0.25); color:#10b981; font-weight:800; border:1px solid #10b981;">🎯 %50 TP1 KİLİTLİ (FREE-TRADE)</span>';
                        } else if (pos.ladder_name) {
                            protectionBadge = `<span class="tag" style="background:rgba(245,158,11,0.22); color:#f59e0b; font-weight:700;">${pos.ladder_name}</span>`;
                        } else if (pos.ladder_step > 0) {
                            protectionBadge = `<span class="tag" style="background:rgba(245,158,11,0.22); color:#f59e0b; font-weight:700;">🪜 Basamak ${pos.ladder_step}</span>`;
                        } else if (pos.status === 'ACTIVE_BE') {
                            protectionBadge = '<span class="tag" style="background:rgba(56,189,248,0.2); color:#38bdf8; font-weight:700;">🛡️ BE+</span>';
                        } else if (pos.trailing_stop && Number(pos.trailing_stop) > 0) {
                            protectionBadge = '<span class="tag" style="background:rgba(245,158,11,0.2); color:#f59e0b; font-weight:700;">⚡ Dinamik Kanal</span>';
                        }

                        let horizonBadge = '<span class="tag" style="background:rgba(56,189,248,0.25); color:#38bdf8; border:1px solid #38bdf8; font-weight:800;">⚡ Kısa (15m)</span>';
                        const tf = pos.timeframe || (pos.trade_horizon && pos.trade_horizon.includes('1h') ? '1h' : (pos.trade_horizon && pos.trade_horizon.includes('30m') ? '30m' : '15m'));
                        if (tf === '1h' || (pos.trade_horizon && pos.trade_horizon.includes('Uzun'))) {
                            horizonBadge = '<span class="tag" style="background:rgba(245,158,11,0.25); color:#fbbf24; border:1px solid #f59e0b; font-weight:800;">👑 Uzun (1h)</span>';
                        } else if (tf === '30m' || (pos.trade_horizon && pos.trade_horizon.includes('Orta'))) {
                            horizonBadge = '<span class="tag" style="background:rgba(168,85,247,0.25); color:#c084fc; border:1px solid #a855f7; font-weight:800;">🎯 Orta (30m)</span>';
                        }

                        return `
                            <div class="pos-card" id="card-${pos.symbol}">
                                <div class="card-header">
                                    <div class="card-title">
                                        <span>${pos.symbol}</span>
                                        <span class="tag ${pos.isLong ? 'tag-long' : 'tag-short'}">${pos.direction}</span>
                                        <span class="tag tag-lev">${pos.lev}x</span>
                                        ${horizonBadge}
                                        ${protectionBadge}
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <span class="card-elapsed" title="Pozisyon Açılış Zamanı (TSİ): ${formatTurkeyTime(pos.entered_at || pos.created_at)}">⏱️ ${elapsed}</span>
                                        <div style="text-align: right;">
                                            <div class="card-pnl ${pos.isProfit ? 'pnl-pos' : 'pnl-neg'}">
                                                ${pos.isProfit ? '+' : ''}${pos.netPnlPct.toFixed(2)}% Net (${pos.posDollarGain >= 0 ? '+$' : '-$'}${Math.abs(pos.posDollarGain).toFixed(2)})
                                            </div>
                                            <div style="font-size: 8.5px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace;">
                                                Brüt: ${(pos.grossPnlPct >= 0 ? '+' : '') + pos.grossPnlPct.toFixed(2)}% | Kom: -${pos.feePct.toFixed(2)}%
                                            </div>
                                        </div>
                                        <button class="btn-manual-close" onclick="closeSinglePosition('${pos.symbol}', ${pos.id || 0})" title="${pos.symbol} pozisyonunu anlık market fiyatından kapat">
                                            ⚡ Kapat
                                        </button>
                                    </div>
                                </div>

                                <!-- Canlı Fiyat Çizgi Grafiği -->
                                <div class="mini-chart-box">
                                    ${lineSvg}
                                </div>

                                <!-- Mesafe ve Kasa Marjin Bilgileri -->
                                <div class="proximity-row">
                                    <span class="prox-sl">🛑 SL: %${pos.distSl.toFixed(2)}</span>
                                    <span style="color: var(--text-muted); font-size: 10px; font-family: 'JetBrains Mono';">💵 Marjin: $${pos.posMargin.toFixed(0)}</span>
                                    <span class="prox-tp">🎯 TP: %${pos.distTp.toFixed(2)}</span>
                                </div>
                            </div>
                        `;
                    }

                    // Sol Sütun (KÂR): En yüksek kârdan en aza doğru
                    let profitHtml = '';
                    if (profitPositions.length === 0) {
                        profitHtml = '<div style="color: var(--text-muted); font-size: 11px; padding: 25px 10px; text-align: center;">Şu an kârda pozisyon yok.</div>';
                    } else {
                        profitPositions.forEach(p => { profitHtml += renderCardHtml(p); });
                    }
                    if (profitListEl && profitHtml !== prevProfitHtml) {
                        profitListEl.innerHTML = profitHtml;
                        prevProfitHtml = profitHtml;
                    }

                    // Sağ Sütun (ZARAR): En çok zarardan en aza doğru
                    let lossHtml = '';
                    if (lossPositions.length === 0) {
                        lossHtml = '<div style="color: var(--green); font-size: 11px; padding: 25px 10px; text-align: center; font-weight: 600;">✨ Harika! Zararda pozisyon yok.</div>';
                    } else {
                        lossPositions.forEach(p => { lossHtml += renderCardHtml(p); });
                    }
                    if (lossListEl && lossHtml !== prevLossHtml) {
                        lossListEl.innerHTML = lossHtml;
                        prevLossHtml = lossHtml;
                    }
                }
            }

            // 3. Sağ Üst: 📡 Tarama Günlüğü (Standart / FAST)
            const logs = logsList;
            if (Array.isArray(logs) && logs.length > 0) {
                const logList = document.getElementById('logList');
                let logHtml = '';
                logs.forEach(l => {
                    const isAppr = l.status === 'APPROVED';
                    const isProt = l.status === 'PROTECTED';
                    let statusClass = isAppr ? 'approved' : (isProt ? 'protected' : 'rejected');
                    let statusBadge = isAppr ? '<span class="badge-appr">✅ FIRSAT BULUNDU</span>' : (isProt ? '<span class="badge-prot">🛡️ SERMAYE KORUMASI</span>' : '<span class="badge-rej">❌ ELENDİ</span>');

                    let reasonTxt = l.reason || '';
                    if (reasonTxt.indexOf('[Son 1 Saatte') !== -1) {
                        const parts = reasonTxt.split('[Son 1 Saatte');
                        const prefix = parts[0];
                        const testPart = parts[1].replace(']', '').trim();
                        reasonTxt = prefix + '<br><span style="color:#38bdf8; font-weight:600; background:rgba(56,189,248,0.12); padding:1px 6px; border-radius:3px; display:inline-block; margin-top:4px;">⏱️ Bu Saatte ' + testPart + '</span>';
                    }
                    logHtml += `
                        <div class="log-item ${statusClass}">
                            <div class="log-top">
                                <span class="log-sym">${l.symbol}</span>
                                ${statusBadge}
                                <span class="log-time">${formatTurkeyTime(l.time)}</span>
                            </div>
                            <div class="log-reason">${reasonTxt} ${l.details ? `<br><span style="font-size:10px; color:#38bdf8; opacity:0.85; font-style:italic;">💡 Mod: ${l.details}</span>` : ''}</div>
                        </div>
                    `;
                });
                if (logHtml !== prevLogsHtml) {
                    logList.innerHTML = logHtml;
                    prevLogsHtml = logHtml;
                }
            }

            // 3.5 Sağ Alt: 🏛️ Ajanlar Yatırım Komitesi Tartışma Odası
            const debates = data.committee_debates;
            const debateList = document.getElementById('debateList');
            if (debateList) {
                if (!Array.isArray(debates) || debates.length === 0) {
                    const emptyMsg = '<div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">🏛️ Ajanlar parite taramasında tartışmak üzere hazır bekliyor...</div>';
                    if (prevDebatesHtml !== emptyMsg) {
                        debateList.innerHTML = emptyMsg;
                        prevDebatesHtml = emptyMsg;
                    }
                } else {
                    let dHtml = '';
                    debates.forEach(d => {
                        const isAppr = d.consensus_verdict === 'APPROVED';
                        const score = Number(d.consensus_score || 0).toFixed(1);
                        const dataObj = d.debate_data || {};
                        const dialogue = dataObj.debate_dialogue || [];

                        let bubblesHtml = '';
                        dialogue.forEach(b => {
                            let roleClass = 'bubble-bull';
                            let roleColor = '#22c55e';
                            if (b.role === 'BEAR') { roleClass = 'bubble-bear'; roleColor = '#ef4444'; }
                            else if (b.role === 'MACRO') { roleClass = 'bubble-macro'; roleColor = '#38bdf8'; }
                            else if (b.role === 'CHIEF') { roleClass = 'bubble-chief'; roleColor = '#f59e0b'; }
                            else if (b.role === 'QUANT') { roleClass = 'bubble-quant'; roleColor = '#818cf8'; }

                            let metricsHtml = '';
                            if (b.metrics) {
                                const isWin = b.metrics.vote === 'APPROVED';
                                metricsHtml = `
                                    <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; font-size: 10px; font-family: monospace;">
                                        <span style="background: rgba(99,102,241,0.18); border: 1px solid rgba(99,102,241,0.35); padding: 2px 6px; border-radius: 4px; color: #a5b4fc;">🎲 ${b.metrics.simulations || 10000} Yol</span>
                                        <span style="background: rgba(34,197,94,0.18); border: 1px solid rgba(34,197,94,0.35); padding: 2px 6px; border-radius: 4px; color: #4ade80;">TP İhtimali: %${b.metrics.win_rate}</span>
                                        <span style="background: rgba(239,68,68,0.18); border: 1px solid rgba(239,68,68,0.35); padding: 2px 6px; border-radius: 4px; color: #f87171;">SL Riski: %${b.metrics.loss_rate}</span>
                                        <span style="background: rgba(56,189,248,0.18); border: 1px solid rgba(56,189,248,0.35); padding: 2px 6px; border-radius: 4px; color: #38bdf8;">Beklenti: +${b.metrics.expectancy_r}R</span>
                                        <span style="background: ${isWin ? 'rgba(34,197,94,0.25)' : 'rgba(239,68,68,0.25)'}; border: 1px solid ${isWin ? '#22c55e' : '#ef4444'}; padding: 2px 6px; border-radius: 4px; color: #fff; font-weight: 700;">${isWin ? '🟢 ONAYLANDI' : '🔴 VETO'}</span>
                                    </div>
                                `;
                            }

                            bubblesHtml += `
                                <div class="dialogue-bubble ${roleClass}">
                                    <div class="speaker-title" style="color: ${roleColor};">
                                        <span>${b.avatar || '💬'}</span>
                                        <span>${b.agent_name || b.role}</span>
                                    </div>
                                    <div>${b.argument || ''}</div>
                                    ${metricsHtml}
                                </div>
                            `;
                        });

                        dHtml += `
                            <div class="debate-card">
                                <div class="debate-header">
                                    <div class="debate-sym">
                                        <span>${d.symbol}</span>
                                        <span class="tag ${d.direction === 'LONG' ? 'tag-long' : 'tag-short'}">${d.direction}</span>
                                        <span style="font-size: 9.5px; color: var(--text-muted); font-family: 'JetBrains Mono';">${formatTurkeyTime(d.time_str)}</span>
                                    </div>
                                    <span class="debate-score ${isAppr ? 'debate-score-approved' : 'debate-score-rejected'}">
                                        ${isAppr ? '✅ ONAYLANDI' : '🚫 VETO EDİLDİ'} (${score}/10)
                                    </span>
                                </div>
                                <div style="display: flex; flex-direction: column; gap: 6px;">
                                    ${bubblesHtml}
                                </div>
                            </div>
                        `;
                    });

                    if (dHtml !== prevDebatesHtml) {
                        debateList.innerHTML = dHtml;
                        prevDebatesHtml = dHtml;
                    }
                }
            }

            // 3.6 Sağ Alt: 🧠 AI Hafıza & Çıkarılan Dersler (Tauric Reflections)
            const reflections = data.trade_reflections;
            const reflectList = document.getElementById('reflectionsList');
            if (reflectList && Array.isArray(reflections)) {
                if (reflections.length === 0) {
                    const emptyMsg = '<div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">🧠 Henüz kayıtlı geçmiş işlem dersi yok. Kapanan her işlemde sistem buraya somut dersler kaydeder.</div>';
                    if (prevReflectHtml !== emptyMsg) {
                        reflectList.innerHTML = emptyMsg;
                        prevReflectHtml = emptyMsg;
                    }
                } else {
                    let rHtml = '';
                    reflections.forEach(r => {
                        const pnl = Number(r.pnl_pct || 0);
                        const isWin = pnl >= 0;
                        const pnlSign = isWin ? '+' : '';
                        let badgeColor = isWin ? '#22c55e' : '#ef4444';
                        let badgeBg = isWin ? 'rgba(34, 197, 94, 0.15)' : 'rgba(239, 68, 68, 0.15)';
                        let statusIcon = '🏁';
                        if (r.status === 'HIT_TP') statusIcon = '🎯';
                        else if (r.status && r.status.includes('LADDER')) statusIcon = '🪜';
                        else if (r.status === 'CLOSED_BE') statusIcon = '🛡️';
                        else if (r.status === 'TIMEOUT_EXIT') statusIcon = '⏱️';
                        else if (r.status === 'HIT_SL') statusIcon = '🛑';

                        rHtml += `
                            <div class="reflection-card" style="border-left: 3px solid ${badgeColor};">
                                <div class="reflection-top">
                                    <div style="display: flex; align-items: center; gap: 6px;">
                                        <span style="font-weight: 700; color: #fff;">${r.symbol}</span>
                                        <span class="tag ${r.direction === 'LONG' ? 'tag-long' : 'tag-short'}">${r.direction}</span>
                                        <span style="font-size: 9.5px; color: var(--text-muted); font-family: 'JetBrains Mono';">${formatTurkeyTime(r.time_str)}</span>
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 5px;">
                                        <span style="font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 4px; background: ${badgeBg}; color: ${badgeColor};">
                                            ${statusIcon} ${r.status} (${pnlSign}${pnl.toFixed(2)}%)
                                        </span>
                                    </div>
                                </div>
                                <div class="reflection-lesson">
                                    ${r.lesson}
                                </div>
                            </div>
                        `;
                    });
                    if (rHtml !== prevReflectHtml) {
                        reflectList.innerHTML = rHtml;
                        prevReflectHtml = rHtml;
                    }
                }
            }

            // 3.7 Sağ Alt: 🧬 Otonom Öğrenme & Kalibrasyon (Self-Tuning Engine)
            const tuning = data.tuning_info;
            const learningReports = data.learning_reports || [];
            const tuningList = document.getElementById('tuningList');
            if (tuningList && tuning) {
                const hScore = tuning.health_score || 75;
                const pFactor = tuning.profit_factor || 1.0;
                const winR = tuning.win_rate || 50;
                const expVal = Number(tuning.expectancy || 0).toFixed(2);
                const expSign = expVal >= 0 ? '+' : '';
                const p = tuning.tuned_params || {};
                const currentEpoch = tuning.epoch_num || (learningReports.length > 0 ? learningReports[0].epoch_num : 1);

                // 1. Üst Özet ve Metrik Kartı
                let tHtml = `
                    <div class="reflection-card" style="border-left: 3px solid #10b981; background: rgba(16, 185, 129, 0.04);">
                        <div class="reflection-top">
                            <div style="display: flex; align-items: center; gap: 6px;">
                                <span style="font-weight: 800; color: #10b981; font-size: 12px;">🧬 Otonom Öğrenme Motoru</span>
                                <span style="background: rgba(16, 185, 129, 0.18); border: 1px solid #10b981; color: #10b981; font-size: 9px; font-weight: 800; padding: 1px 5px; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px;">
                                    <span style="width: 5px; height: 5px; border-radius: 50%; background: #10b981; box-shadow: 0 0 6px #10b981; display: inline-block;"></span>
                                    OTONOM AKTİF
                                </span>
                                <span style="background: rgba(56, 189, 248, 0.15); border: 1px solid #38bdf8; color: #38bdf8; font-size: 9px; font-weight: 800; padding: 1px 5px; border-radius: 4px; font-family: 'JetBrains Mono';">
                                    Döngü #${currentEpoch}
                                </span>
                            </div>
                            <span style="font-size: 10px; background: rgba(16, 185, 129, 0.15); color: #10b981; padding: 2px 7px; border-radius: 4px; font-weight: 700; border: 1px solid rgba(16, 185, 129, 0.3);">
                                Sağlık Skoru: ${hScore}/100
                            </span>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 5px; margin-top: 5px; font-size: 10px; text-align: center;">
                            <div style="background: rgba(255,255,255,0.03); padding: 4px; border-radius: 4px;">
                                <div style="color: var(--text-muted); font-size: 9px;">Kazanma Oranı</div>
                                <div style="font-weight: 800; color: ${winR >= 50 ? '#10b981' : '#ef4444'}; font-size: 11px;">%${winR}</div>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 4px; border-radius: 4px;">
                                <div style="color: var(--text-muted); font-size: 9px;">Beklenti (E)</div>
                                <div style="font-weight: 800; color: ${expVal >= 0 ? '#10b981' : '#ef4444'}; font-size: 11px;">${expSign}${expVal}%</div>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 4px; border-radius: 4px;">
                                <div style="color: var(--text-muted); font-size: 9px;">Kâr Faktörü</div>
                                <div style="font-weight: 800; color: ${pFactor >= 1.0 ? '#10b981' : '#ef4444'}; font-size: 11px;">${pFactor}</div>
                            </div>
                            <div style="background: rgba(255,255,255,0.03); padding: 4px; border-radius: 4px;">
                                <div style="color: var(--text-muted); font-size: 9px;">İncelenen İşlem</div>
                                <div style="font-weight: 800; color: #38bdf8; font-size: 11px;">${tuning.trades_analyzed || (learningReports.length > 0 ? learningReports[0].trades_analyzed : 16)}</div>
                            </div>
                        </div>
                        <div style="font-size: 10px; color: #cbd5e1; margin-top: 6px; line-height: 1.4; border-top: 1px dashed rgba(255,255,255,0.1); padding-top: 5px;">
                            <strong>⚙️ Aktif Kalibre Parametreler:</strong><br>
                            • SMC Kalite Barajı: <span style="color:#38bdf8; font-weight:700;">${p.min_confluence_score || 65}/100</span><br>
                            • Fitil Korumalı Stop Mesafesi: <span style="color:#f59e0b; font-weight:700;">%${p.min_scalp_sl_pct || 0.95} - %${p.max_scalp_sl_pct || 1.35}</span><br>
                            • BTC Dead Chop Eşiği: <span style="color:#ef4444; font-weight:700;">4s &lt; %${p.btc_chop_min_range_4h_pct || 0.70}</span><br>
                            • Merdiven Takip Kanalı: <span style="color:#10b981; font-weight:700;">%${p.ladder_dynamic_channel_pct || 0.25} Dinamik Kâr Kilidi</span><br>
                            • Değiştirilemez Kasa Kalkanı: <span style="color:#10b981; font-weight:700;">Maks %2.0 Risk (Kilitli 🔒)</span><br>
                            • Son Kalibrasyon: <span style="color:#a78bfa; font-weight:700;">${formatTurkeyTime(tuning.calibrated_at || p.last_calibrated_at || '')} (TSİ)</span>
                        </div>
                        <div style="font-size: 9.5px; color: #94a3b8; margin-top: 4px;">
                            <strong>💡 Son Öğrenme Raporu:</strong> ${tuning.summary || 'Parametreler optimize edildi.'}
                        </div>
                        <button onclick="runAutonomousTrainingNow()" id="btnAutoTrain" class="btn-clear" style="border-color:#10b981; color:#10b981; padding: 6px 12px; margin-top: 6px; font-weight: 800; width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer;">
                            <span id="autoTrainSpinner" style="display: none;">⏳</span> <span>🧬 Şimdi Eğit &amp; Optimize Et (Otonom Döngü)</span>
                        </button>
                    </div>
                `;

                // 2. Alt Liste: 📚 Otonom Öğrenme & Keşif Raporları
                if (Array.isArray(learningReports) && learningReports.length > 0) {
                    tHtml += `
                        <div style="font-size: 11px; font-weight: 800; color: #e2e8f0; margin-top: 8px; margin-bottom: 3px; display: flex; justify-content: space-between; align-items: center;">
                            <span>📚 Otonom Öğrenme &amp; Keşif Raporları (${learningReports.length} Döngü)</span>
                            <span style="font-size: 9.5px; color: #10b981; font-weight: 700;">🤖 Otomatik Onaylı</span>
                        </div>
                    `;

                    learningReports.forEach(r => {
                        const isAuto = r.status === 'AUTO_APPROVED';
                        const statusBadge = isAuto 
                            ? '<span style="background: rgba(34, 197, 94, 0.15); border: 1px solid #22c55e; color: #22c55e; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px;">🟢 OTONOM ONAYLANDI</span>'
                            : '<span style="background: rgba(56, 189, 248, 0.15); border: 1px solid #38bdf8; color: #38bdf8; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px;">⚖️ PARAMETRELER OPTİMAL</span>';

                        const hypotheses = Array.isArray(r.hypotheses) ? r.hypotheses : [];
                        const deltas = Array.isArray(r.parameter_deltas) ? r.parameter_deltas : [];
                        const lossAttr = r.loss_attribution || {};

                        let deltasHtml = '';
                        if (deltas.length > 0) {
                            deltasHtml = `
                                <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px;">
                                    ${deltas.map(d => `<span style="font-size: 9.5px; font-weight: 700; padding: 2px 6px; border-radius: 4px; background: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; color: #6ee7b7;">⚙️ ${d.param_name}: ${d.old_val} → ${d.new_val} (${d.delta})</span>`).join('')}
                                </div>
                            `;
                        }

                        let hypothesesHtml = '';
                        if (hypotheses.length > 0) {
                            hypothesesHtml = `
                                <div style="display: flex; flex-direction: column; gap: 3px; margin-top: 4px;">
                                    ${hypotheses.map(h => `<div style="font-size: 9.5px; color: #e2e8f0; line-height: 1.35; padding: 3px 6px; border-radius: 4px; background: rgba(56, 189, 248, 0.05); border-left: 2px solid #38bdf8;">${h}</div>`).join('')}
                                </div>
                            `;
                        }

                        let lossBarHtml = '';
                        if (lossAttr && (lossAttr.total_losses > 0 || lossAttr.wick_hunt_pct !== undefined)) {
                            lossBarHtml = `
                                <div style="font-size: 9px; color: #cbd5e1; margin-top: 4px; background: rgba(255,255,255,0.02); padding: 3px 6px; border-radius: 4px;">
                                    <strong>🔍 Hata Analizi:</strong> Fitil Avı %${lossAttr.wick_hunt_pct || 0} | Testere %${lossAttr.timeout_pct || 0} | Trend Kırılımı %${lossAttr.reversal_pct || 0}
                                </div>
                            `;
                        }

                        tHtml += `
                            <div class="debate-card" style="border-left: 3px solid ${isAuto ? '#10b981' : '#38bdf8'}; background: #0f1523; padding: 8px 10px; margin-top: 6px;">
                                <div class="debate-header">
                                    <div class="debate-sym">
                                        <span style="color: #fff; font-size: 11.5px; font-weight: 800;">🧬 Döngü (Epoch) #${r.epoch_num}</span>
                                        ${statusBadge}
                                    </div>
                                    <span style="font-size: 9.5px; color: var(--text-muted); font-family: 'JetBrains Mono';">${formatTurkeyTime(r.time_str || r.created_at)}</span>
                                </div>

                                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 9.5px; color: var(--text-muted); border-bottom: 1px dashed rgba(255,255,255,0.07); padding-bottom: 4px;">
                                    <span>İncelenen: <strong style="color: #fff;">${r.trades_analyzed} İşlem</strong></span>
                                    <span>Win-Rate: <strong style="color: ${r.win_rate >= 50 ? '#10b981' : '#ef4444'};">%${r.win_rate}</strong></span>
                                    <span>Beklenti: <strong style="color: ${r.expectancy >= 0 ? '#10b981' : '#ef4444'};">${r.expectancy >= 0 ? '+' : ''}${r.expectancy}%</strong></span>
                                    <span>Kâr Faktörü: <strong style="color: #38bdf8;">${r.profit_factor}</strong></span>
                                </div>

                                ${r.regime_diagnosis ? `
                                    <div style="padding: 4px 7px; border-radius: 4px; background: rgba(168, 85, 247, 0.08); border-left: 3px solid #a855f7; color: #f3e8ff; font-size: 9.5px; margin-top: 4px;">
                                        <strong>🏛️ Rejim Teşhisi:</strong> ${r.regime_diagnosis}
                                    </div>
                                ` : ''}

                                ${lossBarHtml}
                                ${hypothesesHtml}
                                ${deltasHtml}
                            </div>
                        `;
                    });
                }

                if (tHtml !== prevTuningHtml) {
                    tuningList.innerHTML = tHtml;
                    prevTuningHtml = tHtml;
                }
            }

            // 4. Sağ Alt: 📰 Haber Kararlandırma Konseyi & Canlı RSS Masası
            const investigations = data.coin_news_investigations;
            const councilReportList = document.getElementById('councilReportList');
            const councilBadge = document.getElementById('councilBadgeCount');
            if (councilBadge && Array.isArray(investigations)) {
                councilBadge.innerText = '(' + investigations.length + ')';
            }

            if (councilReportList && Array.isArray(investigations) && investigations.length > 0) {
                let cHtml = '';
                investigations.forEach(inv => {
                    const isLong = inv.direction === 'LONG';
                    const score = Number(inv.news_score || 50);
                    let scoreColor = '#38bdf8';
                    let scoreBg = 'rgba(56, 189, 248, 0.12)';
                    if (score >= 65) {
                        scoreColor = '#22c55e';
                        scoreBg = 'rgba(34, 197, 94, 0.15)';
                    } else if (score <= 35) {
                        scoreColor = '#ef4444';
                        scoreBg = 'rgba(239, 68, 68, 0.15)';
                    }

                    const mult = Number(inv.pos_multiplier !== undefined ? inv.pos_multiplier : 1.0);
                    let multText = mult + 'x Pozisyon';
                    let multColor = '#38bdf8';
                    let multBg = 'rgba(56, 189, 248, 0.12)';
                    if (inv.is_vetoed || mult === 0.0) {
                        multText = '🚨 0.0x VETO';
                        multColor = '#ef4444';
                        multBg = 'rgba(239, 68, 68, 0.2)';
                    } else if (mult >= 1.20) {
                        multText = '🔥 ' + mult + 'x (+%25 Hacim)';
                        multColor = '#22c55e';
                        multBg = 'rgba(34, 197, 94, 0.18)';
                    } else if (mult >= 1.05) {
                        multText = '📈 ' + mult + 'x (+%10 Hacim)';
                        multColor = '#10b981';
                        multBg = 'rgba(16, 185, 129, 0.15)';
                    } else if (mult < 1.0) {
                        multText = '🛡️ ' + mult + 'x (Defansif Kasa)';
                        multColor = '#f59e0b';
                        multBg = 'rgba(245, 158, 11, 0.15)';
                    }

                    const isVeto = inv.is_vetoed || mult === 0.0;
                    const verdictColor = isVeto ? '#ef4444' : (score >= 65 ? '#22c55e' : (score <= 35 ? '#f59e0b' : '#38bdf8'));
                    const verdictBg = isVeto ? 'rgba(239, 68, 68, 0.15)' : (score >= 65 ? 'rgba(34, 197, 94, 0.12)' : 'rgba(56, 189, 248, 0.10)');

                    // 3 Masanın Görüşleri
                    const debateArr = Array.isArray(inv.council_debate) ? inv.council_debate : [];
                    let regText = 'Regülasyon ve hukuki zemin stabil, inceleme altında.';
                    let secText = 'Protokol ve akıllı sözleşme güvenliği olağan akışında.';
                    let whaleText = 'Sosyal hacim ve balina transferleri normal seviyede.';

                    debateArr.forEach(d => {
                        const str = String(d);
                        const cleanContent = str.indexOf(']:') !== -1 ? str.substring(str.indexOf(']:') + 2).trim() : str;
                        if (str.includes('Regülasyon') || str.includes('🏛️')) {
                            regText = cleanContent;
                        } else if (str.includes('Güvenlik') || str.includes('Protokol') || str.includes('🔐')) {
                            secText = cleanContent;
                        } else if (str.includes('Balina') || str.includes('Twitter') || str.includes('X') || str.includes('🐋')) {
                            whaleText = cleanContent;
                        }
                    });

                    const isSecAlert = isVeto || secText.includes('KRİTİK') || secText.includes('GÜVENLİK ALARMI') || secText.includes('hack') || secText.includes('açığı');

                    // Coine Özel Yakalanan Haber Başlıkları
                    const topArts = Array.isArray(inv.top_articles) ? inv.top_articles : [];
                    let articlesHtml = '';
                    if (topArts.length > 0) {
                        let artItems = '';
                        topArts.slice(0, 3).forEach(a => {
                            let aSent = a.sentiment || 'NEUTRAL';
                            let sColor = aSent === 'BULLISH' ? '#22c55e' : (aSent === 'BEARISH' ? '#ef4444' : '#94a3b8');
                            artItems += `
                                <div style="font-size: 10px; color: #cbd5e1; display: flex; align-items: baseline; gap: 5px; margin-bottom: 2px;">
                                    <span style="font-size: 8.5px; padding: 1px 4px; border-radius: 3px; background: rgba(255,255,255,0.06); color: var(--text-muted); font-family: 'JetBrains Mono';">${a.source || 'Haber'}</span>
                                    <span style="font-size: 8.5px; font-weight: 700; color: ${sColor};">${aSent}</span>
                                    <span style="color: #e2e8f0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1;">${a.title}</span>
                                </div>
                            `;
                        });
                        articlesHtml = `
                            <div style="margin-top: 5px; border-top: 1px dashed rgba(255,255,255,0.08); padding-top: 4px;">
                                <div style="font-size: 9px; color: var(--text-muted); font-weight: 700; margin-bottom: 3px;">🔍 Doğrulanan Haberler:</div>
                                ${artItems}
                            </div>
                        `;
                    }

                    cHtml += `
                        <div class="debate-card" style="border-left: 3px solid ${verdictColor}; background: #101622;">
                            <div class="debate-header">
                                <div class="debate-sym">
                                    <span style="color: #fff; font-size: 12px; font-weight: 800;">🪙 ${inv.symbol}</span>
                                    <span class="tag ${isLong ? 'tag-long' : 'tag-short'}">${inv.direction}</span>
                                    <span style="font-size: 9.5px; color: var(--text-muted); font-family: 'JetBrains Mono';">${formatTurkeyTime(inv.time_str || inv.created_at)}</span>
                                </div>
                                <div style="display: flex; align-items: center; gap: 5px;">
                                    <span style="font-family: 'JetBrains Mono'; font-size: 9.5px; font-weight: 800; padding: 2px 5px; border-radius: 4px; background: ${scoreBg}; color: ${scoreColor}; border: 1px solid ${scoreColor};">
                                        📊 Skor: ${score}/100
                                    </span>
                                    <span style="font-family: 'JetBrains Mono'; font-size: 9.5px; font-weight: 800; padding: 2px 5px; border-radius: 4px; background: ${multBg}; color: ${multColor}; border: 1px solid ${multColor};">
                                        ${multText}
                                    </span>
                                </div>
                            </div>

                            <div style="padding: 4px 7px; border-radius: 4px; background: ${verdictBg}; color: ${verdictColor}; font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: space-between;">
                                <span>${inv.verdict}</span>
                                ${inv.funding_rate_pct ? `<span style="font-size: 9px; opacity: 0.9; font-family: 'JetBrains Mono';">Fonlama: %${Number(inv.funding_rate_pct).toFixed(3)}</span>` : ''}
                            </div>

                            ${isVeto ? `
                                <div style="padding: 5px 7px; border-radius: 4px; background: rgba(239, 68, 68, 0.12); border-left: 3px solid #ef4444; color: #fca5a5; font-size: 10px; font-weight: 600;">
                                    ${inv.veto_reason || '🚨 Pozisyon Konsey Tarafından Kara Kuğu Riski Sebebiyle Veto Edildi (0.0x Marjin)'}
                                </div>
                            ` : ''}

                            <div style="display: flex; flex-direction: column; gap: 3px; margin-top: 2px;">
                                <div class="dialogue-bubble bubble-reg" style="font-size: 10px; padding: 4px 7px;">
                                    <div class="speaker-title" style="color: #c084fc;">🏛️ Regülasyon &amp; Hukuk Şefi</div>
                                    <div>${regText}</div>
                                </div>

                                <div class="dialogue-bubble ${isSecAlert ? 'bubble-sec-alert' : 'bubble-sec-safe'}" style="font-size: 10px; padding: 4px 7px;">
                                    <div class="speaker-title" style="color: ${isSecAlert ? '#f87171' : '#34d399'};">🔐 Protokol &amp; On-Chain Güvenlik</div>
                                    <div>${secText}</div>
                                </div>

                                <div class="dialogue-bubble bubble-whale" style="font-size: 10px; padding: 4px 7px;">
                                    <div class="speaker-title" style="color: #fbbf24;">🐋 Balina &amp; X / Twitter Masası</div>
                                    <div>${whaleText}</div>
                                </div>
                            </div>

                            ${articlesHtml}
                        </div>
                    `;
                });

                if (cHtml !== prevCouncilHtml) {
                    councilReportList.innerHTML = cHtml;
                    prevCouncilHtml = cHtml;
                }
            } else if (councilReportList && (!investigations || investigations.length === 0)) {
                councilReportList.innerHTML = `
                    <div style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">
                        🏛️ Henüz incelenen bir coin yok. Yukarıdaki arama kutusuna coin yazarak (örn: SOL, BTC, KAVA) konseyi çalıştırabilirsiniz.
                    </div>
                `;
            }

            // Küresel RSS Haberleri
            const news = data.news_feed;
            const rssBadge = document.getElementById('rssBadgeCount');
            if (rssBadge && Array.isArray(news)) {
                rssBadge.innerText = '(' + news.length + ')';
            }
            if (Array.isArray(news) && news.length > 0) {
                const newsList = document.getElementById('newsList');
                if (newsList) {
                    let newsHtml = '';
                    news.forEach(n => {
                        let sentClass = 'sent-neut';
                        if (n.sentiment === 'BULLISH') sentClass = 'sent-bull';
                        if (n.sentiment === 'BEARISH') sentClass = 'sent-bear';

                        newsHtml += `
                            <div class="news-item">
                                <div class="news-meta">
                                    <span>${n.source || 'RSS'}</span>
                                    <span class="${sentClass}">${n.sentiment}</span>
                                    <span>${formatTurkeyTime(n.time)}</span>
                                </div>
                                <div class="news-title">${n.title}</div>
                            </div>
                        `;
                    });
                    if (newsHtml !== prevNewsHtml) {
                        newsList.innerHTML = newsHtml;
                        prevNewsHtml = newsHtml;
                    }
                }
            }

            // 5. Alt Kısım: PnL Geçmiş Tablosu (Son Kapatılan İşlem Anında En Üste Gelir)
            let history = historyList;
            if (Array.isArray(history)) {
                history = [...history].sort((a, b) => {
                    const timeA = new Date(a.closed_at || a.created_at || 0).getTime();
                    const timeB = new Date(b.closed_at || b.created_at || 0).getTime();
                    if (timeB !== timeA) return timeB - timeA;
                    return (b.id || 0) - (a.id || 0);
                });
            }
            const historyBody = document.getElementById('historyBody');
            const historyCountEl = document.getElementById('historyCount');
            if (historyCountEl) historyCountEl.innerText = (Array.isArray(history) ? history.length : 0) + ' İşlem';

            if (Array.isArray(history) && history.length > 0) {
                let histHtml = '';
                history.forEach(tr => {
                    const isLong = tr.direction === 'LONG';
                    const pnl = Number(tr.simulated_pnl_pct || 0);
                    const pnlSign = pnl > 0 ? '+' : '';
                    const pnlClass = pnl > 0 ? 'pnl-pos' : (pnl < 0 ? 'pnl-neg' : '');

                    const feePct = tr.fee_pct ? Number(tr.fee_pct) : (0.10 * Number(tr.leverage || 10));
                    const grossPct = tr.gross_pnl_pct !== undefined && tr.gross_pnl_pct !== 0.0 ? Number(tr.gross_pnl_pct) : (pnl + feePct);
                    const grossSign = grossPct > 0 ? '+' : '';

                    let resBadge = tr.status;
                    if (tr.status === 'HIT_TP' || tr.status === 'HIT_TP2') resBadge = '<span style="color:var(--green); font-weight:700;">🎯 Vur-Kaç Kâr</span>';
                    else if (tr.status && (tr.status.startsWith('LADDER_STEP_') || tr.status === 'LADDER_PROFIT_EXIT')) resBadge = `<span style="color:#f59e0b; font-weight:700;">${tr.ladder_name || '🪜 Merdiven Kârı'}</span>`;
                    else if (tr.status === 'TRAILING_STOP_EXIT') resBadge = '<span style="color:#f59e0b; font-weight:700;">⚡ Dinamik Kanal</span>';
                    else if (tr.status === 'CLOSED_BE') resBadge = '<span style="color:var(--cyan); font-weight:700;">🛡️ BE+ (Komisyon Korumalı)</span>';
                    else if (tr.status === 'TIMEOUT_EXIT') resBadge = '<span style="color:var(--yellow); font-weight:700;">⏱️ 45dk Çıkış</span>';
                    else if (tr.status === 'MANUAL_CLOSE') resBadge = '<span style="color:#a855f7; font-weight:700;">🛑 El İle Kapatıldı</span>';
                    else if (tr.status === 'HIT_SL') resBadge = '<span style="color:var(--red); font-weight:700;">🛑 Stop Loss</span>';

                    let tfBadge = '<span class="tag" style="background:rgba(56,189,248,0.2); color:#38bdf8; font-weight:700;">⚡ 15m Kısa</span>';
                    const trTf = tr.timeframe || (tr.trade_horizon && tr.trade_horizon.includes('1h') ? '1h' : (tr.trade_horizon && tr.trade_horizon.includes('30m') ? '30m' : '15m'));
                    if (trTf === '1h' || (tr.trade_horizon && tr.trade_horizon.includes('Uzun'))) {
                        tfBadge = '<span class="tag" style="background:rgba(245,158,11,0.22); color:#fbbf24; border:1px solid #f59e0b; font-weight:700;">👑 1h Uzun</span>';
                    } else if (trTf === '30m' || (tr.trade_horizon && tr.trade_horizon.includes('Orta'))) {
                        tfBadge = '<span class="tag" style="background:rgba(168,85,247,0.22); color:#c084fc; border:1px solid #a855f7; font-weight:700;">🎯 30m Orta</span>';
                    }

                    histHtml += `
                        <tr>
                            <td style="color: var(--text-muted); font-size: 10px;">${formatTurkeyTime(tr.closed_at || tr.created_at)}</td>
                            <td><strong>${tr.symbol}</strong></td>
                            <td><span class="tag ${isLong ? 'tag-long' : 'tag-short'}">${tr.direction}</span></td>
                            <td><span class="tag tag-lev">${tr.leverage}x</span></td>
                            <td>${tfBadge}</td>
                            <td class="mono">$${tr.actual_entry_price || tr.entry_min}</td>
                            <td class="mono">$${tr.exit_price || '-'}</td>
                            <td>${resBadge}</td>
                            <td>
                                <div class="mono ${pnlClass}" style="font-size: 12px; font-weight: 700;">
                                    ${pnlSign}${pnl.toFixed(2)}% Net
                                </div>
                                <div style="font-size: 8.5px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace;">
                                    Brüt: ${grossSign}${grossPct.toFixed(2)}% | Kom: -${feePct.toFixed(2)}%
                                </div>
                            </td>
                        </tr>
                    `;
                });
                if (histHtml !== prevHistHtml) {
                    historyBody.innerHTML = histHtml;
                    prevHistHtml = histHtml;
                }
            } else if (historyBody) {
                const emptyMsg = `<tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 25px; font-size: 11px;">Henüz tamamlanmış işlem kaydı yok.</td></tr>`;
                if (historyBody.innerHTML !== emptyMsg) {
                    historyBody.innerHTML = emptyMsg;
                    prevHistHtml = '';
                }
            }

            // 7. 3D Sims Ofis Verilerini Canlı Güncelle
            if (typeof updateOffice3DData === 'function') {
                updateOffice3DData(data);
            }
        }

        async function triggerScan() {
            const btn = document.querySelector('.btn-scan');
            if (btn) btn.innerText = '⏳...';
            let url = '/api/scan';
            if (currentBotMode === 'superfast') url = '/api/superfast/scan';
            else if (currentBotMode === 'fast') url = '/api/fast/scan';
            try {
                await fetch(url, { method: 'POST' });
                await fetchTerminal();
            } catch(e) {}
            if (btn) btn.innerText = '⚡ Tara';
        }

        async function getAdminPin() {
            let pin = sessionStorage.getItem('admin_pin');
            if (!pin) {
                pin = prompt("🛡️ Yönetici Güvenlik PIN Kodunu Giriniz (Varsayılan: 1923):");
                if (pin) sessionStorage.setItem('admin_pin', pin.trim());
            }
            return pin;
        }

        async function closeSinglePosition(symbol, signalId) {
            if (!symbol) return;
            const msg = `⚡ ${symbol} açık pozisyonunu anlık piyasa fiyatından (Market Emri) kapatmak istediğinize emin misiniz?`;
            if (!confirm(msg)) return;
            const pin = await getAdminPin();
            if (!pin) return;

            const card = document.getElementById(`card-${symbol}`);
            const btn = card ? card.querySelector('.btn-manual-close') : null;
            const oldHtml = btn ? btn.innerHTML : '';
            if (btn) {
                btn.innerHTML = '⏳...';
                btn.disabled = true;
            }

            try {
                const res = await fetch('/api/close-position', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Admin-Pin': pin
                    },
                    body: JSON.stringify({ symbol: symbol, signal_id: signalId })
                });

                if (res.status === 401) {
                    sessionStorage.removeItem('admin_pin');
                    alert('🔒 Hata: Geçersiz Yönetici Güvenlik PIN Kodu!');
                } else {
                    const data = await res.json();
                    if (data.status === 'success') {
                        await fetchTerminal();
                    } else {
                        alert('⚠️ ' + (data.message || 'Pozisyon kapatılamadı.'));
                    }
                }
            } catch (err) {
                console.error("Manuel kapatma hatası:", err);
                alert('İletişim hatası: Pozisyon kapatılamadı!');
            } finally {
                if (btn) {
                    btn.innerHTML = oldHtml;
                    btn.disabled = false;
                }
            }
        }

        async function closePositionsGroup(group) {
            const isProfitGroup = (group === 'profit' || group === 'green' || group === 'kar');
            const groupName = isProfitGroup ? 'KÂRDAKİ' : 'ZARARDAKİ';
            const msg = `⚡ Tüm ${groupName} açık pozisyonları anlık piyasa fiyatından kapatmak istediğinize emin misiniz?`;
            if (!confirm(msg)) return;
            const pin = await getAdminPin();
            if (!pin) return;

            const btns = document.querySelectorAll(isProfitGroup ? '.btn-close-profit' : '.btn-close-loss');
            btns.forEach(b => {
                b.setAttribute('data-old-text', b.innerHTML);
                b.innerHTML = '⏳ Kapatılıyor...';
                b.disabled = true;
            });

            try {
                const res = await fetch('/api/close-positions-group', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Admin-Pin': pin
                    },
                    body: JSON.stringify({ group: isProfitGroup ? 'profit' : 'loss' })
                });

                if (res.status === 401) {
                    sessionStorage.removeItem('admin_pin');
                    alert('🔒 Hata: Geçersiz Yönetici Güvenlik PIN Kodu!');
                } else {
                    const data = await res.json();
                    if (data.status === 'success') {
                        await fetchTerminal();
                    } else {
                        alert('⚠️ ' + (data.message || 'Pozisyonlar kapatılamadı.'));
                    }
                }
            } catch (err) {
                console.error("Grup kapatma hatası:", err);
                alert('İletişim hatası: Pozisyonlar kapatılamadı!');
            } finally {
                btns.forEach(b => {
                    const oldTxt = b.getAttribute('data-old-text') || (isProfitGroup ? '💰 Kârdakileri Kapat' : '🛑 Zarardakileri Kapat');
                    b.innerHTML = oldTxt;
                    b.disabled = false;
                });
            }
        }

        async function closeAllPositions() {
            let botName = 'Standart';
            let url = '/api/close-all-positions';
            if (currentBotMode === 'superfast') {
                botName = 'SÜPER FAST';
                url = '/api/superfast/close-all-positions';
            } else if (currentBotMode === 'fast') {
                botName = 'FAST';
                url = '/api/fast/close-all-positions';
            }
            const msg = `Tüm ${botName} açık pozisyonlarını anlık piyasa fiyatından kapatmak istediğinize emin misiniz?`;
            if (!confirm(msg)) return;
            const pin = await getAdminPin();
            if (!pin) return;
            const btn = document.querySelector('.btn-panic');
            if (btn) btn.innerText = '⏳ Kapatılıyor...';
            try {
                const res = await fetch(url, { 
                    method: 'POST',
                    headers: { 'X-Admin-Pin': pin }
                });
                if (res.status === 401) {
                    sessionStorage.removeItem('admin_pin');
                    alert('🔒 Hata: Geçersiz Yönetici Güvenlik PIN Kodu!');
                } else {
                    await fetchTerminal();
                }
            } catch(e) {}
            if (btn) btn.innerText = '🚫 Tümünü Kapat';
        }

        async function clearTradeHistory() {
            let botName = 'Standart';
            let url = '/api/clear-history';
            if (currentBotMode === 'superfast') {
                botName = 'Süper FAST';
                url = '/api/superfast/clear-history';
            } else if (currentBotMode === 'fast') {
                botName = 'FAST';
                url = '/api/fast/clear-history';
            }
            const msg = `${botName} işlem defterini temizlemek istediğinize emin misiniz? (Aktif işlemler korunur)`;
            if (!confirm(msg)) return;
            const pin = await getAdminPin();
            if (!pin) return;
            const btn = document.querySelector('.btn-clear');
            if (btn) btn.innerText = '⏳...';
            try {
                const res = await fetch(url, { 
                    method: 'POST',
                    headers: { 'X-Admin-Pin': pin }
                });
                if (res.status === 401) {
                    sessionStorage.removeItem('admin_pin');
                    alert('🔒 Hata: Geçersiz Yönetici Güvenlik PIN Kodu!');
                } else {
                    prevHistHtml = '';
                    const historyBody = document.getElementById('historyBody');
                    if (historyBody) historyBody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 20px;">${botName} kapanan işlem kaydı yok.</td></tr>`;
                    const histCountEl = document.getElementById('historyCount');
                    if (histCountEl) histCountEl.innerText = '0 İşlem';
                    await fetchTerminal();
                }
            } catch(e) {}
            if (btn) btn.innerText = '🗑️ Geçmişi Temizle';
        }

        async function runAutonomousTrainingNow() {
            const btn = document.getElementById('btnAutoTrain');
            const spinner = document.getElementById('autoTrainSpinner');
            if (spinner) spinner.style.display = 'inline-block';
            if (btn) btn.disabled = true;

            try {
                const res = await fetch('/api/tuning/run-autonomous', { method: 'POST' });
                const json = await res.json();
                if (json && json.success) {
                    await fetchTerminal();
                } else {
                    alert('Otonom eğitim hatası: ' + (json ? json.error : 'Bilinmeyen hata'));
                }
            } catch(e) {
                console.error('Otonom eğitim hatası:', e);
                alert('Otonom eğitim bağlantı hatası: ' + e);
            } finally {
                if (spinner) spinner.style.display = 'none';
                if (btn) btn.disabled = false;
            }
        }

        async function runCalibrationNow() {
            const pin = await getAdminPin();
            if (!pin) return;
            const btn = document.querySelector('.btn-clear[onclick*="runCalibrationNow"]') || event?.target;
            if (btn) btn.innerText = '⏳ Analiz Ediliyor...';
            try {
                const res = await fetch('/api/tuning/calibrate', { 
                    method: 'POST',
                    headers: { 'X-Admin-Pin': pin }
                });
                if (res.status === 401) {
                    sessionStorage.removeItem('admin_pin');
                    alert('🔒 Hata: Geçersiz Yönetici Güvenlik PIN Kodu!');
                } else {
                    const json = await res.json();
                    const sumMsg = json.summary || 'Parametreler optimize edildi.';
                    alert('🧬 Otonom Kalibrasyon Tamamlandı: ' + sumMsg);
                    await fetchTerminal();
                }
            } catch(e) {
                alert('Kalibrasyon hatası: ' + e);
            }
            if (btn) btn.innerText = '🧬 Şimdi Analiz Et ve Optimize Et';
        }

/* ==========================================================================
   🎮 3D SİMS TARZI YAPAY ZEKA TİCARET OFİSİ (THREE.JS ENGINE) - v5.1.0
   Patron Efe Özel Sürümü:
   1. Duvar Tıkanması Çözüldü: Ön duvar ve tavan kaldırıldı; Kuşbakışı ve tüm açılardan %100 net görünüm.
   2. Masada Gerçek Oturuş: Üst bacaklar (thighs) yere tam paralel masaya uzanır, alt bacaklar dik iner.
   3. Masa Rengi Sabit & Tek Renk: Renk değiştirmeyen, parlamayan lüks koyu mat füme trading masası.
   4. Köşe Tuvalet & Açılır-Kapanır Kapı: Eleman kapıyı açar, içeri girer, kapı kapanır, ihtiyaç giderilir.
   5. Lavabo & El Yıkama: Tuvaletten çıkan eleman yanındaki aynalı lavaboya geçer, ellerini sabunla yıkar.
   6. Genişletilmiş Oturma & PlayStation Lounge: Ekstra kanepeler, 65" TV, PS5 konsolu ve animasyonlu oyun.
   7. Köşeye Alınan Oyun Alanı: Masa tenisi ve langırt köşeye çekildi, Mehmet & Berat izleme bankı eklendi.
   8. Mehmet & Berat Çoklu Dinlenme: PS5 koltuğu, çay köşesi, langırt ve masa tenisi arasında keyifli goygoy.
   ========================================================================== */

let officeScene, officeCamera, officeRenderer, officeControls;
let officeInitialized = false;
let officeAnimFrameId = null;

// WC Kapısı & Işığı & Lavabo
let wcDoorGroup = null;
let wcDoorTargetRot = 0;
let portableWcLight = null;

// TV & PlayStation Ekranı
let tvScreenCanvas = null;
let tvScreenCtx = null;
let tvScreenTexture = null;
let tvScreenMesh = null;

// Karakterler & Ajanlar
const friends = {};
const agents = {};
let bossGroup = null;
let bossHeadMesh = null;
let plumbobMesh = null;

// Masa Monitörleri ve Ekranlar
let officeDeskScreens = [];
let bigWallTexture = null;
let bigWallCtx = null;
let bigWallScreenMesh = null;

// Konfeti Parçacık Sistemi
let confettiParticles = [];
let confettiActive = false;
let lastKnownTradeStatus = null;

// Sırayla Konuşma Yönetimi (Single Speaker Lock)
let activeSpeakerId = null;
let speechUnlockTimer = null;

// Otonom Eylem Sırası (Sadece 1 Eleman Aynı Anda Gezer - Çarpışma Önleyici)
let isAnyAgentWalking = false;

// Kamera Hedefleri
let camTargetPos = null;
let camLookTarget = null;
let camCurrentLook = null;

// Baloncuk Görünüm Modu & Zamanlayıcılar
let currentBubbleMode = window.innerWidth < 768 ? 'smart' : 'all';
let nextAutonomousActionTime = 45000; // İlk 45 sn tüm ekip masasında kesintisiz çalışır
let nextDialogueTime = 3000;
let nextFriendsGameTime = 6000;

// Karakter Balon Çapaları
const bubbleAnchors = {
    boss: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    scanner: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    ta: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    news: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    risk: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    chief: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    quant: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    mehmet: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    berat: { pos: null, el: null, bodyEl: null, isSpeaking: false },
    trade: { pos: null, el: null, bodyEl: null, isSpeaking: false }
};

// -------------------------------------------------------------
// WEB AUDIO AMBİYANS & GERÇEKÇİ OFİS SESLERİ
// -------------------------------------------------------------
let officeAudioCtx = null;
let isOfficeAudioMuted = true;

function initOfficeAudio() {
    if (!officeAudioCtx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) officeAudioCtx = new AudioContext();
    }
    if (officeAudioCtx && officeAudioCtx.state === 'suspended') {
        officeAudioCtx.resume();
    }
}

function playOfficeSound(type) {
    if (isOfficeAudioMuted) return;
    initOfficeAudio();
    if (!officeAudioCtx) return;

    const ctx = officeAudioCtx;
    const now = ctx.currentTime;

    if (type === 'click') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.04);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.05);
    } else if (type === 'chime') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.setValueAtTime(659.25, now + 0.08);
        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.36);
    } else if (type === 'talk') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const baseFreq = 380 + Math.random() * 140;
        osc.frequency.setValueAtTime(baseFreq, now);
        osc.frequency.linearRampToValueAtTime(baseFreq + 60, now + 0.05);
        osc.frequency.linearRampToValueAtTime(baseFreq - 30, now + 0.12);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.14);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.15);
    } else if (type === 'door') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.linearRampToValueAtTime(90, now + 0.12);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.13);
    } else if (type === 'water') {
        // Lavaboda el yıkama su sesi
        try {
            const bufferSize = ctx.sampleRate * 0.4;
            const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
            const data = buffer.getChannelData(0);
            for (let i = 0; i < bufferSize; i++) {
                data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.6));
            }
            const noise = ctx.createBufferSource();
            noise.buffer = buffer;
            const filter = ctx.createBiquadFilter();
            filter.type = 'bandpass';
            filter.frequency.value = 1200;
            filter.Q.value = 1.5;
            const gain = ctx.createGain();
            gain.gain.setValueAtTime(0.05, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
            noise.connect(filter);
            filter.connect(gain);
            gain.connect(ctx.destination);
            noise.start(now);
            noise.stop(now + 0.4);
        } catch(e) {}
    } else if (type === 'pingpong') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1100, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
        gain.gain.setValueAtTime(0.09, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.05);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.06);
    } else if (type === 'confetti') {
        for (let i = 0; i < 4; i++) {
            setTimeout(() => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                const f = 400 + i * 220;
                osc.frequency.setValueAtTime(f, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(f * 2.2, ctx.currentTime + 0.18);
                gain.gain.setValueAtTime(0.09, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(ctx.currentTime);
                osc.stop(ctx.currentTime + 0.23);
            }, i * 90);
        }
    } else if (type === 'tea') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(450, now);
        osc.frequency.linearRampToValueAtTime(650, now + 0.22);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.25);
    }
}

function toggleOfficeSound() {
    isOfficeAudioMuted = !isOfficeAudioMuted;
    const btn = document.getElementById('btnOfficeAudio');
    if (btn) {
        btn.innerText = isOfficeAudioMuted ? '🔇' : '🔊';
        btn.style.color = isOfficeAudioMuted ? '#94a3b8' : '#22c55e';
    }
    if (!isOfficeAudioMuted) {
        initOfficeAudio();
        playOfficeSound('chime');
    }
}

// -------------------------------------------------------------
// SIRAYLA KONUŞMA SİSTEMİ (ACTIVE SPEAKER LOCK)
// -------------------------------------------------------------
function triggerSpeech(charId, text, durationMs = 5000) {
    if (currentBubbleMode === 'off') return;
    if (currentBubbleMode === 'boss' && charId !== 'boss' && charId !== 'trade') return;

    // Eğer şu an biri konuşuyorsa ve bu acil Patron değilse bekle (sıra kuralı)
    if (activeSpeakerId !== null && activeSpeakerId !== charId && charId !== 'boss') {
        return;
    }

    // Önceki konuşan varsa kapat
    if (activeSpeakerId && activeSpeakerId !== charId && bubbleAnchors[activeSpeakerId]) {
        bubbleAnchors[activeSpeakerId].isSpeaking = false;
        if (bubbleAnchors[activeSpeakerId].el) {
            bubbleAnchors[activeSpeakerId].el.classList.remove('speaking');
        }
    }

    const anchor = bubbleAnchors[charId];
    if (!anchor || !anchor.el) return;

    if (anchor.bodyEl && text) {
        anchor.bodyEl.innerText = text;
    }

    activeSpeakerId = charId;
    anchor.isSpeaking = true;
    anchor.el.classList.add('speaking');
    playOfficeSound('talk');

    if (speechUnlockTimer) {
        clearTimeout(speechUnlockTimer);
    }

    speechUnlockTimer = setTimeout(() => {
        anchor.isSpeaking = false;
        if (anchor.el) anchor.el.classList.remove('speaking');
        activeSpeakerId = null;
    }, durationMs);
}

// -------------------------------------------------------------
// 🎉 KONFETİ SİSTEMİ
// -------------------------------------------------------------
function triggerOfficeConfetti() {
    playOfficeSound('confetti');

    // Çalışanların kollarını kaldırıp sevinmesi
    Object.values(agents).forEach(ag => {
        if (ag && ag.leftArm && ag.rightArm) {
            ag.leftArm.rotation.x = -Math.PI / 1.5;
            ag.rightArm.rotation.x = -Math.PI / 1.5;
            setTimeout(() => {
                if (ag.state === 'SEATED_WORKING') {
                    ag.leftArm.rotation.x = Math.PI / 4;
                    ag.rightArm.rotation.x = Math.PI / 4;
                }
            }, 3000);
        }
    });

    triggerSpeech('boss', "🎉 Hedef Vuruldu! Kâr Kasada! Harika disiplin beyler!", 5000);

    const colors = [0x22c55e, 0x3b82f6, 0xf59e0b, 0xec4899, 0xa855f7, 0x06b6d4, 0xffffff];
    const confettiGeo = new THREE.BoxGeometry(0.08, 0.08, 0.005);

    for (let i = 0; i < 140; i++) {
        const mat = new THREE.MeshBasicMaterial({
            color: colors[Math.floor(Math.random() * colors.length)],
            side: THREE.DoubleSide
        });
        const mesh = new THREE.Mesh(confettiGeo, mat);

        const x = (Math.random() - 0.5) * 5.0;
        const y = 3.5 + Math.random() * 2.5;
        const z = (Math.random() - 0.5) * 4.5;
        mesh.position.set(x, y, z);

        mesh.rotation.x = Math.random() * Math.PI * 2;
        mesh.rotation.y = Math.random() * Math.PI * 2;
        mesh.rotation.z = Math.random() * Math.PI * 2;

        officeScene.add(mesh);

        confettiParticles.push({
            mesh: mesh,
            vx: (Math.random() - 0.5) * 0.8,
            vy: -1.0 - Math.random() * 1.4,
            vz: (Math.random() - 0.5) * 0.8,
            rotSpeedX: (Math.random() - 0.5) * 8.0,
            rotSpeedY: (Math.random() - 0.5) * 8.0,
            rotSpeedZ: (Math.random() - 0.5) * 8.0,
            life: 3.5 + Math.random() * 1.5
        });
    }

    confettiActive = true;
}

function updateConfetti(deltaTime) {
    if (!confettiActive || confettiParticles.length === 0) return;

    for (let i = confettiParticles.length - 1; i >= 0; i--) {
        const p = confettiParticles[i];
        p.life -= deltaTime;
        p.mesh.position.x += p.vx * deltaTime;
        p.mesh.position.y += p.vy * deltaTime;
        p.mesh.position.z += p.vz * deltaTime;

        p.mesh.rotation.x += p.rotSpeedX * deltaTime;
        p.mesh.rotation.y += p.rotSpeedY * deltaTime;
        p.mesh.rotation.z += p.rotSpeedZ * deltaTime;

        if (p.mesh.position.y < 0.78 || p.life <= 0) {
            officeScene.remove(p.mesh);
            p.mesh.geometry.dispose();
            p.mesh.material.dispose();
            confettiParticles.splice(i, 1);
        }
    }

    if (confettiParticles.length === 0) {
        confettiActive = false;
    }
}

// -------------------------------------------------------------
// 🎮 3D OFİS MOTORU BAŞLATMA
// -------------------------------------------------------------
function init3DOffice() {
    if (officeInitialized) return;
    const target = document.getElementById('officeCanvasTarget');
    if (!target) return;

    let width = target.clientWidth || target.offsetWidth;
    let height = target.clientHeight || target.offsetHeight;
    if (!width || width < 100) width = 800;
    if (!height || height < 100) height = 520;

    // 1. Sahne
    officeScene = new THREE.Scene();
    officeScene.background = new THREE.Color(0x0a0f1d);

    // 2. Kamera
    officeCamera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camCurrentLook = new THREE.Vector3(0, 1.1, -0.8);
    officeCamera.position.set(0, 2.2, 0.5);
    officeCamera.lookAt(camCurrentLook);

    // 3. Renderer
    officeRenderer = new THREE.WebGLRenderer({
        antialias: true,
        powerPreference: 'high-performance',
        alpha: false
    });
    officeRenderer.setSize(width, height);
    officeRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    officeRenderer.shadowMap.enabled = false; // Masa gölge çizgilenme bug'ını tamamen bitirir!
    target.innerHTML = '';
    target.appendChild(officeRenderer.domElement);

    // 4. Orbit Controls
    if (typeof THREE.OrbitControls !== 'undefined') {
        officeControls = new THREE.OrbitControls(officeCamera, officeRenderer.domElement);
        officeControls.enableDamping = true;
        officeControls.dampingFactor = 0.06;
        officeControls.maxPolarAngle = Math.PI / 2.05;
        officeControls.minDistance = 2.0;
        officeControls.maxDistance = 22;
        officeControls.target.copy(camCurrentLook);
        officeControls.rotateSpeed = 0.85;
        officeControls.zoomSpeed = 1.0;
        officeControls.touches = {
            ONE: THREE.TOUCH.ROTATE,
            TWO: THREE.TOUCH.DOLLY_PAN
        };
    }

    // 5. Işıklandırma (Masa Parlama Bug'ı Sıfırlandı, Yumuşak Doğal Işık)
    setupSoftOfficeLighting();

    // 6. DUVAR ENGELİ KALDIRILMIŞ PENTHOUSE OFİS (Ön Duvar & Tavan Yok, %100 Açık Görünüm)
    buildLuxuryPenthouseOffice();

    // 7. PATRON EFE'NİN DEV MAKAMI VE ÇALIŞANLARIN BAĞIMSIZ ÖZEL MASALARI
    buildExecutiveBossDesk();
    buildIndividualEmployeeDesks();

    // 8. 🖨️ ÇOK FONKSİYONLU OFİS AĞ YAZICISI & FOTOKOPİ İSTASYONU
    buildOfficePrinterAndCopier();

    // 9. 👑 BAŞ KOLTUK / PATRON: EFE (Görkemli Makam Koltuğunda)
    buildBossEfe();

    // 10. EFE'NİN ARKASINDAKİ DEV İKİLİ DUVAR EKRANI (Canlı BTC + Kâr/Zarar)
    buildGiantWallDualScreen();

    // 11. 6 UZMAN ÇALIŞAN (Kendi Özel Masalarında, Monitör, Klavye ve Mouse ile Aktif Çalışma)
    buildSpecialistAgents();

    // 11. KÖŞE TUVALET (Açılır Kapı) & LAVABO (El Yıkama Aynalı Tezgah)
    buildCornerRestroomAndSink(-9.2, 0, -4.5);

    // 12. GENİŞLETİLMİŞ OTURMA & PLAYSTATION 5 LOUNGE (Ekstra Kanepeler, TV, PS5 Konsolu)
    buildExpandedLoungeAndPS5();

    // 13. SEMA VERLİ TÜRK ÇAYI KÖŞESİ
    buildTurkishTeaCorner(-5.8, 0, -4.2);

    // 14. KÖŞEYE ALINAN OYUN ALANI (Masa Tenisi, Langırt, İzleme Bankı)
    buildCornerGameArea();

    // 15. 🏓 ⚽ PATRONUN ARKADAŞLARI: MEHMET & BERAT (Sıfır İş, Goygoy, PS5, Çay, Langırt)
    buildFriendsMehmetAndBerat();

    // 16. Çapa Noktalarını DOM Elementlerine Bağla
    bindBubbleElements();

    officeInitialized = true;
    setTimeout(resizeOffice3D, 50);
    setTimeout(resizeOffice3D, 200);
    setTimeout(resizeOffice3D, 600);

    setOfficeCamera('boss');

    setTimeout(() => {
        triggerSpeech('boss', "Piyasayı tarayın beyler, acele yok! Disiplin #1 kuralımız.", 6000);
    }, 1200);

    setTimeout(() => {
        triggerSpeech('mehmet', "Berat PS5 kolunu hazırla kanka, rövanş maçı var!", 5000);
    }, 3500);

    if (!officeAnimFrameId) {
        animateOffice(0);
    }

    window.addEventListener('resize', resizeOffice3D);
    window.addEventListener('orientationchange', () => {
        setTimeout(resizeOffice3D, 100);
    });
}

// -------------------------------------------------------------
// IŞIKLANDIRMA SİSTEMİ (MASADA PARLAMA BUG'I SIFIR)
// -------------------------------------------------------------
function setupSoftOfficeLighting() {
    // 1. Doğal, yumuşak, gözü almayan ofis ortam ışığı
    const ambientLight = new THREE.AmbientLight(0xdce5f5, 0.95);
    officeScene.add(ambientLight);

    // 2. Yönlü difüze ışık (Gölgeler kapalı, çizgilenme yok)
    const ceilingLight = new THREE.DirectionalLight(0xfff8ee, 0.45);
    ceilingLight.position.set(3, 8, 4);
    officeScene.add(ceilingLight);

    // 3. Efe'nin arkasındaki duvara yumuşak estetik fon ışığı
    const backWallGlow = new THREE.PointLight(0x38bdf8, 0.5, 9);
    backWallGlow.position.set(0, 4.8, -5.8);
    officeScene.add(backWallGlow);

    // 4. Oyun ve Dinlenme Alanı Yumuşak Noktasal Işıkları
    const gameSpot = new THREE.PointLight(0x38bdf8, 0.5, 8);
    gameSpot.position.set(7.5, 3.8, -1.0);
    officeScene.add(gameSpot);

    const loungeSpot = new THREE.PointLight(0xf59e0b, 0.6, 8);
    loungeSpot.position.set(-7.0, 3.8, 1.5);
    officeScene.add(loungeSpot);
}

// -------------------------------------------------------------
// DUVAR ENGELİ OLMAYAN LÜKS PENTHOUSE OFİS
// (Ön Duvar & Tavan Kaldırıldı - Kamera Asla Takılmaz/Engellenmez)
// -------------------------------------------------------------
function buildLuxuryPenthouseOffice() {
    // 1. Zemin (Lüks Koyu Parke)
    const floorGeo = new THREE.PlaneGeometry(24, 20);
    const floorMat = new THREE.MeshLambertMaterial({ color: 0x121724 });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    officeScene.add(floor);

    // 2. Lüks Halı
    const rugGeo = new THREE.PlaneGeometry(13.0, 9.5);
    const rugMat = new THREE.MeshLambertMaterial({ color: 0x0a0f1c });
    const rug = new THREE.Mesh(rugGeo, rugMat);
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0, 0.015, 0);
    officeScene.add(rug);

    // 3. ARKA DUVAR (z = -6.2, Lüks Akustik Ahşap Çıtalar)
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(24, 7.5, 0.2), new THREE.MeshLambertMaterial({ color: 0x0f1422 }));
    backWall.position.set(0, 3.75, -6.2);
    officeScene.add(backWall);

    const slatMat = new THREE.MeshLambertMaterial({ color: 0x241a14 });
    for (let x = -11.5; x <= 11.5; x += 0.55) {
        if (x > -3.8 && x < 3.8) continue; // Dev ekranın arkasını boş bırak
        const slat = new THREE.Mesh(new THREE.BoxGeometry(0.12, 7.2, 0.05), slatMat);
        slat.position.set(x, 3.75, -6.08);
        officeScene.add(slat);
    }

    // 4. SOL VE SAĞ MİMARİ KESİT DUVARLAR (Sadece arka yarıda, kameranın önünü asla kapatmaz)
    const leftWallBack = new THREE.Mesh(new THREE.BoxGeometry(0.2, 6.5, 6.0), new THREE.MeshLambertMaterial({ color: 0x111624 }));
    leftWallBack.position.set(-11.5, 3.25, -3.2);
    officeScene.add(leftWallBack);

    const rightWallBack = new THREE.Mesh(new THREE.BoxGeometry(0.2, 6.5, 6.0), new THREE.MeshLambertMaterial({ color: 0x111624 }));
    rightWallBack.position.set(11.5, 3.25, -3.2);
    officeScene.add(rightWallBack);

    // Alçak lüks mimari süpürgelik bordürü (Ön tarafta şık ve ferah)
    const borderMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const leftBorder = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.40, 14.0), borderMat);
    leftBorder.position.set(-11.5, 0.20, 3.0);
    officeScene.add(leftBorder);

    const rightBorder = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.40, 14.0), borderMat);
    rightBorder.position.set(11.5, 0.20, 3.0);
    officeScene.add(rightBorder);

    const frontBorder = new THREE.Mesh(new THREE.BoxGeometry(23.0, 0.40, 0.15), borderMat);
    frontBorder.position.set(0, 0.20, 8.5);
    officeScene.add(frontBorder);
}

// -------------------------------------------------------------
// 👑 DEV DUVAR EKRANI: İKİLİ GÖRÜNÜM (BTC GRAFİĞİ + KÂR/ZARAR PnL)
// -------------------------------------------------------------
function buildGiantWallDualScreen() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    bigWallCtx = canvas.getContext('2d');

    renderBigWallScreenContent({
        btcPrice: '76,500',
        btcStatus: 'DEAD_CHOP (4s Bant: %0.40)',
        activePositions: []
    });

    bigWallTexture = new THREE.CanvasTexture(canvas);
    bigWallTexture.anisotropy = 4;

    const screenGeo = new THREE.PlaneGeometry(6.6, 2.8);
    const screenMat = new THREE.MeshBasicMaterial({ map: bigWallTexture });
    bigWallScreenMesh = new THREE.Mesh(screenGeo, screenMat);
    bigWallScreenMesh.position.set(0, 4.2, -6.05);
    officeScene.add(bigWallScreenMesh);

    const frame = new THREE.Mesh(new THREE.BoxGeometry(6.75, 2.95, 0.08), new THREE.MeshLambertMaterial({ color: 0x1e293b }));
    frame.position.set(0, 4.2, -6.1);
    officeScene.add(frame);
}

function renderBigWallScreenContent(info) {
    if (!bigWallCtx) return;
    const ctx = bigWallCtx;

    // Arka Plan
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, 1024, 512);

    // Ortadan Bölücü İnce Çizgi
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(512, 10);
    ctx.lineTo(512, 502);
    ctx.stroke();

    // ================= SOL PANEL: CANLI BTC (FUTURES) =================
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(15, 15, 482, 482);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 22px Inter, sans-serif';
    ctx.fillText('⚡ BTC/USDT FUTURES (4S REJİM)', 35, 52);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 38px monospace';
    ctx.fillText(`$${info.btcPrice || '76,500'}`, 35, 105);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '16px Inter, sans-serif';
    ctx.fillText(`Rejim: ${info.btcStatus || 'DEAD_CHOP (Bant: %0.40)'}`, 35, 138);

    // Stilize Mum Grafiği
    const candleData = [
        { o: 60, c: 90, h: 105, l: 45, up: true },
        { o: 90, c: 75, h: 110, l: 70, up: false },
        { o: 75, c: 120, h: 135, l: 65, up: true },
        { o: 120, c: 110, h: 140, l: 100, up: false },
        { o: 110, c: 145, h: 160, l: 105, up: true },
        { o: 145, c: 135, h: 155, l: 125, up: false },
        { o: 135, c: 175, h: 190, l: 130, up: true },
        { o: 175, c: 160, h: 180, l: 150, up: false },
        { o: 160, c: 195, h: 210, l: 155, up: true },
        { o: 195, c: 185, h: 200, l: 175, up: false },
        { o: 185, c: 220, h: 235, l: 180, up: true }
    ];

    const chartBaseY = 440;
    candleData.forEach((c, idx) => {
        const cx = 55 + idx * 38;
        const color = c.up ? '#10b981' : '#ef4444';
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, chartBaseY - c.h);
        ctx.lineTo(cx, chartBaseY - c.l);
        ctx.stroke();

        ctx.fillStyle = color;
        const bodyTop = chartBaseY - Math.max(c.o, c.c);
        const bodyHeight = Math.max(Math.abs(c.c - c.o), 4);
        ctx.fillRect(cx - 10, bodyTop, 20, bodyHeight);
    });

    // ================= SAĞ PANEL: AÇIK POZİSYONLAR & PnL =================
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(527, 15, 482, 482);

    ctx.fillStyle = '#f59e0b';
    ctx.font = 'bold 22px Inter, sans-serif';
    ctx.fillText('📊 AÇIK POZİSYON & PnL TAKİBİ', 547, 52);

    const positions = info.activePositions || [];
    if (positions.length === 0) {
        ctx.fillStyle = '#64748b';
        ctx.font = 'bold 20px Inter, sans-serif';
        ctx.fillText('💤 AKTİF İŞLEM YOK', 547, 180);
        ctx.font = '16px Inter, sans-serif';
        ctx.fillText('200+ Parite 15M Radar Taramasında.', 547, 215);
        ctx.fillText('Sermaye Koruma Kalkanı Devrede: %1.5 Risk', 547, 245);

        ctx.strokeStyle = '#1e293b';
        ctx.strokeRect(547, 280, 440, 160);
        ctx.fillStyle = '#38bdf8';
        ctx.font = '15px Inter, sans-serif';
        ctx.fillText('🏛️ Yatırım Komitesi: Chop Piyasada Beklemede', 567, 320);
        ctx.fillStyle = '#22c55e';
        ctx.fillText('🛡️ Kasa Kalkanı: %100 Hazır', 567, 360);
        ctx.fillStyle = '#94a3b8';
        ctx.fillText('📡 Tarama: Her 15 sn rotasyon canlı', 567, 400);
    } else {
        positions.slice(0, 2).forEach((pos, i) => {
            const cardY = 95 + i * 185;
            const pnl = Number(pos.unrealized_pnl_pct || 0);
            const isProfit = pnl >= 0;

            ctx.fillStyle = '#1e293b';
            ctx.fillRect(547, cardY, 442, 165);
            ctx.strokeStyle = isProfit ? '#10b981' : '#ef4444';
            ctx.lineWidth = 2;
            ctx.strokeRect(547, cardY, 442, 165);

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 22px Inter, sans-serif';
            ctx.fillText(`${pos.symbol || 'PARİTE'} ${pos.direction || 'LONG'} ${pos.leverage || '5'}x`, 567, cardY + 38);

            ctx.fillStyle = isProfit ? '#10b981' : '#ef4444';
            ctx.font = 'bold 32px monospace';
            const pnlStr = (isProfit ? '+' : '') + pnl.toFixed(2) + '%';
            ctx.fillText(pnlStr, 567, cardY + 85);

            ctx.fillStyle = '#94a3b8';
            ctx.font = '15px Inter, sans-serif';
            ctx.fillText(`Giriş: $${pos.entry_price || '0'} | Fiyat: $${pos.live_price || '0'}`, 567, cardY + 120);
            ctx.fillText(`Kâr: $${pos.pnl_usd || '0.00'} | Süre: ${pos.elapsed_str || '0m'}`, 567, cardY + 145);
        });
    }
}

// -------------------------------------------------------------
// SEMA VERLİ TÜRK ÇAYI KÖŞESİ
// -------------------------------------------------------------
function buildTurkishTeaCorner(x, y, z) {
    const teaGroup = new THREE.Group();
    teaGroup.position.set(x, y, z);

    const table = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.82, 1.0), new THREE.MeshLambertMaterial({ color: 0x271c14 }));
    table.position.y = 0.41;
    teaGroup.add(table);

    const semaverBase = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.22, 0.45, 16), new THREE.MeshLambertMaterial({ color: 0xd97706 }));
    semaverBase.position.set(-0.25, 1.05, 0);
    teaGroup.add(semaverBase);

    const demlik = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.18, 14), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    demlik.position.set(-0.25, 1.34, 0);
    teaGroup.add(demlik);

    const tray = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.02, 0.5), new THREE.MeshLambertMaterial({ color: 0xd4d4d8 }));
    tray.position.set(0.35, 0.83, 0);
    teaGroup.add(tray);

    const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xb91c1c, transmission: 0.7, transparent: true, opacity: 0.85 });
    [-0.15, 0.15].forEach((gx, i) => {
        const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.035, 0.10, 12), glassMat);
        glass.position.set(0.35 + gx, 0.88, (i % 2 === 0 ? 0.08 : -0.08));
        teaGroup.add(glass);
    });

    officeScene.add(teaGroup);
}

// -------------------------------------------------------------
// 🛋️ GENİŞLETİLMİŞ LOUNGE & PLAYSTATION 5 MERKEZİ
// (Ekstra Kanepeler, 65" TV, PS5 Konsolu, Oyun Ekranı)
// -------------------------------------------------------------
function buildExpandedLoungeAndPS5() {
    const loungeGroup = new THREE.Group();
    loungeGroup.position.set(-7.2, 0, 1.5);

    const sofaMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const sofaMat2 = new THREE.MeshLambertMaterial({ color: 0x283548 });

    // 1. ANA KANEPE (3 Kişilik Deri Kanepe - TV Karşısı)
    const sofa1 = new THREE.Group();
    sofa1.position.set(0, 0, -0.6);

    const s1Seat = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.28, 0.85), sofaMat);
    s1Seat.position.y = 0.35;
    sofa1.add(s1Seat);

    const s1Back = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.70, 0.22), sofaMat);
    s1Back.position.set(0, 0.72, -0.32);
    sofa1.add(s1Back);

    [-0.95, 0.95].forEach(sx => {
        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.50, 0.85), sofaMat);
        arm.position.set(sx, 0.50, 0);
        sofa1.add(arm);
    });
    loungeGroup.add(sofa1);

    // 2. EKSTRA KANEPE / BERJER (2 Kişilik Lüks Koltuk - Mehmet & Berat İçin)
    const sofa2 = new THREE.Group();
    sofa2.position.set(2.0, 0, 0.6);
    sofa2.rotation.y = -Math.PI / 2; // TV'ye ve ortaya dönük

    const s2Seat = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.28, 0.80), sofaMat2);
    s2Seat.position.y = 0.35;
    sofa2.add(s2Seat);

    const s2Back = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.70, 0.20), sofaMat2);
    s2Back.position.set(0, 0.72, -0.30);
    sofa2.add(s2Back);

    [-0.70, 0.70].forEach(sx => {
        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.50, 0.80), sofaMat2);
        arm.position.set(sx, 0.50, 0);
        sofa2.add(arm);
    });
    loungeGroup.add(sofa2);

    // 3. CAM SEHPA & PLAYSTATION KOLLARI
    const coffeeTable = new THREE.Group();
    coffeeTable.position.set(0, 0, 0.6);

    const tableLegMat = new THREE.MeshLambertMaterial({ color: 0x0f172a });
    const tableTop = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.04, 0.8), new THREE.MeshPhysicalMaterial({
        color: 0x38bdf8,
        transmission: 0.85,
        opacity: 0.7,
        transparent: true
    }));
    tableTop.position.y = 0.42;
    coffeeTable.add(tableTop);

    [[-0.55, -0.3], [0.55, -0.3], [-0.55, 0.3], [0.55, 0.3]].forEach(([lx, lz]) => {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.40, 12), tableLegMat);
        leg.position.set(lx, 0.20, lz);
        coffeeTable.add(leg);
    });

    // 🎮 PS5 Kolları Sehpa Üstünde
    [-0.2, 0.2].forEach(px => {
        const ctrl = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.08), new THREE.MeshLambertMaterial({ color: 0xffffff }));
        ctrl.position.set(px, 0.45, 0);
        coffeeTable.add(ctrl);
    });
    loungeGroup.add(coffeeTable);

    // 4. MEDYA SEHPASI & 65" FLAT TV & PLAYSTATION 5 KONSOLU
    const tvStand = new THREE.Group();
    tvStand.position.set(-2.5, 0, 0.5);
    tvStand.rotation.y = Math.PI / 2; // Kanepelere dönük

    // Medya Konsolu
    const standMesh = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.48, 0.55), new THREE.MeshLambertMaterial({ color: 0x0f172a }));
    standMesh.position.y = 0.24;
    tvStand.add(standMesh);

    // PS5 Konsolu (Beyaz kavisli tasarım + mavi LED)
    const ps5 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.38, 0.26), new THREE.MeshLambertMaterial({ color: 0xf8fafc }));
    ps5.position.set(0.7, 0.67, 0);
    tvStand.add(ps5);

    const ps5Led = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.35, 0.02), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
    ps5Led.position.set(0.76, 0.67, 0);
    tvStand.add(ps5Led);

    // 65" TV Ekranı
    const tvFrame = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.3, 0.06), new THREE.MeshLambertMaterial({ color: 0x020617 }));
    tvFrame.position.set(0, 1.55, 0);
    tvStand.add(tvFrame);

    // TV Ekranı Dinamik Canvas (Canlı Video Oyunu Animasyonu)
    tvScreenCanvas = document.createElement('canvas');
    tvScreenCanvas.width = 512;
    tvScreenCanvas.height = 256;
    tvScreenCtx = tvScreenCanvas.getContext('2d');
    renderTVScreenGraphics(0);

    tvScreenTexture = new THREE.CanvasTexture(tvScreenCanvas);
    const tvDisplay = new THREE.Mesh(new THREE.PlaneGeometry(2.1, 1.2), new THREE.MeshBasicMaterial({ map: tvScreenTexture }));
    tvDisplay.position.set(0, 1.55, 0.035);
    tvStand.add(tvDisplay);

    loungeGroup.add(tvStand);
    officeScene.add(loungeGroup);
}

// TV Ekranında Animasyonlu Futbol/Oyun Döngüsü
function renderTVScreenGraphics(time) {
    if (!tvScreenCtx) return;
    const ctx = tvScreenCtx;

    // Yeşil Futbol Sahası
    ctx.fillStyle = '#15803d';
    ctx.fillRect(0, 0, 512, 256);

    // Beyaz Saha Çizgileri
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 4;
    ctx.strokeRect(20, 20, 472, 216);

    ctx.beginPath();
    ctx.moveTo(256, 20);
    ctx.lineTo(256, 236);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(256, 128, 45, 0, Math.PI * 2);
    ctx.stroke();

    // Hareket Eden Oyuncular & Top
    const ballX = 256 + Math.sin(time * 0.003) * 120;
    const ballY = 128 + Math.cos(time * 0.005) * 60;

    // Oyuncu 1 (Mehmet - Kırmızı)
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(ballX - 35, ballY - 10, 12, 0, Math.PI * 2);
    ctx.fill();

    // Oyuncu 2 (Berat - Mavi)
    ctx.fillStyle = '#3b82f6';
    ctx.beginPath();
    ctx.arc(ballX + 35, ballY + 10, 12, 0, Math.PI * 2);
    ctx.fill();

    // Top
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(ballX, ballY, 7, 0, Math.PI * 2);
    ctx.fill();

    // PS5 Skor Panosu
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(170, 25, 172, 34);
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 16px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('MEHMET 2 - 1 BERAT', 256, 48);

    if (tvScreenTexture) tvScreenTexture.needsUpdate = true;
}

// -------------------------------------------------------------
// 🚻 KÖŞE TUVALET (AÇILIR KAPI) & AYNALI LAVABO (EL YIKAMA)
// -------------------------------------------------------------
function buildCornerRestroomAndSink(x, y, z) {
    const restroomGroup = new THREE.Group();
    restroomGroup.position.set(x, y, z);

    // 1. TUVALET KABİNİ (Sol ve arka duvarlar)
    const cabinMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.5, 1.6), cabinMat);
    cabin.position.y = 1.25;
    restroomGroup.add(cabin);

    // İç Mekan / Klozet (Kapı açıldığında içerisi görünür)
    const toiletBase = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.18, 0.44, 14), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    toiletBase.position.set(0, 0.22, -0.35);
    restroomGroup.add(toiletBase);

    const toiletTank = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.45, 0.22), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    toiletTank.position.set(0, 0.55, -0.65);
    restroomGroup.add(toiletTank);

    // 2. AÇILIR-KAPANIR KABİN KAPISI (Menteşesi kenarda döner!)
    wcDoorGroup = new THREE.Group();
    wcDoorGroup.position.set(-0.70, 0, 0.81); // Menteşe noktası

    const doorLeaf = new THREE.Mesh(new THREE.BoxGeometry(1.35, 2.2, 0.05), new THREE.MeshLambertMaterial({ color: 0x334155 }));
    doorLeaf.position.set(0.675, 1.15, 0); // Menteşeden sağa uzanır
    wcDoorGroup.add(doorLeaf);

    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.14, 0.06), new THREE.MeshLambertMaterial({ color: 0xd4d4d8 }));
    handle.position.set(1.20, 1.05, 0.04);
    wcDoorGroup.add(handle);

    restroomGroup.add(wcDoorGroup);

    // Tabela: "WC / LAVABO"
    const sign = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.22, 0.06), new THREE.MeshBasicMaterial({ color: 0x0284c7 }));
    sign.position.set(0, 2.35, 0.82);
    restroomGroup.add(sign);

    // Dolu/Boş Durum Işığı (Yeşil = Boş, Kırmızı = Dolu)
    portableWcLight = new THREE.PointLight(0x10b981, 1.0, 3.5);
    portableWcLight.position.set(0, 2.35, 0.95);
    restroomGroup.add(portableWcLight);

    // 3. 🚰 AYNALI LAVABO TEZGAHI (TUVALETİN HEMEN YANINDA)
    const sinkGroup = new THREE.Group();
    sinkGroup.position.set(1.6, 0, 0); // Kabinin hemen sağında

    // Ahşap Dolaplı Tezgah
    const vanity = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.84, 0.65), new THREE.MeshLambertMaterial({ color: 0x0f172a }));
    vanity.position.y = 0.42;
    sinkGroup.add(vanity);

    // Beyaz Porselen Lavabo Çanağı
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.18, 0.14, 16), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    basin.position.set(0, 0.90, 0);
    sinkGroup.add(basin);

    // Krom Modern Kuğu Batarya
    const faucet = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.22, 12), new THREE.MeshLambertMaterial({ color: 0xd4d4d8 }));
    faucet.position.set(0, 1.05, -0.18);
    sinkGroup.add(faucet);

    // Duvarda Ayna
    const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.70, 0.95, 0.02), new THREE.MeshPhysicalMaterial({
        color: 0xe2e8f0,
        metalness: 0.95,
        roughness: 0.1
    }));
    mirror.position.set(0, 1.70, -0.32);
    sinkGroup.add(mirror);

    // Sabunluk
    const soap = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.12, 12), new THREE.MeshLambertMaterial({ color: 0x38bdf8 }));
    soap.position.set(0.30, 0.90, 0);
    sinkGroup.add(soap);

    restroomGroup.add(sinkGroup);
    officeScene.add(restroomGroup);
}

// -------------------------------------------------------------
// KÖŞEYE ALINAN OYUN ALANI (PING-PONG & LANGIRT & BANK)
// -------------------------------------------------------------
function buildCornerGameArea() {
    // 🏓 Masa Tenisi (Sağ arka köşede)
    const ppGroup = new THREE.Group();
    ppGroup.position.set(8.2, 0, -3.2);

    const ppTop = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.06, 1.4), new THREE.MeshLambertMaterial({ color: 0x0284c7 }));
    ppTop.position.y = 0.76;
    ppGroup.add(ppTop);

    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const centerLine = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.005, 0.03), lineMat);
    centerLine.position.set(0, 0.795, 0);
    ppGroup.add(centerLine);

    const net = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.16, 1.5), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 }));
    net.position.set(0, 0.87, 0);
    ppGroup.add(net);

    const legMat = new THREE.MeshLambertMaterial({ color: 0x0f172a });
    [[-1.0, -0.55], [1.0, -0.55], [-1.0, 0.55], [1.0, 0.55]].forEach(([lx, lz]) => {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.76, 12), legMat);
        leg.position.set(lx, 0.38, lz);
        ppGroup.add(leg);
    });
    officeScene.add(ppGroup);

    // ⚽ Langırt Masası (Hemen yanında)
    const foosballGroup = new THREE.Group();
    foosballGroup.position.set(8.2, 0, 0.5);

    const box = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.40, 0.95), new THREE.MeshLambertMaterial({ color: 0x991b1b }));
    box.position.y = 0.68;
    foosballGroup.add(box);

    const pitch = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.75), new THREE.MeshBasicMaterial({ color: 0x15803d }));
    pitch.rotation.x = -Math.PI / 2;
    pitch.position.set(0, 0.75, 0);
    foosballGroup.add(pitch);

    [[-0.65, -0.38], [0.65, -0.38], [-0.65, 0.38], [0.65, 0.38]].forEach(([lx, lz]) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.70, 0.08), legMat);
        leg.position.set(lx, 0.35, lz);
        foosballGroup.add(leg);
    });
    officeScene.add(foosballGroup);

    // 🛋️ İzleme Bankı (Mehmet & Berat Oyun Seyir Koltuğu)
    const benchGroup = new THREE.Group();
    benchGroup.position.set(6.2, 0, 2.5);
    benchGroup.rotation.y = -Math.PI / 3;

    const benchSeat = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.12, 0.5), new THREE.MeshLambertMaterial({ color: 0x1e293b }));
    benchSeat.position.y = 0.42;
    benchGroup.add(benchSeat);

    const benchBack = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.45, 0.1), new THREE.MeshLambertMaterial({ color: 0x1e293b }));
    benchBack.position.set(0, 0.65, -0.2);
    benchGroup.add(benchBack);

    officeScene.add(benchGroup);
}

// -------------------------------------------------------------
// TRADING MASASI (TEK RENK, ASLA RENK DEĞİŞTİRMEYEN LÜKS MAT FÜME)
// -------------------------------------------------------------
// -------------------------------------------------------------
// TRADING MASASI GERİYE DÖNÜK UYUMLULUK KÖPRÜSÜ
// -------------------------------------------------------------
function buildTradingDesk() {
    buildExecutiveBossDesk();
    buildIndividualEmployeeDesks();
    buildOfficePrinterAndCopier();
}

// -------------------------------------------------------------
// 👑 PATRON EFE'NİN DEV MAKAM MASASI (Executive Patron Desk)
// -------------------------------------------------------------
function buildExecutiveBossDesk() {
    const bossDeskGroup = new THREE.Group();
    bossDeskGroup.position.set(0, 0, -3.2);

    // 1. Ana Tabla (Genişlik: 3.2m, Derinlik: 1.35m, Yükseklik: 0.82m)
    // Lüks Koyu Abanoz / Ceviz Ahşap
    const topMat = new THREE.MeshLambertMaterial({ color: 0x1a1412 });
    const topGeo = new THREE.BoxGeometry(3.2, 0.08, 1.35);
    const tableTop = new THREE.Mesh(topGeo, topMat);
    tableTop.position.y = 0.82;
    bossDeskGroup.add(tableTop);

    // 2. Altın / Pirinç Lüks Pah Çıtası (Gold Edge Trim)
    const goldMat = new THREE.MeshLambertMaterial({ color: 0xd4af37 });
    const goldTrim = new THREE.Mesh(new THREE.BoxGeometry(3.23, 0.02, 1.38), goldMat);
    goldTrim.position.y = 0.85;
    bossDeskGroup.add(goldTrim);

    // 3. Ön Perde Paneli (Modesty Panel - Odaya bakan ön cephe)
    const panelMat = new THREE.MeshLambertMaterial({ color: 0x111622 });
    const frontPanel = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.65, 0.04), panelMat);
    frontPanel.position.set(0, 0.45, 0.60);
    bossDeskGroup.add(frontPanel);

    // Ön panel üstü altın geometrik motif çıtası
    const panelGoldAccent = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.03, 0.05), goldMat);
    panelGoldAccent.position.set(0, 0.65, 0.61);
    bossDeskGroup.add(panelGoldAccent);

    // 4. Masif Yan Keson ve Ayak Gövdeleri (Sol ve Sağ Yan Kaideler)
    const pedestalMat = new THREE.MeshLambertMaterial({ color: 0x151b28 });
    [-1.3, 1.3].forEach(px => {
        const ped = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.78, 1.25), pedestalMat);
        ped.position.set(px, 0.39, 0);
        bossDeskGroup.add(ped);

        // Çekmece Altın Kulpları
        [0.25, 0.45, 0.65].forEach(hy => {
            const handle = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.025, 0.04), goldMat);
            handle.position.set(px, hy, -0.63);
            bossDeskGroup.add(handle);
        });
    });

    // 5. Lüks Siyah Deri Masa Sümeni (Blotter Pad - Ortada)
    const blotterMat = new THREE.MeshLambertMaterial({ color: 0x0a0c10 });
    const blotter = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.012, 0.75), blotterMat);
    blotter.position.set(0, 0.865, -0.15);
    bossDeskGroup.add(blotter);

    // 6. Patronun Çift Kavisli Ultra-Wide Monitörleri (Dual Curved Displays)
    const screenStand = new THREE.Mesh(new THREE.BoxGeometry(0.80, 0.03, 0.04), goldMat);
    screenStand.position.set(0, 1.15, 0.30);
    bossDeskGroup.add(screenStand);

    const screenPost = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.35, 16), goldMat);
    screenPost.position.set(0, 0.98, 0.30);
    bossDeskGroup.add(screenPost);

    // Sol Monitör (Canlı Mum Grafiği - Yeşil/Kırmızı Matris)
    const leftScreenMat = new THREE.MeshBasicMaterial({ color: 0x059669 });
    const leftScreen = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.45, 0.025), leftScreenMat);
    leftScreen.position.set(-0.44, 1.25, 0.28);
    leftScreen.rotation.y = -0.16;
    bossDeskGroup.add(leftScreen);

    // Sağ Monitör (Emir Defteri ve Kuantum Portföy Ekranı - Cyan/Mavi)
    const rightScreenMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const rightScreen = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.45, 0.025), rightScreenMat);
    rightScreen.position.set(0.44, 1.25, 0.28);
    rightScreen.rotation.y = 0.16;
    bossDeskGroup.add(rightScreen);

    // 7. Mekanik Kablosuz Klavye ve Hassas Mouse
    const bossKb = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.015, 0.14), new THREE.MeshLambertMaterial({ color: 0x1f2937 }));
    bossKb.position.set(-0.06, 0.875, -0.25);
    bossDeskGroup.add(bossKb);

    const bossMouse = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.02, 0.10), new THREE.MeshLambertMaterial({ color: 0x111827 }));
    bossMouse.position.set(0.26, 0.875, -0.25);
    bossDeskGroup.add(bossMouse);

    const mouseGoldRing = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.005, 0.04), goldMat);
    mouseGoldRing.position.set(0.26, 0.885, -0.25);
    bossDeskGroup.add(mouseGoldRing);

    // 8. Altın Vurgulu Porselen Espresso / Kahve Kupası
    const mugMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const mug = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.04, 0.09, 16), mugMat);
    mug.position.set(0.70, 0.90, -0.20);
    bossDeskGroup.add(mug);

    const mugRim = new THREE.Mesh(new THREE.CylinderGeometry(0.046, 0.046, 0.01, 16), goldMat);
    mugRim.position.set(0.70, 0.945, -0.20);
    bossDeskGroup.add(mugRim);

    // 9. Modern Pirinç Masa Lambası
    const lampBase = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.015, 16), goldMat);
    lampBase.position.set(-0.95, 0.87, -0.15);
    bossDeskGroup.add(lampBase);

    const lampArm = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.38, 12), goldMat);
    lampArm.position.set(-0.95, 1.05, -0.15);
    bossDeskGroup.add(lampArm);

    const lampShade = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.12, 16), goldMat);
    lampShade.position.set(-0.90, 1.20, -0.15);
    lampShade.rotation.z = -Math.PI / 4;
    bossDeskGroup.add(lampShade);

    // 10. Altın İsimlik: "👑 PATRON: EFE" (Odaya dönük ön kısımda)
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#b45309';
    ctx.fillRect(0, 0, 512, 128);
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 8;
    ctx.strokeRect(6, 6, 500, 116);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 44px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('👑 PATRON: EFE', 256, 80);

    const plateTex = new THREE.CanvasTexture(canvas);
    const plate = new THREE.Mesh(new THREE.BoxGeometry(0.70, 0.16, 0.08), new THREE.MeshLambertMaterial({ map: plateTex }));
    plate.position.set(0, 0.92, 0.50);
    plate.rotation.x = -0.25;
    bossDeskGroup.add(plate);

    officeScene.add(bossDeskGroup);
}

// -------------------------------------------------------------
// 💼 6 UZMAN ÇALIŞANIN BAĞIMSIZ ÖZEL MASALARI (Individual Workstations)
// -------------------------------------------------------------
function buildIndividualEmployeeDesks() {
    const desksGroup = new THREE.Group();

    // 1. Orta Koridor Lüks Lacivert & Altın Yolluk Halısı
    const runnerGeo = new THREE.PlaneGeometry(1.6, 5.8);
    const runnerMat = new THREE.MeshLambertMaterial({ color: 0x0f1c30 });
    const runner = new THREE.Mesh(runnerGeo, runnerMat);
    runner.rotation.x = -Math.PI / 2;
    runner.position.set(0, 0.018, 0.0);
    desksGroup.add(runner);

    const goldBorderGeo = new THREE.PlaneGeometry(1.66, 5.86);
    const goldBorderMat = new THREE.MeshLambertMaterial({ color: 0xb45309 });
    const goldBorder = new THREE.Mesh(goldBorderGeo, goldBorderMat);
    goldBorder.rotation.x = -Math.PI / 2;
    goldBorder.position.set(0, 0.016, 0.0);
    desksGroup.add(goldBorder);

    // Masa Koordinatları:
    // Batı Sırası (Sol): Scanner, TA, Quant (x = -1.85, z = -1.8, 0.0, 1.8) -> Çalışanlar x = -2.55'te oturur, Doğuya (+X) bakar
    // Doğu Sırası (Sağ): Chief, Risk, News (x = 1.85, z = -1.8, 0.0, 1.8) -> Çalışanlar x = 2.55'te oturur, Batıya (-X) bakar
    const deskConfigs = [
        { id: 'scanner', x: -1.85, z: -1.8, isWest: true },
        { id: 'ta',      x: -1.85, z:  0.0, isWest: true },
        { id: 'quant',   x: -1.85, z:  1.8, isWest: true },
        { id: 'chief',   x:  1.85, z: -1.8, isWest: false },
        { id: 'risk',    x:  1.85, z:  0.0, isWest: false },
        { id: 'news',    x:  1.85, z:  1.8, isWest: false }
    ];

    const deskTopMat = new THREE.MeshLambertMaterial({ color: 0x1e2636 });
    const legMat = new THREE.MeshLambertMaterial({ color: 0x0f172a });
    const panelMat = new THREE.MeshLambertMaterial({ color: 0x161e2e });
    const cabinetMat = new THREE.MeshLambertMaterial({ color: 0x131a26 });
    const silverMat = new THREE.MeshLambertMaterial({ color: 0x94a3b8 });

    deskConfigs.forEach(cfg => {
        const singleDesk = new THREE.Group();
        singleDesk.position.set(cfg.x, 0, cfg.z);

        // Tabla: Genişlik (X): 0.80m, Uzunluk (Z): 1.30m, Kalınlık: 0.04m, Yükseklik: 0.76m
        const top = new THREE.Mesh(new THREE.BoxGeometry(0.80, 0.04, 1.30), deskTopMat);
        top.position.y = 0.76;
        singleDesk.add(top);

        // 4 Sağlam Çelik Ayak
        [[-0.36, -0.60], [0.36, -0.60], [-0.36, 0.60], [0.36, 0.60]].forEach(([lx, lz]) => {
            const leg = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.74, 0.045), legMat);
            leg.position.set(lx, 0.37, lz);
            singleDesk.add(leg);
        });

        // Modesty Panel (Koridor tarafındaki ön perde paneli)
        const panelX = cfg.isWest ? 0.37 : -0.37;
        const panel = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.38, 1.20), panelMat);
        panel.position.set(panelX, 0.50, 0);
        singleDesk.add(panel);

        // 3 Çekmeceli Yan Keson Dolabı (Under-desk Pedestal Cabinet)
        const cabX = cfg.isWest ? -0.18 : 0.18;
        const cabZ = -0.38;
        const cab = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.54, 0.44), cabinetMat);
        cab.position.set(cabX, 0.27, cabZ);
        singleDesk.add(cab);

        // Çekmece Metal Kulpları
        [0.14, 0.28, 0.42].forEach(cy => {
            const handle = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.02, 0.02), silverMat);
            handle.position.set(cabX, cy, cfg.isWest ? cabZ + 0.23 : cabZ - 0.23);
            singleDesk.add(handle);
        });

        // Masaüstü Aksesuarları: Kalemlik & Sticky Notlar
        const penCup = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.08, 12), silverMat);
        penCup.position.set(cfg.isWest ? 0.25 : -0.25, 0.82, 0.52);
        singleDesk.add(penCup);

        const notes = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.02, 0.08), new THREE.MeshBasicMaterial({ color: 0xfef08a }));
        notes.position.set(cfg.isWest ? 0.25 : -0.25, 0.79, 0.38);
        singleDesk.add(notes);

        desksGroup.add(singleDesk);
    });

    // Canlı İşlem Balonunun Çapa Noktası (Makam masası ile çalışanlar arasındaki koridor)
    bubbleAnchors.trade.pos = new THREE.Vector3(0, 1.5, 0);

    officeScene.add(desksGroup);
}

// -------------------------------------------------------------
// 🖨️ ÇOK FONKSİYONLU KURUMSAL OFİS AĞ YAZICISI & FOTOKOPİ İSTASYONU
// -------------------------------------------------------------
function buildOfficePrinterAndCopier() {
    const printerGroup = new THREE.Group();
    printerGroup.position.set(-4.5, 0, -2.5);

    // 1. Ana Gövde (Ağır Hizmet Kurumsal Fotokopi/Yazıcı Kasası)
    const bodyMat = new THREE.MeshLambertMaterial({ color: 0xe2e8f0 }); // Mat Ofis Beyazı/Açık Gri
    const darkMat = new THREE.MeshLambertMaterial({ color: 0x1e293b }); // Koyu Antrasit Detaylar
    const accentMat = new THREE.MeshLambertMaterial({ color: 0x0284c7 });

    const baseCabinet = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.72, 0.72), bodyMat);
    baseCabinet.position.y = 0.36;
    printerGroup.add(baseCabinet);

    // Kağıt Besleme Çekmeceleri (Kaset 1 & Kaset 2)
    [0.20, 0.45].forEach(dy => {
        const drawerLine = new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.015, 0.71), darkMat);
        drawerLine.position.y = dy;
        printerGroup.add(drawerLine);

        const drawerHandle = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.03, 0.02), darkMat);
        drawerHandle.position.set(0, dy + 0.08, 0.37);
        printerGroup.add(drawerHandle);
    });

    // 2. Üst Tarayıcı Camı ve ADF Otomatik Belge Besleyici
    const scannerBed = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.16, 0.72), darkMat);
    scannerBed.position.y = 0.80;
    printerGroup.add(scannerBed);

    const adfLid = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.12, 0.65), bodyMat);
    adfLid.position.set(0, 0.94, 0);
    printerGroup.add(adfLid);

    // 3. Dokunmatik Renkli Kontrol Paneli (Tilted Touchscreen)
    const screenFrame = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.18, 0.03), darkMat);
    screenFrame.position.set(0.32, 0.98, 0.38);
    screenFrame.rotation.x = -Math.PI / 4;
    printerGroup.add(screenFrame);

    const touchScreen = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.01), new THREE.MeshBasicMaterial({ color: 0x0284c7 }));
    touchScreen.position.set(0.32, 0.985, 0.39);
    touchScreen.rotation.x = -Math.PI / 4;
    printerGroup.add(touchScreen);

    // 4. Çıktı Tepsisi ve Üstündeki Analiz/İşlem Raporu Çıktıları
    const outputTray = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.02, 0.36), darkMat);
    outputTray.position.set(-0.52, 0.68, 0.10);
    printerGroup.add(outputTray);

    // Çıkan A4 Rapor Kağıdı
    const paperMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const printedSheet = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.005, 0.24), paperMat);
    printedSheet.position.set(-0.50, 0.70, 0.10);
    printerGroup.add(printedSheet);

    // Çıktı kağıdı üstündeki finansal veri satırları (Grafik çizgileri)
    const chartLine = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.006, 0.03), new THREE.MeshBasicMaterial({ color: 0x16a34a }));
    chartLine.position.set(-0.50, 0.705, 0.08);
    printerGroup.add(chartLine);

    // 5. LED Durum Göstergeleri (Hazır / Ağ Aktif)
    const greenLed = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.01, 12), new THREE.MeshBasicMaterial({ color: 0x22c55e }));
    greenLed.position.set(0.12, 0.89, 0.37);
    greenLed.rotation.x = Math.PI / 2;
    printerGroup.add(greenLed);

    const blueLed = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.01, 12), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
    blueLed.position.set(0.16, 0.89, 0.37);
    blueLed.rotation.x = Math.PI / 2;
    printerGroup.add(blueLed);

    // 6. Yanında Yedek A4 Kağıt Kutusu ve Belge İmha / Geri Dönüşüm Kutusu
    const paperBox = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.32, 0.30), new THREE.MeshLambertMaterial({ color: 0xb45309 }));
    paperBox.position.set(-0.70, 0.16, -0.25);
    printerGroup.add(paperBox);

    const shredderBin = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.50, 0.32), darkMat);
    shredderBin.position.set(0.70, 0.25, 0.15);
    printerGroup.add(shredderBin);

    const shredderSlot = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.015, 0.02), accentMat);
    shredderSlot.position.set(0.70, 0.51, 0.15);
    printerGroup.add(shredderSlot);

    officeScene.add(printerGroup);
}

// -------------------------------------------------------------
// 👑 BAŞ KOLTUK / PATRON: EFE (GÖRKEMLİ MAKAM KOLTUĞUNDA)
// -------------------------------------------------------------
function buildBossEfe() {
    // 1. Patron Lüks Deri Makam Koltuğu (z = -4.0, Masaya ve Odaya Bakar)
    const bossChair = new THREE.Group();
    bossChair.position.set(0, 0, -4.0);

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.14, 0.75), new THREE.MeshLambertMaterial({ color: 0x0f1117 }));
    seat.position.y = 0.44;
    bossChair.add(seat);

    const back = new THREE.Mesh(new THREE.BoxGeometry(0.85, 1.15, 0.16), new THREE.MeshLambertMaterial({ color: 0x0f1117 }));
    back.position.set(0, 1.05, -0.34);
    bossChair.add(back);

    [-0.45, 0.45].forEach(ax => {
        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.48, 0.65), new THREE.MeshLambertMaterial({ color: 0xd4af37 }));
        arm.position.set(ax, 0.66, 0);
        bossChair.add(arm);
    });

    const chairBase = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.44, 16), new THREE.MeshLambertMaterial({ color: 0xd4af37 }));
    chairBase.position.y = 0.22;
    bossChair.add(chairBase);
    officeScene.add(bossChair);

    // 2. Patron Efe Karakteri (Özel Dikim Siyah Takım Elbise)
    bossGroup = new THREE.Group();
    bossGroup.position.set(0, 0, -4.0);

    const suitMat = new THREE.MeshLambertMaterial({ color: 0x090d16 });
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xfbd0b0 });

    // 🦵 Bacaklar: Üst Bacak Yere Tam Paralel, Alt Bacak Yere Dik İner!
    const thighs = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.14, 0.40), suitMat);
    thighs.position.set(0, 0.44, 0.20);
    bossGroup.add(thighs);

    const calves = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.40, 0.14), suitMat);
    calves.position.set(0, 0.20, 0.40);
    bossGroup.add(calves);

    // Gövde
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.60, 0.32), suitMat);
    torso.position.y = 0.74;
    bossGroup.add(torso);

    const collar = new THREE.Mesh(new THREE.BoxGeometry(0.20, 0.12, 0.02), new THREE.MeshLambertMaterial({ color: 0xffffff }));
    collar.position.set(0, 0.95, 0.17);
    bossGroup.add(collar);

    const tie = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.32, 0.025), new THREE.MeshLambertMaterial({ color: 0xb91c1c }));
    tie.position.set(0, 0.80, 0.18);
    bossGroup.add(tie);

    // Kollar (Makam masasında klavye ve fareyi yönetir)
    const bossLeftArm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.45, 0.12), suitMat);
    bossLeftArm.position.set(-0.35, 0.72, 0.18);
    bossLeftArm.rotation.x = Math.PI / 3.0;
    bossGroup.add(bossLeftArm);

    const bossRightArm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.45, 0.12), suitMat);
    bossRightArm.position.set(0.35, 0.72, 0.18);
    bossRightArm.rotation.x = Math.PI / 3.0;
    bossGroup.add(bossRightArm);

    // Kafa
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.20, 0);

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.34, 0.28), skinMat);
    headGroup.add(head);

    const hair = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.12, 0.30), new THREE.MeshLambertMaterial({ color: 0x171717 }));
    hair.position.set(0, 0.18, 0);
    headGroup.add(hair);

    bossHeadMesh = headGroup;
    bossGroup.add(headGroup);

    // Dönen Sims Plumbob'u
    buildSimsPlumbob(bossGroup);

    bubbleAnchors.boss.pos = new THREE.Vector3(0, 2.45, -4.0);
    officeScene.add(bossGroup);
}

function buildSimsPlumbob(parentGroup) {
    const plumbobGeo = new THREE.OctahedronGeometry(0.18, 0);
    plumbobGeo.scale(0.85, 1.7, 0.85);

    const plumbobMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
    plumbobMesh = new THREE.Mesh(plumbobGeo, plumbobMat);
    plumbobMesh.position.set(0, 2.05, -0.02);
    parentGroup.add(plumbobMesh);
}

function buildBossDeskItems(parentGroup) {
    // Tüm masaüstü ögeleri (Çift Kavisli Ekranlar, Altın İsimlik, Mekanik Klavye, Mouse, Espresso Kupası) buildExecutiveBossDesk içerisinde yer almaktadır.
}

// -------------------------------------------------------------
// 6 UZMAN AJAN (KENDİ ÖZEL MASALARINDA, AKTİF VE DİKKATLİ ÇALIŞMA)
// -------------------------------------------------------------
function buildSpecialistAgents() {
    const agentConfigs = [
        {
            id: 'scanner',
            name: 'Scanner Ajanı',
            seatPos: [-2.55, 0, -1.8],
            seatRotY: Math.PI / 2, // Masasına ve Doğuya (+X) dönük
            deskPos: [-1.85, 0.76, -1.8],
            suitColor: 0x0284c7,
            hairColor: 0x3f3f46,
            screenColor: 0x0369a1,
            hasGlasses: true
        },
        {
            id: 'ta',
            name: 'Teknik Analist',
            seatPos: [-2.55, 0, 0.0],
            seatRotY: Math.PI / 2, // Masasına ve Doğuya (+X) dönük
            deskPos: [-1.85, 0.76, 0.0],
            suitColor: 0x9333ea,
            hairColor: 0x78350f,
            screenColor: 0x7e22ce,
            hasGlasses: false
        },
        {
            id: 'quant',
            name: 'Kuant Simülasyon Uzmanı',
            seatPos: [-2.55, 0, 1.8],
            seatRotY: Math.PI / 2, // Masasına ve Doğuya (+X) dönük
            deskPos: [-1.85, 0.76, 1.8],
            suitColor: 0x4f46e5,   // Indigo Kuant Takım Elbisesi
            hairColor: 0x1e1b4b,
            screenColor: 0x6366f1, // Indigo/Cyan Kuant Simülasyon Ekranı
            hasGlasses: true
        },
        {
            id: 'chief',
            name: 'Baş Stratejist',
            seatPos: [2.55, 0, -1.8],
            seatRotY: -Math.PI / 2, // Masasına ve Batıya (-X) dönük
            deskPos: [1.85, 0.76, -1.8],
            suitColor: 0x059669,
            hairColor: 0x52525b,
            screenColor: 0x10b981,
            hasGlasses: true
        },
        {
            id: 'risk',
            name: 'Risk Şefi',
            seatPos: [2.55, 0, 0.0],
            seatRotY: -Math.PI / 2, // Masasına ve Batıya (-X) dönük
            deskPos: [1.85, 0.76, 0.0],
            suitColor: 0xdc2626,
            hairColor: 0x18181b,
            screenColor: 0xef4444,
            hasGlasses: false
        },
        {
            id: 'news',
            name: 'Haber & Makro',
            seatPos: [2.55, 0, 1.8],
            seatRotY: -Math.PI / 2, // Masasına ve Batıya (-X) dönük
            deskPos: [1.85, 0.76, 1.8],
            suitColor: 0xea580c,
            hairColor: 0x451a03,
            screenColor: 0xf97316,
            hasGlasses: true
        }
    ];

    agentConfigs.forEach(cfg => {
        createSingleWorker(cfg);
    });
}

function createSingleWorker(cfg) {
    const isRightSide = cfg.seatPos[0] > 0;

    // 1. BAĞIMSIZ DÖNER SANDALYE (Masada sabit kalır, eleman kalkarken döner)
    const chairGroup = new THREE.Group();
    chairGroup.position.set(...cfg.seatPos);
    chairGroup.rotation.y = cfg.seatRotY;

    const chairSeat = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.08, 0.55), new THREE.MeshLambertMaterial({ color: 0x1e293b }));
    chairSeat.position.y = 0.44;
    chairGroup.add(chairSeat);

    const chairBack = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.65, 0.08), new THREE.MeshLambertMaterial({ color: 0x1e293b }));
    chairBack.position.set(0, 0.80, -0.27);
    chairGroup.add(chairBack);

    const chairLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.44, 12), new THREE.MeshLambertMaterial({ color: 0x475569 }));
    chairLeg.position.y = 0.22;
    chairGroup.add(chairLeg);

    officeScene.add(chairGroup);

    // 2. MONİTÖRLER VE MOUSE (YÖNLERİ ELEMANA BAKIYOR!)
    buildWorkerDeskEquipment(cfg, isRightSide);

    // 3. KARAKTER MODELİ
    const agentGroup = new THREE.Group();
    agentGroup.position.set(...cfg.seatPos);
    agentGroup.rotation.y = cfg.seatRotY;

    const bodyGroup = new THREE.Group();
    const clothMat = new THREE.MeshLambertMaterial({ color: cfg.suitColor });
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xfbd0b0 });

    // 🦵 GERÇEKÇİ OTURUŞ: Üst bacak yere tam paralel, alt bacak yere dik iner!
    const legsGroup = new THREE.Group();

    // Üst Bacaklar (Thighs - Yere Tam Paralel!)
    const leftThigh = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.12, 0.36), clothMat);
    leftThigh.position.set(-0.13, 0.44, 0.18);
    legsGroup.add(leftThigh);

    const rightThigh = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.12, 0.36), clothMat);
    rightThigh.position.set(0.13, 0.44, 0.18);
    legsGroup.add(rightThigh);

    // Alt Bacaklar (Calves - Dizden yere dik iner)
    const leftCalf = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.38, 0.12), clothMat);
    leftCalf.position.set(-0.13, 0.21, 0.36);
    legsGroup.add(leftCalf);

    const rightCalf = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.38, 0.12), clothMat);
    rightCalf.position.set(0.13, 0.21, 0.36);
    legsGroup.add(rightCalf);

    bodyGroup.add(legsGroup);

    // Gövde
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.52, 0.28), clothMat);
    torso.position.y = 0.70;
    bodyGroup.add(torso);

    // Kollar
    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.40, 0.11), clothMat);
    leftArm.position.set(-0.28, 0.68, 0.12);
    leftArm.rotation.x = Math.PI / 4;
    bodyGroup.add(leftArm);

    const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.40, 0.11), clothMat);
    rightArm.position.set(0.28, 0.68, 0.12);
    rightArm.rotation.x = Math.PI / 4;
    bodyGroup.add(rightArm);

    // Kafa
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.10, 0);

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.30, 0.26), skinMat);
    headGroup.add(head);

    const hair = new THREE.Mesh(new THREE.BoxGeometry(0.30, 0.10, 0.28), new THREE.MeshLambertMaterial({ color: cfg.hairColor }));
    hair.position.set(0, 0.15, 0);
    headGroup.add(hair);

    if (cfg.hasGlasses) {
        const glasses = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.05, 0.03), new THREE.MeshBasicMaterial({ color: 0x0284c7 }));
        glasses.position.set(0, 0.02, 0.14);
        headGroup.add(glasses);
    }

    bodyGroup.add(headGroup);
    agentGroup.add(bodyGroup);

    agents[cfg.id] = {
        id: cfg.id,
        name: cfg.name,
        group: agentGroup,
        chairGroup: chairGroup,
        bodyGroup: bodyGroup,
        headGroup: headGroup,
        legsGroup: legsGroup,
        leftThigh: leftThigh,
        rightThigh: rightThigh,
        leftCalf: leftCalf,
        rightCalf: rightCalf,
        leftArm: leftArm,
        rightArm: rightArm,
        homePos: new THREE.Vector3(...cfg.seatPos),
        homeRotY: cfg.seatRotY,
        state: 'SEATED_WORKING',
        swivelProgress: 0,
        swivelTargetRot: 0,
        waypoints: [],
        currentWpIdx: 0,
        activityType: 0,
        destinationTimer: 0,
        destinationPhrase: ''
    };

    bubbleAnchors[cfg.id].pos = new THREE.Vector3(cfg.seatPos[0], 1.95, cfg.seatPos[2]);
    officeScene.add(agentGroup);
}

// Bacak Pozunu Ayarla (Oturuş: Üst Bacak Yere Paralel / Ayakta: Dik)
function setAgentLegsPose(ag, isSeated) {
    if (isSeated) {
        ag.leftThigh.position.set(-0.13, 0.44, 0.18);
        ag.leftThigh.scale.set(1, 1, 1);
        ag.rightThigh.position.set(0.13, 0.44, 0.18);
        ag.rightThigh.scale.set(1, 1, 1);

        ag.leftCalf.position.set(-0.13, 0.21, 0.36);
        ag.rightCalf.position.set(0.13, 0.21, 0.36);
    } else {
        // Ayakta yürürken bacaklar düz dik konuma geçer
        ag.leftThigh.position.set(-0.13, 0.30, 0);
        ag.leftThigh.scale.set(1, 1.4, 0.35);
        ag.rightThigh.position.set(0.13, 0.30, 0);
        ag.rightThigh.scale.set(1, 1.4, 0.35);

        ag.leftCalf.position.set(-0.13, 0.10, 0);
        ag.rightCalf.position.set(0.13, 0.10, 0);
    }
}

// 🖥️ MONİTÖRLERİN ELEMANA BAKMASI VE OPTİK MOUSE
function buildWorkerDeskEquipment(cfg, isRightSide) {
    const compGroup = new THREE.Group();
    compGroup.position.set(...cfg.deskPos);

    // Kavisli ekranlar ve ekipmanlar doğrudan masada oturan elemana baksın:
    compGroup.rotation.y = isRightSide ? Math.PI / 2 : -Math.PI / 2;

    const screenMat = new THREE.MeshBasicMaterial({ color: cfg.screenColor });

    // 🖥️ Ana Ekran (27" Canlı Mum ve Uzmanlık Grafiği)
    const scr1 = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.32, 0.02), screenMat);
    scr1.position.set(-0.24, 0.25, 0.02);
    scr1.rotation.y = -0.15;
    compGroup.add(scr1);
    officeDeskScreens.push(scr1);

    // 🖥️ İkincil Ekran (24" Derinlik / Emir Akışı Ekranı)
    const scr2 = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.28, 0.02), screenMat);
    scr2.position.set(0.24, 0.23, 0.02);
    scr2.rotation.y = 0.18;
    compGroup.add(scr2);
    officeDeskScreens.push(scr2);

    // Ekran Standı ve Ayarlanabilir Montaj Kolu
    const standMat = new THREE.MeshLambertMaterial({ color: 0x334155 });
    const standBar = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.03, 0.03), standMat);
    standBar.position.set(0, 0.22, -0.05);
    compGroup.add(standBar);

    const standPost = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.22, 12), standMat);
    standPost.position.set(0, 0.11, -0.05);
    compGroup.add(standPost);

    // ⌨️ Mekanik Ofis Klavyesi (RGB Işıklı Çerçeve)
    const kb = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.015, 0.14), new THREE.MeshLambertMaterial({ color: 0x1e293b }));
    kb.position.set(-0.05, 0.015, 0.24);
    compGroup.add(kb);

    // 🖱️ Geniş Mousepad & Hassas Optik Mouse
    const pad = new THREE.Mesh(new THREE.BoxGeometry(0.70, 0.005, 0.30), new THREE.MeshLambertMaterial({ color: 0x090e17 }));
    pad.position.set(0.05, 0.005, 0.24);
    compGroup.add(pad);

    const mouse = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.018, 0.10), new THREE.MeshLambertMaterial({ color: 0x0f172a }));
    mouse.position.set(0.25, 0.018, 0.24);
    compGroup.add(mouse);

    const mouseLed = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.005, 0.03), new THREE.MeshBasicMaterial({ color: cfg.screenColor }));
    mouseLed.position.set(0.25, 0.028, 0.24);
    compGroup.add(mouseLed);

    // ☕ Çalışan Kahve/Su Kupası
    const cupMat = new THREE.MeshLambertMaterial({ color: 0x334155 });
    const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.03, 0.08, 12), cupMat);
    cup.position.set(-0.30, 0.04, 0.18);
    compGroup.add(cup);

    // 🏷️ Masada Çalışan İsimlik Plaketi
    const badgeMat = new THREE.MeshLambertMaterial({ color: 0x1e293b });
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.03, 0.06), badgeMat);
    badge.position.set(-0.24, 0.015, -0.02);
    badge.rotation.x = -0.3;
    compGroup.add(badge);

    officeScene.add(compGroup);
}

// -------------------------------------------------------------
// 🏓 ⚽ PATRONUN ARKADAŞLARI: MEHMET & BERAT
// -------------------------------------------------------------
function buildFriendsMehmetAndBerat() {
    createFriendCharacter({
        id: 'mehmet',
        name: 'Mehmet (Patronun Arkadaşı)',
        startPos: [7.5, 0, -2.5],
        startRotY: -Math.PI / 2,
        shirtColor: 0x0d9488,
        pantsColor: 0x1e293b,
        hairColor: 0x1c1917,
        initialPhrase: "Berat PS5 kolunu hazırla kanka, rövanş maçı var!"
    });

    createFriendCharacter({
        id: 'berat',
        name: 'Berat (Patronun Arkadaşı)',
        startPos: [7.5, 0, 1.2],
        startRotY: -Math.PI / 2,
        shirtColor: 0x2563eb,
        pantsColor: 0x0f172a,
        hairColor: 0x451a03,
        initialPhrase: "Langırt 7'de biter kanka, yenilen semaverden çayları koyar!"
    });
}

function createFriendCharacter(cfg) {
    const friendGroup = new THREE.Group();
    friendGroup.position.set(...cfg.startPos);
    friendGroup.rotation.y = cfg.startRotY;

    const bodyGroup = new THREE.Group();
    const shirtMat = new THREE.MeshLambertMaterial({ color: cfg.shirtColor });
    const pantsMat = new THREE.MeshLambertMaterial({ color: cfg.pantsColor });
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xfbd0b0 });

    const legs = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.44, 0.16), pantsMat);
    legs.position.y = 0.22;
    bodyGroup.add(legs);

    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.52, 0.26), shirtMat);
    torso.position.y = 0.70;
    bodyGroup.add(torso);

    const leftArm = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.42, 0.11), shirtMat);
    leftArm.position.set(-0.28, 0.68, 0.10);
    leftArm.rotation.x = Math.PI / 5;
    bodyGroup.add(leftArm);

    const rightArm = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.42, 0.11), shirtMat);
    rightArm.position.set(0.28, 0.68, 0.10);
    rightArm.rotation.x = -Math.PI / 6;
    bodyGroup.add(rightArm);

    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.10, 0);

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.30, 0.26), skinMat);
    headGroup.add(head);

    const hair = new THREE.Mesh(new THREE.BoxGeometry(0.30, 0.10, 0.28), new THREE.MeshLambertMaterial({ color: cfg.hairColor }));
    hair.position.set(0, 0.15, 0);
    headGroup.add(hair);

    bodyGroup.add(headGroup);
    friendGroup.add(bodyGroup);

    friends[cfg.id] = {
        id: cfg.id,
        name: cfg.name,
        group: friendGroup,
        bodyGroup: bodyGroup,
        headGroup: headGroup,
        leftArm: leftArm,
        rightArm: rightArm,
        currentSpot: 0
    };

    bubbleAnchors[cfg.id].pos = new THREE.Vector3(cfg.startPos[0], 2.05, cfg.startPos[2]);
    officeScene.add(friendGroup);
}

// -------------------------------------------------------------
// ÇAPA NOKTALARINI DOM ELEMENTLERİNE BAĞLA
// -------------------------------------------------------------
function bindBubbleElements() {
    bubbleAnchors.boss.el = document.getElementById('bubble-boss');
    bubbleAnchors.boss.bodyEl = document.getElementById('text-boss');

    bubbleAnchors.scanner.el = document.getElementById('bubble-scanner');
    bubbleAnchors.scanner.bodyEl = document.getElementById('text-scanner');

    bubbleAnchors.ta.el = document.getElementById('bubble-ta');
    bubbleAnchors.ta.bodyEl = document.getElementById('text-ta');

    bubbleAnchors.news.el = document.getElementById('bubble-news');
    bubbleAnchors.news.bodyEl = document.getElementById('text-news');

    bubbleAnchors.risk.el = document.getElementById('bubble-risk');
    bubbleAnchors.risk.bodyEl = document.getElementById('text-risk');

    bubbleAnchors.chief.el = document.getElementById('bubble-chief');
    bubbleAnchors.chief.bodyEl = document.getElementById('text-chief');

    bubbleAnchors.quant.el = document.getElementById('bubble-quant');
    bubbleAnchors.quant.bodyEl = document.getElementById('text-quant');

    bubbleAnchors.mehmet.el = document.getElementById('bubble-mehmet');
    bubbleAnchors.mehmet.bodyEl = document.getElementById('text-mehmet');

    bubbleAnchors.berat.el = document.getElementById('bubble-berat');
    bubbleAnchors.berat.bodyEl = document.getElementById('text-berat');

    bubbleAnchors.trade.el = document.getElementById('tradeMonitorBubble');
}

// -------------------------------------------------------------
// OTONOM OFİS RUTİNİ: SANDALYE DÖNÜŞÜ, MASADAN DOLAŞMA, WC, LAVABO, PS5
// -------------------------------------------------------------
function updateAutonomousOfficeAI(deltaTime, time) {
    // TV Ekranı Oyun Grafiğini Döndür
    renderTVScreenGraphics(time);

    // WC Kapısı Hareketi (Lerp)
    if (wcDoorGroup) {
        wcDoorGroup.rotation.y = THREE.MathUtils.lerp(wcDoorGroup.rotation.y, wcDoorTargetRot, 0.12);
    }

    // 1. Rastgele Karakter Diyaloğu (Sırayla Konuşma)
    if (time > nextDialogueTime) {
        nextDialogueTime = time + 6500 + Math.random() * 4500;
        const allKeys = ['boss', 'scanner', 'ta', 'risk', 'news', 'chief', 'quant', 'mehmet', 'berat'];
        const chosen = allKeys[Math.floor(Math.random() * allKeys.length)];

        if (chosen === 'boss') {
            const bossLines = [
                "Piyasayı tarayın beyler, acele yok! Disiplin #1 kuralımız.",
                "Sermaye koruma kuralına sıkı sıkıya bağlıyız.",
                "Mehmet, Berat PS5'te sesinizi biraz kısın toplantıdayız haha!",
                "Radardaki hacimli hareketleri gözden kaçırmayın."
            ];
            triggerSpeech('boss', bossLines[Math.floor(Math.random() * bossLines.length)], 5000);
        } else if (chosen === 'mehmet') {
            const mLines = [
                "Berat PS5 kolunda lag var bahane bulma haha!",
                "Semaverden iki tavşan kanı çay kap gel de yeni tura geçelim kanka.",
                "Masa tenisinde bu sefer seni devireceğim oğlum!",
                "Langırt 7'de biter kanka, yenilen semaverin suyunu tazeler!"
            ];
            triggerSpeech('mehmet', mLines[Math.floor(Math.random() * mLines.length)], 4500);
        } else if (chosen === 'berat') {
            const bLines = [
                "Mehmet pas versene oğlum kaleciyle karşı karşıyayım!",
                "Masa tenisinde dün şansın yaver gitti kanka, gel rövanşa!",
                "İki çay koydum semaverden, kap gel sehpaya.",
                "Efe patrona helal olsun, ofisi saray gibi yapmış valla!"
            ];
            triggerSpeech('berat', bLines[Math.floor(Math.random() * bLines.length)], 4500);
        } else {
            const phr = {
                scanner: [
                    "200+ parite taranıyor, hacim anomalileri anlık takipte.",
                    "15m grafiklerde Bollinger sıkışması olan coinler filtreleniyor.",
                    "Ölü piyasa filtresi devrede, testere piyasada işlem açmıyoruz."
                ],
                ta: [
                    "BTC 4s bant daralması %0.40 seviyesinde, kırılım bekleniyor.",
                    "EMA 20 & 50 kesişimleri analiz masasında inceleniyor.",
                    "Destek ve direnç rejimleri netleşmeden acele karar yok."
                ],
                news: [
                    "Funding rate oranları dengeli, global haber akışı sakin.",
                    "Makro piyasada likidite şoku tespit edilmedi.",
                    "Kripto haber akışında kritik duyuru yok, radar stabil."
                ],
                risk: [
                    "Kasa Kalkanı devrede: Maks 5x kaldıraç, %1.5 risk tavanı.",
                    "Sermaye koruma modu devrede, stop seviyeleri korunuyor.",
                    "Günlük kayıp limiti devrede, disiplin tam."
                ],
                chief: [
                    "Efe Bey, piyasa şu an bekleme modunda. Sabır en büyük kârımız.",
                    "Trend teyidi gelmeden sermayeyi riske atmıyoruz.",
                    "Risk ve Teknik ekipleri tam koordinasyon halinde."
                ],
                quant: [
                    "10,000 Monte Carlo stokastik yol simüle ediliyor. Eşiğimiz %70!",
                    "GBM ve Jump Diffusion ile olasılık dağılımını hesaplıyorum.",
                    "Beklenen R-Multiple pozitif ve TP ihtimali %70'in üzerindeyse onay veririm.",
                    "10,000 simülasyonda Stop Loss riski yüksekse komiteyi anında veto ederim."
                ]
            }[chosen];
            if (phr) triggerSpeech(chosen, phr[Math.floor(Math.random() * phr.length)], 5000);
        }
    }

    // 2. Mehmet ve Berat Eğlence Döngüsü
    if (time > nextFriendsGameTime) {
        nextFriendsGameTime = time + 14000;
        const m = friends['mehmet'];
        const b = friends['berat'];
        if (m && b) {
            // Mehmet ve Berat sırayla mekan değiştirir: Masa Tenisi -> Langırt -> PS5 Kanepe -> Çay
            m.currentSpot = ((m.currentSpot || 0) + 1) % 4;
            if (m.currentSpot === 0) {
                // Masa tenisi
                m.group.position.set(7.5, 0, -3.2);
                b.group.position.set(9.0, 0, -3.2);
                triggerSpeech('mehmet', "Masa tenisinde bu sefer seni devireceğim!", 4500);
            } else if (m.currentSpot === 1) {
                // Langırt
                m.group.position.set(7.5, 0, 0.5);
                b.group.position.set(9.0, 0, 0.5);
                triggerSpeech('berat', "Langırt 7'de biter kanka, bahse var mısın?", 4500);
            } else if (m.currentSpot === 2) {
                // 🎮 PlayStation 5 Kanepesi
                m.group.position.set(-6.8, 0, 0.9);
                b.group.position.set(-5.8, 0, 1.4);
                triggerSpeech('mehmet', "Berat PS5'te pas at pas, kaleci boşta!", 4500);
            } else {
                // Çay Köşesi
                m.group.position.set(-5.5, 0, -3.8);
                b.group.position.set(-6.5, 0, -3.8);
                triggerSpeech('berat', "Semaverden iki tavşan kanı çay çekelim ya.", 4500);
            }
            bubbleAnchors.mehmet.pos = new THREE.Vector3(m.group.position.x, 2.05, m.group.position.z);
            bubbleAnchors.berat.pos = new THREE.Vector3(b.group.position.x, 2.05, b.group.position.z);
        }
    }

    // 3. Çalışanların Mola Döngüsü (Yürüyüşler Seyreltildi - Tam Bir Çalışkan Ofis Havası)
    if (!isAnyAgentWalking && time > nextAutonomousActionTime) {
        // Her 90 - 135 saniyede bir sadece 1 kişi kısa bir işlem/ihtiyaç için kalkar, vakitlerinin %95'ini masada geçirirler
        nextAutonomousActionTime = time + 90000 + Math.random() * 45000;
        const eligibleAgents = Object.values(agents).filter(a => a.state === 'SEATED_WORKING');
        if (eligibleAgents.length > 0) {
            const chosenAgent = eligibleAgents[Math.floor(Math.random() * eligibleAgents.length)];
            const activityType = Math.floor(Math.random() * 4); // 0: Çay, 1: WC & Lavabo, 2: Yazıcı/Fotokopi Çıktısı, 3: PS5 / Lounge
            startAgentActivityWithChairSwivel(chosenAgent, activityType);
        }
    }

    // Elemanların Yürüme ve Rutinlerini Güncelle
    Object.values(agents).forEach(ag => {
        updateSingleAgentMovement(ag, deltaTime, time);
    });
}

// 🪑 SANDALYEYİ ARKAYA ÇEVİRME & MASANIN ETRAFINDAN DOLAŞMA
function startAgentActivityWithChairSwivel(ag, actionType) {
    isAnyAgentWalking = true;
    ag.state = 'SWIVELING_OUT';
    ag.activityType = actionType;
    ag.swivelProgress = 0;

    // Sandalyenin arkaya dönük açısı (Kendi sırasının arka koridoruna doğru)
    const isLeft = ag.homePos.x < 0;
    ag.swivelTargetRot = isLeft ? -Math.PI / 2 : Math.PI / 2;
    const aisleX = isLeft ? -3.3 : 3.3;

    if (actionType === 0) {
        // Çay Köşesine Gidiş
        if (isLeft) {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, -3.2),
                new THREE.Vector3(-5.8, 0, -3.2)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(aisleX, 0, -3.2),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        } else {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(-3.3, 0, -3.2),
                new THREE.Vector3(-5.8, 0, -3.2)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(-5.8, 0, -3.2),
                new THREE.Vector3(-3.3, 0, -3.2),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        }
        ag.destinationPhrase = "Tavşan kanı bir bardak çay alayım, piyasa takibi yoğun...";
    } else if (actionType === 1) {
        // 🚻 Köşe Tuvalete Gidiş (Kapı Açılır, Girer, Çıkar, Lavaboda El Yıkar)
        if (isLeft) {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, -3.2),
                new THREE.Vector3(-8.8, 0, -3.2)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(-7.5, 0, -3.2),
                new THREE.Vector3(aisleX, 0, -3.2),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        } else {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(-3.3, 0, -3.2),
                new THREE.Vector3(-8.8, 0, -3.2)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(-7.5, 0, -3.2),
                new THREE.Vector3(-3.3, 0, -3.2),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        }
        ag.destinationPhrase = "Kısa bir ihtiyaç molası...";
    } else if (actionType === 2) {
        // 🖨️ YAZICIDAN / FOTOKOPİDEN RAPOR ALMA
        if (isLeft) {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(-4.0, 0, -2.5)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(aisleX, 0, -2.5),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        } else {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(-4.0, 0, -2.5)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(-3.3, 0, -2.5),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        }
        ag.destinationPhrase = "Kuantum simülasyonu ve risk denetim raporu çıktısını alıyorum...";
    } else {
        // 🛋️ GENİŞLETİLMİŞ LOUNGE & PS5 KANEPESİ
        if (isLeft) {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, 1.2),
                new THREE.Vector3(-6.8, 0, 1.2)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(-6.8, 0, 1.2),
                new THREE.Vector3(aisleX, 0, 1.2),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        } else {
            ag.waypoints = [
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(-6.8, 0, 1.2)
            ];
            ag.returnWaypoints = [
                new THREE.Vector3(-6.8, 0, 1.2),
                new THREE.Vector3(-3.3, 0, 2.6),
                new THREE.Vector3(aisleX, 0, 2.6),
                new THREE.Vector3(aisleX, 0, ag.homePos.z),
                ag.homePos.clone()
            ];
        }
        ag.destinationPhrase = "Lounge'da 5 dakika dinlenip PlayStation'da bir tur atayım.";
    }
}

function updateSingleAgentMovement(ag, deltaTime, time) {
    if (ag.state === 'SEATED_WORKING') {
        ag.leftArm.rotation.x = Math.PI / 3.5 + Math.sin(time * 0.005) * 0.04;
        ag.rightArm.rotation.x = Math.PI / 3.5 + Math.cos(time * 0.005) * 0.04;
        ag.bodyGroup.position.y = 0;
        setAgentLegsPose(ag, true); // Bacaklar yere tam paralel!
        return;
    }

    // AŞAMA 1: SANDALYEYİ ARKAYA ÇEVİRME
    if (ag.state === 'SWIVELING_OUT') {
        ag.swivelProgress += deltaTime * 2.5;
        const currentRot = THREE.MathUtils.lerp(ag.homeRotY, ag.swivelTargetRot, Math.min(ag.swivelProgress, 1.0));
        ag.chairGroup.rotation.y = currentRot;
        ag.group.rotation.y = currentRot;

        if (ag.swivelProgress >= 1.0) {
            ag.state = 'WALKING';
            ag.currentWpIdx = 0;
            setAgentLegsPose(ag, false); // Ayağa kalktı, bacaklar dik
        }
        return;
    }

    // AŞAMA 2: YÜRÜME (MASANIN ETRAFINDAN KORİDORLARDAN DOLAŞIR)
    if (ag.state === 'WALKING') {
        if (ag.currentWpIdx >= ag.waypoints.length) {
            if (ag.activityType === 1) {
                // 🚻 TUVALET KABİNİNE GİRİŞ AŞAMASI
                ag.state = 'WC_DOOR_OPENING';
                wcDoorTargetRot = -Math.PI / 2; // Kapı açılır!
                playOfficeSound('door');
                ag.destinationTimer = Date.now() + 800;
                return;
            } else {
                ag.state = 'AT_DESTINATION';
                ag.destinationTimer = Date.now() + 6000;
                triggerSpeech(ag.id, ag.destinationPhrase, 4500);

                if (ag.activityType === 0) {
                    playOfficeSound('tea');
                } else if (ag.activityType === 2) {
                    // 🖨️ Yazıcıdan çıktı alma animasyonu
                    ag.group.rotation.y = -Math.PI / 2; // Yazıcıya dönük
                    ag.leftArm.rotation.x = Math.PI / 3;
                    ag.rightArm.rotation.x = Math.PI / 3;
                    playOfficeSound('click');
                } else if (ag.activityType === 3) {
                    // 🛋️ KANEPEDE OTURMA & PS5
                    ag.group.rotation.y = Math.PI / 2; // Odaya ve TV'ye dönük
                    ag.bodyGroup.position.y = -0.15; // Kanepenin minderine oturur
                    setAgentLegsPose(ag, true);
                    ag.leftArm.rotation.x = Math.PI / 3; // PS5 kolunu tutar
                    ag.rightArm.rotation.x = Math.PI / 3;
                }
                return;
            }
        }

        const targetWp = ag.waypoints[ag.currentWpIdx];
        const currentPos = ag.group.position;
        const dir = new THREE.Vector3().subVectors(targetWp, currentPos);
        const dist = dir.length();

        if (dist < 0.12) {
            ag.currentWpIdx++;
        } else {
            dir.normalize();
            const step = Math.min(dist, 1.8 * deltaTime);
            currentPos.addScaledVector(dir, step);

            const targetAngle = Math.atan2(dir.x, dir.z);
            ag.group.rotation.y = THREE.MathUtils.lerp(ag.group.rotation.y, targetAngle, 0.15);

            // Ayakta yürüme salınımı
            const walkCycle = time * 0.01;
            ag.leftThigh.position.z = Math.sin(walkCycle) * 0.15;
            ag.rightThigh.position.z = -Math.sin(walkCycle) * 0.15;
            ag.leftArm.rotation.x = -Math.sin(walkCycle) * 0.35;
            ag.rightArm.rotation.x = Math.sin(walkCycle) * 0.35;
        }
    } else if (ag.state === 'WC_DOOR_OPENING') {
        if (Date.now() > ag.destinationTimer) {
            // Eleman kabinin içine adım atar
            ag.group.position.set(-9.2, 0, -4.5);
            wcDoorTargetRot = 0; // Kapı kapanır!
            playOfficeSound('door');
            if (portableWcLight) portableWcLight.color.setHex(0xef4444); // DOLU IŞIĞI (KIRMIZI)
            ag.state = 'WC_INSIDE';
            ag.destinationTimer = Date.now() + 4000; // İçeride 4 saniye
        }
    } else if (ag.state === 'WC_INSIDE') {
        if (Date.now() > ag.destinationTimer) {
            // İhtiyaç giderildi, kapı açılır
            wcDoorTargetRot = -Math.PI / 2;
            playOfficeSound('door');
            if (portableWcLight) portableWcLight.color.setHex(0x10b981); // BOŞ IŞIĞI (YEŞİL)
            ag.state = 'WC_EXITING';
            ag.destinationTimer = Date.now() + 800;
        }
    } else if (ag.state === 'WC_EXITING') {
        if (Date.now() > ag.destinationTimer) {
            // Eleman tuvaletten çıkar ve yanındaki lavaboya geçer
            ag.group.position.set(-7.5, 0, -3.8); // Lavabo önü
            ag.group.rotation.y = Math.PI; // Aynaya/Lavaboya dönük
            wcDoorTargetRot = 0; // Kapı geri kapanır
            playOfficeSound('door');

            ag.state = 'WASHING_HANDS';
            ag.destinationTimer = Date.now() + 3500;
            triggerSpeech(ag.id, "Ellerimi sabunla bolca yıkadım, hijyen tamam!", 3500);
            playOfficeSound('water'); // El yıkama su sesi!
        }
    } else if (ag.state === 'WASHING_HANDS') {
        // Lavaboda el yıkama hareketi
        ag.leftArm.rotation.x = Math.PI / 2.8 + Math.sin(time * 0.02) * 0.15;
        ag.rightArm.rotation.x = Math.PI / 2.8 + Math.cos(time * 0.02) * 0.15;

        if (Date.now() > ag.destinationTimer) {
            // El yıkama bitti, masaya dönüş başlar
            ag.leftArm.rotation.x = 0;
            ag.rightArm.rotation.x = 0;
            ag.state = 'WALKING_BACK';
            ag.waypoints = ag.returnWaypoints;
            ag.currentWpIdx = 0;
        }
    } else if (ag.state === 'AT_DESTINATION') {
        if (Date.now() > ag.destinationTimer) {
            // Kanepeden veya dinlenmeden kalkış
            ag.bodyGroup.position.y = 0;
            setAgentLegsPose(ag, false);
            ag.state = 'WALKING_BACK';
            ag.waypoints = ag.returnWaypoints;
            ag.currentWpIdx = 0;
        }
    } else if (ag.state === 'WALKING_BACK') {
        if (ag.currentWpIdx >= ag.waypoints.length) {
            // AŞAMA 3: MASAYA GELDİ, SANDALYE VE KARAKTERİ MASAYA DOĞRU GERİ ÇEVİR
            ag.state = 'SWIVELING_IN';
            ag.swivelProgress = 0;
        } else {
            const targetWp = ag.waypoints[ag.currentWpIdx];
            const currentPos = ag.group.position;
            const dir = new THREE.Vector3().subVectors(targetWp, currentPos);
            const dist = dir.length();

            if (dist < 0.12) {
                ag.currentWpIdx++;
            } else {
                dir.normalize();
                const step = Math.min(dist, 1.8 * deltaTime);
                currentPos.addScaledVector(dir, step);

                const targetAngle = Math.atan2(dir.x, dir.z);
                ag.group.rotation.y = THREE.MathUtils.lerp(ag.group.rotation.y, targetAngle, 0.15);

                const walkCycle = time * 0.01;
                ag.leftThigh.position.z = Math.sin(walkCycle) * 0.15;
                ag.rightThigh.position.z = -Math.sin(walkCycle) * 0.15;
                ag.leftArm.rotation.x = -Math.sin(walkCycle) * 0.35;
                ag.rightArm.rotation.x = Math.sin(walkCycle) * 0.35;
            }
        }
    } else if (ag.state === 'SWIVELING_IN') {
        ag.swivelProgress += deltaTime * 2.5;
        const currentRot = THREE.MathUtils.lerp(ag.swivelTargetRot, ag.homeRotY, Math.min(ag.swivelProgress, 1.0));
        ag.chairGroup.rotation.y = currentRot;
        ag.group.rotation.y = currentRot;

        if (ag.swivelProgress >= 1.0) {
            ag.state = 'SEATED_WORKING';
            ag.group.position.copy(ag.homePos);
            ag.group.rotation.y = ag.homeRotY;
            ag.chairGroup.rotation.y = ag.homeRotY;
            setAgentLegsPose(ag, true); // Bacaklar masada yere tam paralel pozisyona geçer!
            isAnyAgentWalking = false; // Tekli kilit serbest!
        }
    }

    bubbleAnchors[ag.id].pos = new THREE.Vector3(ag.group.position.x, 1.95, ag.group.position.z);
}

// -------------------------------------------------------------
// BALONCUKLARIN 3D DÜNYADAN 2D EKRANA YANSITILMASI
// -------------------------------------------------------------
function updateBubblePositions() {
    if (!officeCamera || !officeRenderer) return;

    const width = officeRenderer.domElement.clientWidth;
    const height = officeRenderer.domElement.clientHeight;

    Object.keys(bubbleAnchors).forEach(key => {
        const item = bubbleAnchors[key];
        if (!item || !item.el || !item.pos) return;

        // Trade Bubble görünürlük kontrolü
        if (key === 'trade') {
            if (currentBubbleMode === 'off') {
                item.el.style.opacity = '0';
                return;
            }
        } else {
            // Karakter balonları
            if (currentBubbleMode === 'off') {
                item.el.style.opacity = '0';
                return;
            }
            if (currentBubbleMode === 'boss' && key !== 'boss') {
                item.el.style.opacity = '0';
                return;
            }
            if (!item.isSpeaking && currentBubbleMode === 'smart') {
                item.el.style.opacity = '0';
                return;
            }
        }

        const screenPos = item.pos.clone().project(officeCamera);

        // Kamera arkasındaysa gizle
        if (screenPos.z > 1.0) {
            item.el.style.opacity = '0';
            return;
        }

        const x = (screenPos.x * 0.5 + 0.5) * width;
        const y = (-screenPos.y * 0.5 + 0.5) * height;

        item.el.style.left = `${x}px`;
        item.el.style.top = `${y}px`;

        if (key === 'trade') {
            item.el.style.opacity = '1';
        } else if (item.isSpeaking || currentBubbleMode === 'all') {
            item.el.style.opacity = '1';
        }
    });
}

// -------------------------------------------------------------
// BALONCUK GÖRÜNÜM MODUNU DEĞİŞTİR
// -------------------------------------------------------------
function cycleBubbleMode() {
    const modes = ['all', 'smart', 'boss', 'off'];
    const idx = modes.indexOf(currentBubbleMode);
    currentBubbleMode = modes[(idx + 1) % modes.length];

    const btn = document.getElementById('btnToggleBubbles');
    if (btn) {
        const labels = {
            all: '💬 Balon: Tümü',
            smart: '💬 Balon: Akıllı',
            boss: '💬 Balon: Patron',
            off: '💬 Balon: Gizli'
        };
        btn.innerText = labels[currentBubbleMode];
    }
    playOfficeSound('click');
}

// -------------------------------------------------------------
// TAM EKRAN MODU
// -------------------------------------------------------------
function toggleOfficeFullscreen() {
    const container = document.getElementById('office3dContainer');
    if (!container) return;

    if (!document.fullscreenElement) {
        if (container.requestFullscreen) {
            container.requestFullscreen();
        } else if (container.webkitRequestFullscreen) {
            container.webkitRequestFullscreen();
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        }
    }
}

document.addEventListener('fullscreenchange', () => {
    const isFs = !!document.fullscreenElement;
    const btnExit = document.getElementById('btnExitOfficeFs');
    if (btnExit) btnExit.style.display = isFs ? 'block' : 'none';
    setTimeout(resizeOffice3D, 150);
});

// -------------------------------------------------------------
// KAMERA AÇILARI (DUVAR ENGELİ SIFIR - TÜM AÇILARDAN FERAH GÖRÜNÜM)
// -------------------------------------------------------------
function setOfficeCamera(mode = 'boss') {
    ['btnCamBoss', 'btnCamTable', 'btnCamIso', 'btnCamChill'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.classList.remove('active');
    });

    const isPortrait = (window.innerWidth / window.innerHeight) < 1.0;

    if (mode === 'boss') {
        const btn = document.getElementById('btnCamBoss');
        if (btn) btn.classList.add('active');
        camTargetPos = new THREE.Vector3(0, 2.2, isPortrait ? -1.0 : -1.4);
        camLookTarget = new THREE.Vector3(0, 1.35, -3.8);
        playOfficeSound('chime');
    } else if (mode === 'table') {
        const btn = document.getElementById('btnCamTable');
        if (btn) btn.classList.add('active');
        camTargetPos = new THREE.Vector3(0, isPortrait ? 4.8 : 4.0, isPortrait ? 5.5 : 4.8);
        camLookTarget = new THREE.Vector3(0, 1.1, -0.8);
        playOfficeSound('click');
    } else if (mode === 'iso') {
        const btn = document.getElementById('btnCamIso');
        if (btn) btn.classList.add('active');
        // Kuşbakışı: Duvar engeli olmadan tüm odayı 45 dereceden görür!
        camTargetPos = new THREE.Vector3(isPortrait ? 8.2 : 7.2, isPortrait ? 7.5 : 6.5, isPortrait ? 8.2 : 7.2);
        camLookTarget = new THREE.Vector3(0, 0.9, 0);
        playOfficeSound('click');
    } else if (mode === 'chill') {
        const btn = document.getElementById('btnCamChill');
        if (btn) btn.classList.add('active');
        // Dinlenme, TV, PS5 ve Çay Alanına Odak
        camTargetPos = new THREE.Vector3(-4.5, 3.8, 5.2);
        camLookTarget = new THREE.Vector3(-6.5, 1.1, 0.5);
        playOfficeSound('pingpong');
    }
}

// -------------------------------------------------------------
// ANİMASYON DÖNGÜSÜ (RENDER LOOP)
// -------------------------------------------------------------
let lastFrameTime = 0;

function animateOffice(time) {
    officeAnimFrameId = requestAnimationFrame(animateOffice);

    const deltaTime = lastFrameTime ? Math.min((time - lastFrameTime) / 1000, 0.1) : 0.016;
    lastFrameTime = time;

    // 1. Dönen Sims Plumbob'u
    if (plumbobMesh) {
        plumbobMesh.rotation.y += 0.025;
        const bobY = 1.95 + Math.sin(time * 0.003) * 0.06;
        plumbobMesh.position.y = bobY;
    }

    // 2. Patron Efe'nin Hafif Kafa Hareketi
    if (bossHeadMesh) {
        bossHeadMesh.rotation.x = Math.sin(time * 0.0018) * 0.04;
        bossHeadMesh.rotation.y = Math.sin(time * 0.001) * 0.08;
    }

    // 3. Konfeti Parçacık Animasyonu
    updateConfetti(deltaTime);

    // 4. Otonom Ofis Yapay Zekası
    updateAutonomousOfficeAI(deltaTime, time);

    // 5. Yumuşak Kamera Geçişi
    if (camTargetPos && officeCamera) {
        officeCamera.position.lerp(camTargetPos, 0.05);
        if (camLookTarget && camCurrentLook) {
            camCurrentLook.lerp(camLookTarget, 0.05);
            if (officeControls) {
                officeControls.target.copy(camCurrentLook);
            } else {
                officeCamera.lookAt(camCurrentLook);
            }
        }
        if (officeCamera.position.distanceTo(camTargetPos) < 0.02) {
            camTargetPos = null;
        }
    }

    // 6. Controls
    if (officeControls) {
        officeControls.update();
    }

    // 7. Baloncukları Yansıt
    updateBubblePositions();

    // 8. Render
    if (officeRenderer && officeScene && officeCamera) {
        officeRenderer.render(officeScene, officeCamera);
    }
}

// -------------------------------------------------------------
// CANLI VERİ ENTEGRASYONU (API/DATA)
// -------------------------------------------------------------
function updateOffice3DData(data) {
    if (!data) return;

    const btc = data.btc_regime || {};
    const positions = data.active_positions || [];
    const logs = data.scanner_logs || [];
    const statusPill = document.getElementById('officeStatusPill');

    // Kârlı pozisyon kontrolü (Yeni pozisyon kâra geçtiğinde konfeti patlat!)
    if (positions.length > 0) {
        const pos = positions[0];
        const pnl = Number(pos.unrealized_pnl_pct || 0);
        if (pnl > 0.5 && lastKnownTradeStatus !== 'PROFIT') {
            lastKnownTradeStatus = 'PROFIT';
            triggerOfficeConfetti();
        }
    } else {
        lastKnownTradeStatus = null;
    }

    // 1. Dev Ekranda İkili Görünümü Güncelle
    renderBigWallScreenContent({
        btcPrice: btc.btc_price ? Number(btc.btc_price).toLocaleString('en-US', {minimumFractionDigits: 1}) : '76,500.0',
        btcStatus: `${btc.status || 'DEAD_CHOP'} (4s Bant: %${btc.range_pct || '0.40'})`,
        activePositions: positions
    });
    if (bigWallTexture) bigWallTexture.needsUpdate = true;

    // 2. Canlı İşlem Baloncuğu (Masa rengini asla değiştirmeden sadece 2D balonu günceller!)
    const tradeBubble = bubbleAnchors.trade.el;
    if (positions.length > 0) {
        const pos = positions[0];
        const pnl = Number(pos.unrealized_pnl_pct || 0);
        const isProfit = pnl >= 0;
        const pnlText = (isProfit ? '+' : '') + pnl.toFixed(2) + '%';
        const sym = pos.symbol || 'POZİSYON';
        const dir = pos.direction || 'LONG';

        if (tradeBubble) {
            tradeBubble.className = 'sims-trade-bubble ' + (isProfit ? 'profit' : 'loss');
            tradeBubble.innerHTML = `
                <div style="font-weight: 800; font-size: 11px;">
                    ${isProfit ? '🟢' : '🔴'} ${sym} ${dir} ${pnlText}
                </div>
                <div style="font-size: 9px; opacity: 0.85; margin-top: 2px;">
                    Fiyat: $${Number(pos.live_price || 0).toLocaleString()} | ${pos.elapsed_str || ''}
                </div>
            `;
        }

        if (statusPill) {
            statusPill.innerHTML = `⚡ <strong>CANLI İŞLEM:</strong> ${sym} (${pnlText})`;
            statusPill.style.color = isProfit ? '#10b981' : '#ef4444';
        }
    } else {
        if (tradeBubble) {
            tradeBubble.className = 'sims-trade-bubble idle';
            tradeBubble.innerHTML = `💤 AKTİF İŞLEM YOK (200 Parite Radarda)`;
        }

        if (statusPill) {
            statusPill.innerHTML = `👑 Efe Masada | Piyasayı Gözlüyor`;
            statusPill.style.color = '#94a3b8';
        }
    }

    // 3. Canlı Veriye Göre Cümleler
    if (bubbleAnchors.boss.bodyEl) {
        if (positions.length > 0) {
            bubbleAnchors.boss.bodyEl.innerText = "İşlem açık beyler! Hedeflere sadık kalın, stop seviyesini koruyun.";
        } else if (btc.status === 'DEAD_CHOP') {
            bubbleAnchors.boss.bodyEl.innerText = "Piyasada ölü testere var. Acele işlem yok, sermaye koruma kuralımız #1!";
        } else if (btc.status === 'BULLISH') {
            bubbleAnchors.boss.bodyEl.innerText = "BTC yukarı yönlü kırılımda. En güçlü pariteyi önüme getirin!";
        }
    }

    if (bubbleAnchors.scanner.bodyEl && logs.length > 0) {
        bubbleAnchors.scanner.bodyEl.innerText = `Radar: ${logs[0].symbol || 'PARİTE'} incelendi [${logs[0].status || 'OK'}].`;
    }

    if (bubbleAnchors.ta.bodyEl) {
        bubbleAnchors.ta.bodyEl.innerText = `BTC 4s bant daralması: %${btc.range_pct || '0.40'}. EMA & Bollinger sıkışması var.`;
    }
}

// -------------------------------------------------------------
// PENCERE BOYUTLANDIRMA VE DUYARLILIK
// -------------------------------------------------------------
function resizeOffice3D() {
    const target = document.getElementById('officeCanvasTarget');
    if (!target || !officeRenderer || !officeCamera) return;

    const width = target.clientWidth || target.offsetWidth;
    const height = target.clientHeight || target.offsetHeight;

    if (width > 0 && height > 0) {
        officeCamera.aspect = width / height;
        officeCamera.updateProjectionMatrix();
        officeRenderer.setSize(width, height);
    }
}

// -------------------------------------------------------------
// BAŞLATMA & BOYUTLANDIRMA KÖPRÜSÜ
// -------------------------------------------------------------
function initOrResizeOffice3D() {
    try {
        if (!officeInitialized) {
            init3DOffice();
        } else {
            resizeOffice3D();
        }
    } catch (e) {
        console.error("Office init/resize error:", e);
    }
}
window.initOrResizeOffice3D = initOrResizeOffice3D;
window.initOffice3D = initOrResizeOffice3D;

        // Başlangıç Sol Görünümü ve Canlı Polling
        try {
            switchLeftView(currentLeftView);
        } catch (e) {
            console.error("Initial switchLeftView error:", e);
        }
        try {
            switchBotMode(currentBotMode);
        } catch (e) {
            console.error("Initial switchBotMode error:", e);
        }

        // Canlı Polling Kesintisiz Başlatılır
        fetchTerminal();
        setInterval(fetchTerminal, 2000);
    </script>
</body>
</html>
"""

@app.after_request
def add_no_cache_headers(response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

@app.route("/")
def index():
    return render_template_string(HTML_OFFICE_TEMPLATE)

@app.route("/charts/<path:filename>")
def serve_chart(filename):
    return send_from_directory(CHARTS_DIR, filename)

_terminal_cache = {
    "btc_regime": {"status": "NEUTRAL", "btc_price": 0, "summary": "Piyasa taranıyor..."},
    "stats": {},
    "total_unrealized_pnl": 0.0,
    "total_unrealized_dollar": 0.0,
    "active_positions": [],
    "scanner_logs": [],
    "news_feed": [],
    "coin_news_investigations": [],
    "trade_history": [],
    "committee_debates": [],
    "trade_reflections": [],
    "learning_reports": [],
    "tuning_info": {},
    "timeline_quotas": {"total": {"used": 0, "max": 12}, "15m": {"used": 0, "max": 5}, "30m": {"used": 0, "max": 4}, "1h": {"used": 0, "max": 3}}
}

# İlk açılışta ekranın boş kalmaması veya gidip gelmemesi için DB'den anında besle
try:
    from core.database import (
        get_scanner_logs_db, get_news_feed_db, get_coin_news_investigations_db, get_performance_stats,
        get_all_signals, get_active_and_pending_signals, get_latest_debates_db,
        get_recent_reflections_db, get_learning_reports_db,
        get_fast_performance_stats, get_fast_active_and_pending_signals,
        get_fast_all_signals, get_fast_scanner_logs_db
    )
    from core.self_tuning_engine import SelfTuningEngine
    from fast_config import FAST_MAX_CONCURRENT_TRADES
    _terminal_cache["stats"] = get_performance_stats() or {}
    _terminal_cache["scanner_logs"] = get_scanner_logs_db(limit=40) or []
    _terminal_cache["news_feed"] = get_news_feed_db(limit=25) or []
    _terminal_cache["coin_news_investigations"] = get_coin_news_investigations_db(limit=25) or []
    _terminal_cache["learning_reports"] = get_learning_reports_db(limit=15) or []
    _all_init = get_all_signals(limit=40) or []
    _terminal_cache["trade_history"] = [s for s in _all_init if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
    _terminal_cache["active_positions"] = get_active_and_pending_signals() or []
    _terminal_cache["committee_debates"] = get_latest_debates_db(limit=8) or []
    _terminal_cache["trade_reflections"] = get_recent_reflections_db(limit=15) or []
    _terminal_cache["tuning_info"] = SelfTuningEngine.run_autonomous_training_cycle(auto_commit=True) or {}

    # FAST Bot Başlangıç Önbellek Verileri
    _terminal_cache["fast_stats"] = get_fast_performance_stats() or {}
    _terminal_cache["fast_scanner_logs"] = get_fast_scanner_logs_db(limit=40) or []
    _all_fast_init = get_fast_all_signals(limit=40) or []
    _terminal_cache["fast_trade_history"] = [s for s in _all_fast_init if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
    _terminal_cache["fast_active_positions"] = get_fast_active_and_pending_signals() or []
    _terminal_cache["fast_total_unrealized_pnl"] = 0.0
    _terminal_cache["fast_max_concurrent_trades"] = FAST_MAX_CONCURRENT_TRADES

    # SÜPER FAST Bot Başlangıç Önbellek Verileri (Saniyelik HFT)
    from core.database import (
        get_super_fast_performance_stats, get_super_fast_active_and_pending_signals,
        get_super_fast_all_signals, get_super_fast_scanner_logs_db
    )
    from super_fast_config import SUPER_FAST_MAX_CONCURRENT_TRADES
    _terminal_cache["super_fast_stats"] = get_super_fast_performance_stats() or {}
    _terminal_cache["super_fast_scanner_logs"] = get_super_fast_scanner_logs_db(limit=40) or []
    _all_super_init = get_super_fast_all_signals(limit=40) or []
    _terminal_cache["super_fast_trade_history"] = [s for s in _all_super_init if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
    _terminal_cache["super_fast_active_positions"] = get_super_fast_active_and_pending_signals() or []
    _terminal_cache["super_fast_total_unrealized_pnl"] = 0.0
    _terminal_cache["super_fast_max_concurrent_trades"] = SUPER_FAST_MAX_CONCURRENT_TRADES
except Exception:
    pass
_cache_lock = threading.Lock()
_updater_started = False

def update_terminal_cache_loop():
    """Arka planda piyasa ve pozisyon verilerini kesintisiz ve hatasız günceller (Sıfır Donma, Sıfır Gidip Gelme)."""
    global _terminal_cache
    cached_tickers = {}
    cached_klines = {}
    cached_fast_klines = {}

    import time
    while True:
        try:
            # 1. Binance Tickers
            try:
                fresh_tickers = client.get_24hr_tickers()
                if fresh_tickers:
                    cached_tickers = fresh_tickers
            except Exception:
                pass

            # 2. BTC Rejimi
            try:
                btc_regime = client.get_btc_regime()
            except Exception:
                with _cache_lock:
                    btc_regime = _terminal_cache.get("btc_regime", {"status": "NEUTRAL", "btc_price": 0})

            # 3. İstatistikler & Veritabanı
            try:
                stats = get_performance_stats()
                active_signals = get_active_and_pending_signals()
                all_sigs = get_all_signals(limit=40)
                history = [s for s in all_sigs if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
                scanner_logs = get_scanner_logs()
                news_feed = get_live_news_feed()
                if not news_feed:
                    news_feed = news_agent.fetch_latest_market_news()
                debates = get_latest_debates_db(limit=8)
                reflections = get_recent_reflections_db(limit=15)
                coin_investigations = get_coin_news_investigations_db(limit=25)
                learning_reports = get_learning_reports_db(limit=15)

                # Otonom Kendi Kendini Eğitme Kontrolü (Her 3 dakikada bir otomatik eğitim döngüsü)
                if not hasattr(update_terminal_cache_loop, "_last_auto_train_ts"):
                    update_terminal_cache_loop._last_auto_train_ts = time.time()
                if time.time() - update_terminal_cache_loop._last_auto_train_ts > 180:
                    try:
                        SelfTuningEngine.run_autonomous_training_cycle(auto_commit=True)
                        update_terminal_cache_loop._last_auto_train_ts = time.time()
                        learning_reports = get_learning_reports_db(limit=15)
                    except Exception:
                        pass
            except Exception:
                with _cache_lock:
                    stats = _terminal_cache.get("stats", {})
                    active_signals = []
                    history = _terminal_cache.get("trade_history", [])
                    scanner_logs = _terminal_cache.get("scanner_logs", [])
                    news_feed = _terminal_cache.get("news_feed", [])
                    coin_investigations = _terminal_cache.get("coin_news_investigations", [])
                    learning_reports = _terminal_cache.get("learning_reports", [])
                    debates = _terminal_cache.get("committee_debates", [])
                    reflections = _terminal_cache.get("trade_reflections", [])

            # FAST Bot Pozisyon Takibi (TP / SL / Ladder / Timeout Anlık Denetimi)
            try:
                from agents.fast_tracker_agent import FastCounterfactualTrackerAgent
                if not hasattr(update_terminal_cache_loop, "_fast_tracker_inst"):
                    from agents.notifier_agent import NotifierAgent
                    update_terminal_cache_loop._fast_tracker_inst = FastCounterfactualTrackerAgent(client, notifier=NotifierAgent())
                update_terminal_cache_loop._fast_tracker_inst.update_open_trades()
            except Exception:
                pass

            # FAST Bot İstatistikleri & Veritabanı
            try:
                from core.database import (
                    get_fast_performance_stats, get_fast_active_and_pending_signals,
                    get_fast_all_signals, get_fast_scanner_logs_db
                )
                from fast_config import FAST_MAX_CONCURRENT_TRADES
                fast_stats = get_fast_performance_stats()
                fast_active_signals = get_fast_active_and_pending_signals()
                fast_all_sigs = get_fast_all_signals(limit=40)
                fast_history = [s for s in fast_all_sigs if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
                fast_scanner_logs = get_fast_scanner_logs_db(limit=40)
            except Exception:
                with _cache_lock:
                    fast_stats = _terminal_cache.get("fast_stats", {})
                    fast_active_signals = []
                    fast_history = _terminal_cache.get("fast_trade_history", [])
                    fast_scanner_logs = _terminal_cache.get("fast_scanner_logs", [])

            # 4. Standart Aktif Pozisyonlar ve Çizgi Fiyatları
            active_positions = []
            total_unrealized_pnl = 0.0
            total_unrealized_dollar = 0.0

            from core.binance_streamer import get_live_price, is_streamer_connected

            for sig in active_signals:
                symbol = sig["symbol"]
                ws_price = get_live_price(symbol)
                ticker = cached_tickers.get(symbol, {})
                entry_price = sig.get("actual_entry_price") or sig["entry_min"]
                live_price = ws_price if ws_price else ticker.get("lastPrice", entry_price)
                leverage = sig.get("leverage", 10)
                direction = sig["direction"]

                gross_pnl_pct = 0.0
                fee_pct = round(BINANCE_ROUNDTRIP_FEE_PCT * leverage, 2)
                net_pnl_pct = 0.0
                if entry_price > 0:
                    if direction == "LONG":
                        raw_diff = (live_price - entry_price) / entry_price
                    else:
                        raw_diff = (entry_price - live_price) / entry_price
                    gross_pnl_pct = round(raw_diff * leverage * 100, 2)
                    net_pnl_pct = round(gross_pnl_pct - fee_pct, 2)
                    total_unrealized_pnl += net_pnl_pct

                pos_margin = float(sig.get("allocated_margin_usdt") or 200.0)
                pos_dollar_gain = round(pos_margin * (net_pnl_pct / 100.0), 2)
                total_unrealized_dollar += pos_dollar_gain

                # Mum verisini çek (başarısız olursa son hafızadakini koru)
                try:
                    klines = client.get_klines(symbol, interval="15m", limit=16)
                    if klines:
                        cached_klines[symbol] = klines
                except Exception:
                    pass

                entered_str = sig.get("entered_at") or sig.get("created_at")
                elapsed_str = "1 dk"
                if entered_str:
                    try:
                        t_str = str(entered_str).replace('T', ' ').split('.')[0]
                        dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
                        diff_sec = max(0, int((datetime.now() - dt).total_seconds()))
                        mins = diff_sec // 60
                        secs = diff_sec % 60
                        if mins == 0:
                            elapsed_str = f"{secs} sn"
                        elif mins < 60:
                            elapsed_str = f"{mins} dk"
                        else:
                            elapsed_str = f"{mins // 60} sa {mins % 60} dk"
                    except Exception:
                        pass

                sig_dict = dict(sig)
                sig_dict["elapsed_str"] = elapsed_str
                sig_dict["live_price"] = live_price
                sig_dict["unrealized_pnl_pct"] = net_pnl_pct
                sig_dict["unrealized_pnl_dollar"] = pos_dollar_gain
                sig_dict["allocated_margin_usdt"] = pos_margin
                sig_dict["gross_pnl_pct"] = gross_pnl_pct
                sig_dict["fee_pct"] = fee_pct
                sig_dict["ladder_step"] = sig.get("ladder_step") or 0
                sig_dict["ladder_name"] = sig.get("ladder_name") or ""
                sig_dict["recent_candles"] = cached_klines.get(symbol, [])
                active_positions.append(sig_dict)

            # 5. FAST Scalper Aktif Pozisyonlar ve Çizgi Fiyatları (1m Mumlar)
            fast_active_positions = []
            fast_total_unrealized_pnl = 0.0
            fast_total_unrealized_dollar = 0.0

            for fsig in fast_active_signals:
                fsymbol = fsig["symbol"]
                f_ws_price = get_live_price(fsymbol)
                f_ticker = cached_tickers.get(fsymbol, {})
                f_entry_price = fsig.get("actual_entry_price") or fsig["entry_min"]
                f_live_price = f_ws_price if f_ws_price else f_ticker.get("lastPrice", f_entry_price)
                f_leverage = fsig.get("leverage", 10)
                f_direction = fsig["direction"]

                f_gross_pnl_pct = 0.0
                f_fee_pct = round(0.10 * f_leverage, 2)
                f_net_pnl_pct = 0.0
                if f_entry_price > 0:
                    if f_direction == "LONG":
                        f_raw_diff = (f_live_price - f_entry_price) / f_entry_price
                    else:
                        f_raw_diff = (f_entry_price - f_live_price) / f_entry_price
                    f_gross_pnl_pct = round(f_raw_diff * f_leverage * 100, 2)
                    f_net_pnl_pct = round(f_gross_pnl_pct - f_fee_pct, 2)
                    fast_total_unrealized_pnl += f_net_pnl_pct

                f_pos_margin = float(fsig.get("allocated_margin_usdt") or 100.0)
                f_pos_dollar = round(f_pos_margin * (f_net_pnl_pct / 100.0), 2)
                fast_total_unrealized_dollar += f_pos_dollar

                # 1m hızlı mum verisi çek
                try:
                    f_klines = client.get_klines(fsymbol, interval="1m", limit=16)
                    if f_klines:
                        cached_fast_klines[fsymbol] = f_klines
                except Exception:
                    pass

                f_entered_str = fsig.get("entered_at") or fsig.get("created_at")
                f_elapsed_str = "1 dk"
                if f_entered_str:
                    try:
                        t_str = str(f_entered_str).replace('T', ' ').split('.')[0]
                        dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
                        diff_sec = max(0, int((datetime.now() - dt).total_seconds()))
                        mins = diff_sec // 60
                        secs = diff_sec % 60
                        if mins == 0:
                            f_elapsed_str = f"{secs} sn"
                        elif mins < 60:
                            f_elapsed_str = f"{mins} dk"
                        else:
                            f_elapsed_str = f"{mins // 60} sa {mins % 60} dk"
                    except Exception:
                        pass

                fsig_dict = dict(fsig)
                fsig_dict["elapsed_str"] = f_elapsed_str
                fsig_dict["live_price"] = f_live_price
                fsig_dict["unrealized_pnl_pct"] = f_net_pnl_pct
                fsig_dict["unrealized_pnl_dollar"] = f_pos_dollar
                fsig_dict["allocated_margin_usdt"] = f_pos_margin
                fsig_dict["gross_pnl_pct"] = f_gross_pnl_pct
                fsig_dict["fee_pct"] = f_fee_pct
                fsig_dict["ladder_step"] = fsig.get("ladder_step") or 0
                fsig_dict["ladder_name"] = fsig.get("ladder_name") or ""
                fsig_dict["recent_candles"] = cached_fast_klines.get(fsymbol, [])
                fast_active_positions.append(fsig_dict)

            # SÜPER FAST Bot Pozisyon Takibi (Saniyelik TP / SL / Ladder / Timeout Anlık Denetimi)
            try:
                from agents.super_fast_tracker_agent import SuperFastCounterfactualTrackerAgent
                if not hasattr(update_terminal_cache_loop, "_super_fast_tracker_inst"):
                    update_terminal_cache_loop._super_fast_tracker_inst = SuperFastCounterfactualTrackerAgent(client)
                update_terminal_cache_loop._super_fast_tracker_inst.update_open_trades()
            except Exception:
                pass

            # SÜPER FAST Bot İstatistikleri & Veritabanı
            try:
                from core.database import (
                    get_super_fast_performance_stats, get_super_fast_active_and_pending_signals,
                    get_super_fast_all_signals, get_super_fast_scanner_logs_db
                )
                from super_fast_config import SUPER_FAST_MAX_CONCURRENT_TRADES
                super_fast_stats = get_super_fast_performance_stats()
                super_fast_active_signals = get_super_fast_active_and_pending_signals()
                super_fast_all_sigs = get_super_fast_all_signals(limit=50)
                super_fast_history = [s for s in super_fast_all_sigs if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
                super_fast_scanner_logs = get_super_fast_scanner_logs_db(limit=50)
            except Exception:
                with _cache_lock:
                    super_fast_stats = _terminal_cache.get("super_fast_stats", {})
                    super_fast_active_signals = []
                    super_fast_history = _terminal_cache.get("super_fast_trade_history", [])
                    super_fast_scanner_logs = _terminal_cache.get("super_fast_scanner_logs", [])

            # 6. SÜPER FAST Scalper Aktif Pozisyonlar ve Çizgi Fiyatları
            super_fast_active_positions = []
            super_fast_total_unrealized_pnl = 0.0
            super_fast_total_unrealized_dollar = 0.0

            for sfsig in super_fast_active_signals:
                sfsymbol = sfsig["symbol"]
                sf_ws_price = get_live_price(sfsymbol)
                sf_ticker = cached_tickers.get(sfsymbol, {})
                sf_entry_price = sfsig.get("actual_entry_price") or sfsig["entry_min"]
                sf_live_price = sf_ws_price if sf_ws_price else sf_ticker.get("lastPrice", sf_entry_price)
                sf_leverage = sfsig.get("leverage", 10)
                sf_direction = sfsig["direction"]

                sf_gross_pnl_pct = 0.0
                sf_fee_pct = round(0.10 * sf_leverage, 2)
                sf_net_pnl_pct = 0.0
                if sf_entry_price > 0:
                    if sf_direction == "LONG":
                        sf_raw_diff = (sf_live_price - sf_entry_price) / sf_entry_price
                    else:
                        sf_raw_diff = (sf_entry_price - sf_live_price) / sf_entry_price
                    sf_gross_pnl_pct = round(sf_raw_diff * sf_leverage * 100, 2)
                    sf_net_pnl_pct = round(sf_gross_pnl_pct - sf_fee_pct, 2)
                    super_fast_total_unrealized_pnl += sf_net_pnl_pct

                sf_pos_margin = float(sfsig.get("allocated_margin_usdt") or 50.0)
                sf_pos_dollar = round(sf_pos_margin * (sf_net_pnl_pct / 100.0), 2)
                super_fast_total_unrealized_dollar += sf_pos_dollar

                # 1m hızlı mum verisi (grafik için)
                try:
                    sf_klines = client.get_klines(sfsymbol, interval="1m", limit=16)
                    if sf_klines:
                        cached_fast_klines[sfsymbol] = sf_klines
                except Exception:
                    pass

                sf_entered_str = sfsig.get("entered_at") or sfsig.get("created_at")
                sf_elapsed_str = "1 dk"
                if sf_entered_str:
                    try:
                        t_str = str(sf_entered_str).replace('T', ' ').split('.')[0]
                        dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
                        diff_sec = max(0, int((datetime.now() - dt).total_seconds()))
                        mins = diff_sec // 60
                        secs = diff_sec % 60
                        if mins == 0:
                            sf_elapsed_str = f"{secs} sn"
                        elif mins < 60:
                            sf_elapsed_str = f"{mins} dk"
                        else:
                            sf_elapsed_str = f"{mins // 60} sa {mins % 60} dk"
                    except Exception:
                        pass

                sfsig_dict = dict(sfsig)
                sfsig_dict["elapsed_str"] = sf_elapsed_str
                sfsig_dict["live_price"] = sf_live_price
                sfsig_dict["unrealized_pnl_pct"] = sf_net_pnl_pct
                sfsig_dict["unrealized_pnl_dollar"] = sf_pos_dollar
                sfsig_dict["allocated_margin_usdt"] = sf_pos_margin
                sfsig_dict["gross_pnl_pct"] = sf_gross_pnl_pct
                sfsig_dict["fee_pct"] = sf_fee_pct
                sfsig_dict["ladder_step"] = sfsig.get("ladder_step") or 0
                sfsig_dict["ladder_name"] = sfsig.get("ladder_name") or ""
                sfsig_dict["recent_candles"] = cached_fast_klines.get(sfsymbol, [])
                super_fast_active_positions.append(sfsig_dict)

            # Vade Kotaları Bilgisini Derle
            try:
                from core.database import get_today_trades_count_by_timeframe, get_today_trades_count
                from config import DAILY_MAX_TRADES_15M, DAILY_MAX_TRADES_30M, DAILY_MAX_TRADES_1H, DAILY_BASE_MAX_TRADES
                t_counts = get_today_trades_count_by_timeframe()
                t_total = get_today_trades_count()
                sum_used = t_counts.get("15m", 0) + t_counts.get("30m", 0) + t_counts.get("1h", 0)
                used_final = max(t_total, sum_used)
                timeline_quotas = {
                    "total": {"used": used_final, "max": DAILY_BASE_MAX_TRADES},
                    "15m": {"used": t_counts.get("15m", 0), "max": DAILY_MAX_TRADES_15M},
                    "30m": {"used": t_counts.get("30m", 0), "max": DAILY_MAX_TRADES_30M},
                    "1h": {"used": t_counts.get("1h", 0), "max": DAILY_MAX_TRADES_1H}
                }
            except Exception:
                timeline_quotas = _terminal_cache.get("timeline_quotas", {
                    "total": {"used": 0, "max": 12},
                    "15m": {"used": 0, "max": 5},
                    "30m": {"used": 0, "max": 4},
                    "1h": {"used": 0, "max": 3}
                })

            # Atomik Olarak Önbelleği Güncelle
            with _cache_lock:
                _terminal_cache = {
                    "ws_connected": is_streamer_connected(),
                    "btc_regime": btc_regime,
                    "stats": stats,
                    "max_concurrent_trades": MAX_CONCURRENT_TRADES,
                    "timeline_quotas": timeline_quotas,
                    "total_unrealized_pnl": round(total_unrealized_pnl, 2),
                    "total_unrealized_dollar": round(total_unrealized_dollar, 2),
                    "active_positions": active_positions,
                    "scanner_logs": scanner_logs if scanner_logs else _terminal_cache.get("scanner_logs", []),
                    "news_feed": news_feed if news_feed else _terminal_cache.get("news_feed", []),
                    "coin_news_investigations": coin_investigations if coin_investigations else _terminal_cache.get("coin_news_investigations", []),
                    "trade_history": history if history else _terminal_cache.get("trade_history", []),
                    "committee_debates": debates if debates else _terminal_cache.get("committee_debates", []),
                    "trade_reflections": reflections if reflections else _terminal_cache.get("trade_reflections", []),
                    "tuning_info": _terminal_cache.get("tuning_info", {}),
                    "learning_reports": learning_reports if learning_reports else _terminal_cache.get("learning_reports", []),
                    # FAST Scalper (1m) Bağımsız Alanı
                    "fast_stats": fast_stats,
                    "fast_max_concurrent_trades": FAST_MAX_CONCURRENT_TRADES,
                    "fast_total_unrealized_pnl": round(fast_total_unrealized_pnl, 2),
                    "fast_total_unrealized_dollar": round(fast_total_unrealized_dollar, 2),
                    "fast_active_positions": fast_active_positions,
                    "fast_trade_history": fast_history if fast_history else _terminal_cache.get("fast_trade_history", []),
                    "fast_scanner_logs": fast_scanner_logs if fast_scanner_logs else _terminal_cache.get("fast_scanner_logs", []),
                    # SÜPER FAST Scalper (Saniyelik) Bağımsız Alanı
                    "super_fast_stats": super_fast_stats,
                    "super_fast_max_concurrent_trades": SUPER_FAST_MAX_CONCURRENT_TRADES,
                    "super_fast_total_unrealized_pnl": round(super_fast_total_unrealized_pnl, 2),
                    "super_fast_total_unrealized_dollar": round(super_fast_total_unrealized_dollar, 2),
                    "super_fast_active_positions": super_fast_active_positions,
                    "super_fast_trade_history": super_fast_history if super_fast_history else _terminal_cache.get("super_fast_trade_history", []),
                    "super_fast_scanner_logs": super_fast_scanner_logs if super_fast_scanner_logs else _terminal_cache.get("super_fast_scanner_logs", [])
                }

        except Exception:
            pass

        time.sleep(1.2)

@app.route("/api/data")
def api_data():
    with _cache_lock:
        return jsonify(_terminal_cache)

@app.route("/api/news/coin-investigations", methods=["GET"])
def api_news_coin_investigations():
    from core.database import get_coin_news_investigations_db
    limit = int(request.args.get("limit", 25))
    return jsonify(get_coin_news_investigations_db(limit=limit))

@app.route("/api/news/investigate", methods=["GET", "POST"])
def api_news_investigate():
    global _terminal_cache
    if request.method == "POST" and request.is_json:
        data = request.get_json() or {}
        symbol = data.get("symbol", "BTC")
        direction = data.get("direction", "LONG")
    else:
        symbol = request.args.get("symbol", "BTC")
        direction = request.args.get("direction", "LONG")
    
    if not symbol:
        return jsonify({"success": False, "error": "Sembol belirtilmelidir (örn: SOL, BTC)"}), 400
    
    try:
        from agents.news_agent import NewsAgent
        from core.database import get_coin_news_investigations_db
        agent = NewsAgent()
        clean_sym = symbol.strip().upper()
        if not clean_sym.endswith("USDT") and not clean_sym.endswith("BUSD"):
            clean_sym += "USDT"
        inv = agent.investigate_coin_news(clean_sym, direction.strip().upper())
        
        # Önbelleği de anında güncelle
        with _cache_lock:
            _terminal_cache["coin_news_investigations"] = get_coin_news_investigations_db(limit=25)
            
        return jsonify({"success": True, "data": inv})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/reflections")
def api_reflections():
    from core.database import get_recent_reflections_db
    return jsonify(get_recent_reflections_db(limit=30))

@app.route("/api/tuning", methods=["GET"])
def api_tuning():
    from core.self_tuning_engine import SelfTuningEngine
    return jsonify(SelfTuningEngine.run_calibration_cycle(min_trades_required=5))

@app.route("/api/tuning/reports", methods=["GET"])
def api_tuning_reports():
    from core.database import get_learning_reports_db
    limit = int(request.args.get("limit", 15))
    return jsonify(get_learning_reports_db(limit=limit))

@app.route("/api/tuning/run-autonomous", methods=["POST"])
def api_tuning_run_autonomous():
    global _terminal_cache
    from core.self_tuning_engine import SelfTuningEngine
    from core.database import get_learning_reports_db
    res = SelfTuningEngine.run_autonomous_training_cycle(auto_commit=True)
    with _cache_lock:
        _terminal_cache["tuning_info"] = res
        _terminal_cache["learning_reports"] = get_learning_reports_db(limit=15)
    return jsonify({"success": True, "data": res})

@app.route("/api/tuning/calibrate", methods=["POST"])
@require_admin_pin
def api_tuning_calibrate():
    global _terminal_cache
    from core.self_tuning_engine import SelfTuningEngine
    from core.database import get_learning_reports_db
    res = SelfTuningEngine.run_calibration_cycle(min_trades_required=5)
    with _cache_lock:
        _terminal_cache["tuning_info"] = res
        _terminal_cache["learning_reports"] = get_learning_reports_db(limit=15)
    return jsonify(res)

@app.route("/api/scan", methods=["POST"])
def api_scan():
    global _orchestrator
    if _orchestrator:
        threading.Thread(target=_orchestrator.run_cycle, daemon=True).start()
        return jsonify({"status": "Scan started in background"})
    else:
        from main import TradingBotOrchestrator
        orch = TradingBotOrchestrator()
        threading.Thread(target=orch.run_cycle, daemon=True).start()
        return jsonify({"status": "Scan triggered"})

@app.route("/api/close-position", methods=["POST"])
@require_admin_pin
def api_close_single_position():
    data = request.get_json(silent=True) or {}
    symbol = data.get("symbol") or request.args.get("symbol")
    sig_id = data.get("signal_id") or request.args.get("signal_id")
    target = sig_id if sig_id else symbol

    if not target:
        return jsonify({"status": "error", "message": "Parite (symbol) veya Sinyal ID belirtilmedi"}), 400

    from core.database import (
        close_single_signal_db, get_performance_stats, get_all_signals, get_active_and_pending_signals
    )
    closed_sig = close_single_signal_db(target, client=client)
    if not closed_sig:
        return jsonify({"status": "error", "message": f"{target} için aktif pozisyon bulunamadı veya işlem zaten kapanmış"}), 404

    with _cache_lock:
        active_sigs = get_active_and_pending_signals() or []
        _terminal_cache["active_positions"] = active_sigs
        _terminal_cache["stats"] = get_performance_stats()
        _all_init = get_all_signals(limit=40) or []
        _terminal_cache["trade_history"] = [
            s for s in _all_init if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")
        ]

    return jsonify({
        "status": "success",
        "message": f"{closed_sig.get('symbol')} pozisyonu piyasa fiyatından kapatıldı.",
        "signal": closed_sig
    })

@app.route("/api/close-positions-group", methods=["POST"])
@require_admin_pin
def api_close_positions_group():
    data = request.get_json(silent=True) or {}
    group = data.get("group") or request.args.get("group")
    if not group or group.lower() not in ("profit", "kar", "green", "loss", "zarar", "red"):
        return jsonify({"status": "error", "message": "Geçerli bir grup belirtilmedi ('profit' veya 'loss')"}), 400

    from core.database import (
        close_positions_by_outcome_db, get_performance_stats, get_all_signals, get_active_and_pending_signals
    )
    res = close_positions_by_outcome_db(group, client=client)

    with _cache_lock:
        active_sigs = get_active_and_pending_signals() or []
        _terminal_cache["active_positions"] = active_sigs
        _terminal_cache["stats"] = get_performance_stats()
        _all_init = get_all_signals(limit=40) or []
        _terminal_cache["trade_history"] = [
            s for s in _all_init if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")
        ]

    return jsonify({
        "status": "success",
        "group": res.get("group"),
        "count": res.get("count", 0),
        "closed": res.get("closed", []),
        "message": f"{res.get('count', 0)} adet pozisyon piyasa fiyatından kapatıldı."
    })

@app.route("/api/close-all-positions", methods=["POST"])
@require_admin_pin
def api_close_all_positions():
    from core.database import close_all_active_signals_db, get_performance_stats, get_all_signals
    count = close_all_active_signals_db(client=client)
    with _cache_lock:
        _terminal_cache["active_positions"] = []
        _terminal_cache["total_unrealized_pnl"] = 0.0
        _terminal_cache["total_unrealized_dollar"] = 0.0
        _terminal_cache["stats"] = get_performance_stats()
        _all_init = get_all_signals(limit=40) or []
        _terminal_cache["trade_history"] = [s for s in _all_init if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
    return jsonify({"status": "closed", "count": count})

@app.route("/api/clear-history", methods=["POST"])
@require_admin_pin
def api_clear_history():
    from core.database import clear_closed_trades_db, get_performance_stats
    clear_closed_trades_db()
    with _cache_lock:
        _terminal_cache["trade_history"] = []
        _terminal_cache["stats"] = get_performance_stats()
    return jsonify({"status": "cleared"})

# ========================================================
# FAST BOT ÖZEL API ENDPOINT'LERİ (BAĞIMSIZ KONTROL & 1m SCALPING)
# ========================================================
_fast_orchestrator = None

def get_fast_orchestrator():
    global _fast_orchestrator
    if _fast_orchestrator is None:
        from fast_engine import FastTradingBotOrchestrator
        _fast_orchestrator = FastTradingBotOrchestrator()
    return _fast_orchestrator

@app.route("/api/fast/data")
def api_fast_data():
    with _cache_lock:
        return jsonify({
            "ws_connected": _terminal_cache.get("ws_connected", False),
            "btc_regime": _terminal_cache.get("btc_regime", {}),
            "stats": _terminal_cache.get("fast_stats", {}),
            "max_concurrent_trades": _terminal_cache.get("fast_max_concurrent_trades", 10),
            "total_unrealized_pnl": _terminal_cache.get("fast_total_unrealized_pnl", 0.0),
            "active_positions": _terminal_cache.get("fast_active_positions", []),
            "scanner_logs": _terminal_cache.get("fast_scanner_logs", []),
            "trade_history": _terminal_cache.get("fast_trade_history", []),
            "bot_mode": "fast"
        })

@app.route("/api/fast/scan", methods=["POST"])
def api_fast_scan():
    orch = get_fast_orchestrator()
    threading.Thread(target=orch.run_cycle, daemon=True).start()
    return jsonify({"status": "FAST 1m scan started in background"})

@app.route("/api/fast/close-all-positions", methods=["POST"])
@require_admin_pin
def api_fast_close_all_positions():
    from core.database import close_all_fast_positions_db, get_fast_performance_stats, get_fast_all_signals
    count = close_all_fast_positions_db(client=client)
    with _cache_lock:
        _terminal_cache["fast_active_positions"] = []
        _terminal_cache["fast_total_unrealized_pnl"] = 0.0
        _terminal_cache["fast_stats"] = get_fast_performance_stats()
        _all_fast = get_fast_all_signals(limit=40) or []
        _terminal_cache["fast_trade_history"] = [s for s in _all_fast if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
    return jsonify({"status": "closed", "count": count})

@app.route("/api/fast/clear-history", methods=["POST"])
@require_admin_pin
def api_fast_clear_history():
    from core.database import clear_fast_closed_trades_db, get_fast_performance_stats
    clear_fast_closed_trades_db()
    with _cache_lock:
        _terminal_cache["fast_trade_history"] = []
        _terminal_cache["fast_stats"] = get_fast_performance_stats()
    return jsonify({"status": "cleared"})

@app.route("/api/fast/reset-all", methods=["POST"])
@require_admin_pin
def api_fast_reset_all():
    from core.database import reset_fast_bot_db, get_fast_performance_stats
    reset_fast_bot_db()
    with _cache_lock:
        _terminal_cache["fast_active_positions"] = []
        _terminal_cache["fast_total_unrealized_pnl"] = 0.0
        _terminal_cache["fast_trade_history"] = []
        _terminal_cache["fast_scanner_logs"] = []
        _terminal_cache["fast_stats"] = get_fast_performance_stats()
    return jsonify({"status": "reset", "bot": "fast", "equity": 1000.0})

# ========================================================
# SÜPER FAST BOT ÖZEL API ENDPOINT'LERİ (SANİYELİK HFT)
# ========================================================
_super_fast_orchestrator = None

def get_super_fast_orchestrator():
    global _super_fast_orchestrator
    if _super_fast_orchestrator is None:
        from super_fast_engine import SuperFastTradingBotOrchestrator
        _super_fast_orchestrator = SuperFastTradingBotOrchestrator()
    return _super_fast_orchestrator

@app.route("/api/superfast/data")
def api_super_fast_data():
    with _cache_lock:
        return jsonify({
            "ws_connected": _terminal_cache.get("ws_connected", False),
            "btc_regime": _terminal_cache.get("btc_regime", {}),
            "stats": _terminal_cache.get("super_fast_stats", {}),
            "max_concurrent_trades": _terminal_cache.get("super_fast_max_concurrent_trades", 20),
            "total_unrealized_pnl": _terminal_cache.get("super_fast_total_unrealized_pnl", 0.0),
            "active_positions": _terminal_cache.get("super_fast_active_positions", []),
            "scanner_logs": _terminal_cache.get("super_fast_scanner_logs", []),
            "trade_history": _terminal_cache.get("super_fast_trade_history", []),
            "bot_mode": "superfast"
        })

@app.route("/api/superfast/scan", methods=["POST"])
def api_super_fast_scan():
    orch = get_super_fast_orchestrator()
    threading.Thread(target=orch.run_cycle, daemon=True).start()
    return jsonify({"status": "Super FAST scan started in background"})

@app.route("/api/superfast/close-all-positions", methods=["POST"])
@require_admin_pin
def api_super_fast_close_all_positions():
    from core.database import close_all_super_fast_positions_db, get_super_fast_performance_stats, get_super_fast_all_signals
    count = close_all_super_fast_positions_db(client=client)
    with _cache_lock:
        _terminal_cache["super_fast_active_positions"] = []
        _terminal_cache["super_fast_total_unrealized_pnl"] = 0.0
        _terminal_cache["super_fast_stats"] = get_super_fast_performance_stats()
        _all_super = get_super_fast_all_signals(limit=50) or []
        _terminal_cache["super_fast_trade_history"] = [s for s in _all_super if s.get("status") not in ("ACTIVE", "PENDING_ENTRY", "ACTIVE_BE", "ACTIVE_LADDER", "ACTIVE_PARTIAL_TP1")]
    return jsonify({"status": "closed", "count": count})

@app.route("/api/superfast/clear-history", methods=["POST"])
@require_admin_pin
def api_super_fast_clear_history():
    from core.database import clear_super_fast_closed_trades_db, get_super_fast_performance_stats
    clear_super_fast_closed_trades_db()
    with _cache_lock:
        _terminal_cache["super_fast_trade_history"] = []
        _terminal_cache["super_fast_stats"] = get_super_fast_performance_stats()
    return jsonify({"status": "cleared"})

@app.route("/api/superfast/reset-all", methods=["POST"])
@require_admin_pin
def api_super_fast_reset_all():
    from core.database import reset_super_fast_bot_db, get_super_fast_performance_stats
    reset_super_fast_bot_db()
    with _cache_lock:
        _terminal_cache["super_fast_active_positions"] = []
        _terminal_cache["super_fast_total_unrealized_pnl"] = 0.0
        _terminal_cache["super_fast_trade_history"] = []
        _terminal_cache["super_fast_scanner_logs"] = []
        _terminal_cache["super_fast_stats"] = get_super_fast_performance_stats()
    return jsonify({"status": "reset", "bot": "superfast", "equity": 1000.0})

import socket

def is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0

def start_dashboard(orchestrator=None, port=5000, auto_open=True):
    global _orchestrator, _fast_orchestrator, _super_fast_orchestrator, _updater_started
    _orchestrator = orchestrator

    try:
        from config import ENABLE_FAST_ENGINE, ENABLE_SUPER_FAST_ENGINE
    except Exception:
        ENABLE_FAST_ENGINE = False
        ENABLE_SUPER_FAST_ENGINE = False

    if ENABLE_FAST_ENGINE and _fast_orchestrator is None:
        try:
            from fast_engine import FastTradingBotOrchestrator
            _fast_orchestrator = FastTradingBotOrchestrator()
            threading.Thread(target=_fast_orchestrator.run_forever, daemon=True, name="FastBotThread").start()
            print("⚡ [FAST Scalper 1m] Bağımsız Fon Kasalı Motor Arka Planda Başlatıldı (Kasa: $1000 USDT).")
        except Exception as fast_err:
            print(f"⚠️ FAST Scalper başlatılamadı: {fast_err}")
    elif not ENABLE_FAST_ENGINE:
        print("⏸️ [FAST Motoru] Uyku modunda (Tüm API bant genişliği 3-Vadeli Ana Motora ayrıldı).")

    if ENABLE_SUPER_FAST_ENGINE and _super_fast_orchestrator is None:
        try:
            from super_fast_engine import SuperFastTradingBotOrchestrator
            _super_fast_orchestrator = SuperFastTradingBotOrchestrator()
            threading.Thread(target=_super_fast_orchestrator.run_forever, daemon=True, name="SuperFastBotThread").start()
            print("⚡⚡ [SÜPER FAST Saniyelik HFT] Bağımsız Fon Kasalı Motor Arka Planda Başlatıldı (Kasa: $1000 USDT | Limit: 20).")
        except Exception as sfast_err:
            print(f"⚠️ SÜPER FAST başlatılamadı: {sfast_err}")
    elif not ENABLE_SUPER_FAST_ENGINE:
        print("⏸️ [SÜPER FAST Motoru] Uyku modunda (Tüm API bant genişliği 3-Vadeli Ana Motora ayrıldı).")

    # Bulut ve Yerel Ortam Dinamik Port ve Host Desteği (Railway, Render, VPS uyumlu)
    port = int(os.environ.get("PORT", port))
    host = os.environ.get("HOST", "0.0.0.0")

    if not _updater_started:
        threading.Thread(target=update_terminal_cache_loop, daemon=True, name="CacheUpdater").start()
        _updater_started = True

    url = f"http://{'127.0.0.1' if host == '0.0.0.0' else host}:{port}"
    # Yerel ortamda port kullanımını denetle (Bulut ortamında kontrolü her zaman atla)
    is_cloud = bool(
        os.environ.get("RAILWAY_ENVIRONMENT_NAME") or
        os.environ.get("RAILWAY_SERVICE_ID") or
        os.environ.get("RAILWAY_PROJECT_ID") or
        os.environ.get("RAILWAY_ENVIRONMENT") or
        os.environ.get("RENDER") or
        os.environ.get("PORT")
    )
    if not is_cloud and is_port_in_use(port):
        print(f"\n🌐 [Canlı Ofis Terminali Zaten Aktif]: {url}")
        if auto_open:
            try:
                webbrowser.open(url)
            except Exception:
                pass
        return None

    def run_app():
        import logging
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.ERROR)
        try:
            app.run(host=host, port=port, debug=False, use_reloader=False)
        except Exception as e:
            print(f"❌ [DashboardServer Hata] Port: {port}, Host: {host} -> {e}")

    server_thread = threading.Thread(target=run_app, daemon=True, name="DashboardServer")
    server_thread.start()
    print(f"\n🌐 [Canlı Ofis Terminali Hazır]: {url}")

    if auto_open:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    return server_thread

if __name__ == "__main__":
    print("🚀 [Başlatılıyor] Binance Futures AI Ticaret Ofisi...")
    from main import TradingBotOrchestrator
    orch = TradingBotOrchestrator()
    start_dashboard(orchestrator=orch, auto_open=False)

    # 7/24 Kesintisiz Arka Plan Döngüsünü Başlat
    threading.Thread(target=orch.run_forever, kwargs={"skip_dashboard": True}, daemon=True).start()

    print("Kapatmak için Ctrl+C tuşlarına basabilirsiniz.")
    try:
        while True:
            threading.Event().wait(1)
    except KeyboardInterrupt:
        print("\nTerminal kapatıldı.")
