"""
SÜPER FAST Trading Bot Orchestrator - Saniyelik Mikro-Scalp & Yüksek Frekans (HFT) Motoru
High-frequency, second-level trading engine running alongside Standard and FAST bots with an independent $1000 vault.
"""
import sys
import time
import json
import threading
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Set

from super_fast_config import (
    SUPER_FAST_PORTFOLIO_EQUITY_USDT,
    SUPER_FAST_MAX_CONCURRENT_TRADES,
    SUPER_FAST_MAX_POSITIONS_PER_DIRECTION,
    SUPER_FAST_LEVERAGE,
    SUPER_FAST_RISK_PER_TRADE_USDT,
    SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE,
    SUPER_FAST_SCAN_INTERVAL_SECONDS,
    SUPER_FAST_COINS_UNIVERSE,
    SUPER_FAST_CIRCUIT_BREAKER_ENABLED,
    SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT,
    SUPER_FAST_MAX_DAILY_TRADES,
    SUPER_FAST_MAX_DAILY_FEE_USDT,
    SUPER_FAST_POST_LOSS_COOLDOWN_MINUTES,
    SUPER_FAST_BLOCK_DEAD_CHOP,
    SUPER_FAST_SIDE_GUARD_ENABLED,
    SUPER_FAST_SIDE_MAX_CONSECUTIVE_LOSSES,
    SUPER_FAST_SIDE_COOLDOWN_MINUTES
)
from core.binance_client import BinanceFuturesClient
from core.binance_streamer import get_live_price, add_stream_symbol
from core.database import (
    save_super_fast_signal,
    get_super_fast_active_and_pending_signals,
    get_super_fast_performance_stats,
    add_super_fast_scanner_log_db,
    check_super_fast_side_stoploss_guard,
    is_symbol_locked_by_other_bot
)
from agents.super_fast_ta_agent import SuperFastTechnicalAnalysisAgent
from agents.super_fast_tracker_agent import SuperFastCounterfactualTrackerAgent
from agents.notifier_agent import NotifierAgent
from agents.news_agent import NewsAgent
from agents.pairs_stat_arb_agent import StatisticalArbitrageAgent

class SuperFastTradingBotOrchestrator:
    def __init__(self):
        print("⚡⚡ [SÜPER FAST Motoru Başlatılıyor] Saniyelik HFT Scalping Çoklu-Ajan Sistemi ($1000 Bağımsız Kasa)...")
        self.client = BinanceFuturesClient()
        self.ta_agent = SuperFastTechnicalAnalysisAgent()
        self.news_agent = NewsAgent()
        self.notifier = NotifierAgent()
        self.stat_arb = StatisticalArbitrageAgent()
        self.tracker = SuperFastCounterfactualTrackerAgent(self.client, notifier=self.notifier)
        self.cooldown_until: Dict[str, float] = {}
        self.last_reported_hour: Optional[str] = None
        self.is_running = False

    def run_cycle(self):
        """Tek bir saniyelik mikro tarama ve işlem açılış döngüsü yürütür."""
        now_ts = time.time()
        active_positions = get_super_fast_active_and_pending_signals() or []
        active_count = len(active_positions)

        # 1. Kasa Kalkanı: Maksimum 20 Eşzamanlı Pozisyon Sınırı
        if active_count >= SUPER_FAST_MAX_CONCURRENT_TRADES:
            return

        # 2. Günlük Devre Kesici & Sert İşlem/Komisyon Kotası (Anti-Overtrading Guard)
        stats = get_super_fast_performance_stats() or {}
        today_trades = int(stats.get("today_trades") or 0)
        today_dollar_gain = float(stats.get("today_dollar_gain") or 0.0)
        today_fee_pct = float(stats.get("today_fee_pct") or 0.0)
        today_fee_usd = (today_fee_pct / 100.0) * SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE

        # A) Sert Günlük İşlem Kotası (Maks 25 İşlem)
        if today_trades >= SUPER_FAST_MAX_DAILY_TRADES:
            add_super_fast_scanner_log_db(
                "CIRCUIT_BREAKER",
                "STOPPED",
                f"⚡⚡ Süper FAST Günlük İşlem Kotası ({today_trades}/{SUPER_FAST_MAX_DAILY_TRADES}) Doldu. Komisyon Koruma Kilidi Aktif."
            )
            return

        # B) Günlük Komisyon Tavanı (Maks $20)
        if today_fee_usd >= SUPER_FAST_MAX_DAILY_FEE_USDT:
            add_super_fast_scanner_log_db(
                "CIRCUIT_BREAKER",
                "STOPPED",
                f"⚡⚡ Süper FAST Günlük Komisyon Tavanı (${today_fee_usd:.2f} >= ${SUPER_FAST_MAX_DAILY_FEE_USDT}) Aşıldı. Komisyon Kilidi."
            )
            return

        # C) Günlük Zarar Limiti Devre Kesici
        if SUPER_FAST_CIRCUIT_BREAKER_ENABLED and today_dollar_gain <= -SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT:
            add_super_fast_scanner_log_db(
                "CIRCUIT_BREAKER",
                "STOPPED",
                f"Süper FAST Günlük Maksimum Zarar Sınırına (-${SUPER_FAST_DAILY_MAX_DRAWDOWN_USDT}) Ulaşıldı."
            )
            return

        # 2.5. BTC Piyasa Rejimi & Ölü Testere Kalkanı (Sermaye Koruma)
        btc_regime = self.client.get_btc_regime()
        if SUPER_FAST_BLOCK_DEAD_CHOP and btc_regime.get("block_all_entries", False):
            add_super_fast_scanner_log_db("BTC_KALKANI", "PROTECTED", "BTC Ölü Testere Piyasada (İşlemler Donduruldu)")
            return

        active_symbols = {p["symbol"] for p in active_positions}
        long_count = sum(1 for p in active_positions if p["direction"] == "LONG")
        short_count = sum(1 for p in active_positions if p["direction"] == "SHORT")
        slots_left = SUPER_FAST_MAX_CONCURRENT_TRADES - active_count

        # 2.6. STATISTICAL ARBITRAGE & PAIRS TRADING (Market-Neutral Çiftler)
        if slots_left >= 2:
            try:
                pair_opps = self.stat_arb.evaluate_all_pairs(self.client)
                for opp in pair_opps:
                    sym_a = opp["sym_a"]
                    sym_b = opp["sym_b"]
                    if sym_a in active_symbols or sym_b in active_symbols:
                        continue
                    if slots_left < 2:
                        break

                    locked_a, _ = is_symbol_locked_by_other_bot(sym_a, "super_fast", opp["leg_a_direction"])
                    locked_b, _ = is_symbol_locked_by_other_bot(sym_b, "super_fast", opp["leg_b_direction"])
                    if locked_a or locked_b:
                        continue

                    p_a = opp["price_a"]
                    p_b = opp["price_b"]
                    sl_pct = 0.80
                    tp_pct = 0.65

                    sl_a = round(p_a * (1.0 - sl_pct/100.0 if opp["leg_a_direction"] == "LONG" else 1.0 + sl_pct/100.0), 6)
                    tp_a = round(p_a * (1.0 + tp_pct/100.0 if opp["leg_a_direction"] == "LONG" else 1.0 - tp_pct/100.0), 6)
                    sig_a = {
                        "symbol": sym_a,
                        "direction": opp["leg_a_direction"],
                        "leverage": SUPER_FAST_LEVERAGE,
                        "entry_min": p_a, "entry_max": p_a,
                        "actual_entry_price": p_a,
                        "stop_loss": sl_a, "take_profit_1": tp_a, "take_profit_2": tp_a,
                        "risk_reward": 1.4,
                        "risk_grade": "🎯 Stat-Arb Leg A",
                        "news_summary": f"🎯 Stat-Arb Çift ({opp['pair_name']}) Z:{opp['z_score']}",
                        "ta_reasons": opp["reason"],
                        "allocated_margin_usdt": SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE,
                        "risk_usd": SUPER_FAST_RISK_PER_TRADE_USDT,
                        "is_pair_trade": 1,
                        "pair_symbol": sym_b,
                        "super_fast_meta": {"type": "stat_arb", "pair": opp["pair_name"], "leg": "A", "z_score": opp["z_score"]}
                    }
                    save_super_fast_signal(sig_a)
                    active_symbols.add(sym_a)

                    sl_b = round(p_b * (1.0 - sl_pct/100.0 if opp["leg_b_direction"] == "LONG" else 1.0 + sl_pct/100.0), 6)
                    tp_b = round(p_b * (1.0 + tp_pct/100.0 if opp["leg_b_direction"] == "LONG" else 1.0 - tp_pct/100.0), 6)
                    sig_b = {
                        "symbol": sym_b,
                        "direction": opp["leg_b_direction"],
                        "leverage": SUPER_FAST_LEVERAGE,
                        "entry_min": p_b, "entry_max": p_b,
                        "actual_entry_price": p_b,
                        "stop_loss": sl_b, "take_profit_1": tp_b, "take_profit_2": tp_b,
                        "risk_reward": 1.4,
                        "risk_grade": "🎯 Stat-Arb Leg B",
                        "news_summary": f"🎯 Stat-Arb Çift ({opp['pair_name']}) Z:{opp['z_score']}",
                        "ta_reasons": opp["reason"],
                        "allocated_margin_usdt": SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE,
                        "risk_usd": SUPER_FAST_RISK_PER_TRADE_USDT,
                        "is_pair_trade": 1,
                        "pair_symbol": sym_a,
                        "super_fast_meta": {"type": "stat_arb", "pair": opp["pair_name"], "leg": "B", "z_score": opp["z_score"]}
                    }
                    save_super_fast_signal(sig_b)
                    active_symbols.add(sym_b)
                    slots_left -= 2

                    add_super_fast_scanner_log_db(
                        "STAT_ARB",
                        "APPROVED",
                        f"🎯 {opp['pair_name']} Piyasa-Nötr Stat-Arb Çift Açıldı! (Z: {opp['z_score']})",
                        f"Leg A ({sym_a}): {opp['leg_a_direction']} | Leg B ({sym_b}): {opp['leg_b_direction']}"
                    )
            except Exception:
                pass

        for symbol in SUPER_FAST_COINS_UNIVERSE:
            if slots_left <= 0:
                break

            if symbol in active_symbols:
                continue

            # Zarar soğuma süresi kontrolü
            if now_ts < self.cooldown_until.get(symbol, 0):
                continue

            try:
                add_stream_symbol(symbol)
                # 1m mumlar ve son fiyatlar (Regresyon kanalı ve Camarilla için 30 mum)
                candles_1m = self.client.get_klines(symbol, interval="1m", limit=30)
                if not candles_1m or len(candles_1m) < 10:
                    if self.client.is_rate_limited():
                        add_super_fast_scanner_log_db("ALL", "PROTECTED", "Binance API Dinlenme Modu (Rate-Limit Koruması)")
                        break
                    continue

                # Canlı WebSocket fiyatı ve book ticker
                ws_price = get_live_price(symbol)
                book_ticker = self.client.get_book_ticker(symbol)
                recent_prices = [ws_price] if ws_price else []

                # Teknik Analiz Değerlendirmesi
                setup, reason = self.ta_agent.analyze_super_fast_setup(
                    symbol, recent_prices, candles_1m, book_ticker
                )

                if not setup:
                    continue

                direction = setup["direction"]

                # BTC Yön Kalkanı Denetimi (Ayı/Düşüşte LONG Yasak, Rallide SHORT Yasak)
                if direction == "LONG" and btc_regime.get("block_longs", False):
                    add_super_fast_scanner_log_db(symbol, "BLOCKED", "BTC Düşüş/Ayı Kalkanı (LONG Engellendi)")
                    continue
                if direction == "SHORT" and btc_regime.get("block_shorts", False):
                    add_super_fast_scanner_log_db(symbol, "BLOCKED", "BTC Yükseliş/Ralli Kalkanı (SHORT Engellendi)")
                    continue

                # Yön Kalkanı Denetimi (Max 12 Long veya 12 Short)
                if direction == "LONG" and long_count >= SUPER_FAST_MAX_POSITIONS_PER_DIRECTION:
                    continue
                if direction == "SHORT" and short_count >= SUPER_FAST_MAX_POSITIONS_PER_DIRECTION:
                    continue

                # Multi-Bot Anti-Collision & Anti-Hedging Kalkanı (Standard veya FAST çakışması)
                is_other_locked, lock_reason = is_symbol_locked_by_other_bot(symbol, "super_fast", direction)
                if is_other_locked:
                    add_super_fast_scanner_log_db(symbol, "BLOCKED", lock_reason)
                    continue

                # Haber Kararlandırma Konseyi Veto Denetimi (Kara Kuğu / Hack Koruması)
                news_analysis = self.news_agent.analyze_catalyst(symbol, direction)
                if news_analysis and news_analysis.get("is_vetoed"):
                    add_super_fast_scanner_log_db(symbol, "BLOCKED", f"Haber Konseyi Veto: {news_analysis.get('verdict')}")
                    continue

                # Seri Zarar Kalkanı Denetimi
                if SUPER_FAST_SIDE_GUARD_ENABLED:
                    is_locked, guard_reason = check_super_fast_side_stoploss_guard(
                        direction,
                        max_consecutive_losses=SUPER_FAST_SIDE_MAX_CONSECUTIVE_LOSSES,
                        cooldown_minutes=SUPER_FAST_SIDE_COOLDOWN_MINUTES
                    )
                    if is_locked:
                        add_super_fast_scanner_log_db(symbol, "BLOCKED", guard_reason)
                        continue

                # Pozisyonu Aç ve Süper FAST Veritabanına Kaydet
                signal_data = {
                    "symbol": symbol,
                    "direction": direction,
                    "leverage": SUPER_FAST_LEVERAGE,
                    "entry_min": setup["entry_min"],
                    "entry_max": setup["entry_max"],
                    "actual_entry_price": setup["current_price"],
                    "stop_loss": setup["stop_loss"],
                    "take_profit_1": setup["take_profit_1"],
                    "take_profit_2": setup["take_profit_2"],
                    "risk_reward": setup["risk_reward"],
                    "risk_grade": setup["risk_grade"],
                    "news_summary": f"⚡⚡ SÜPER FAST Saniyelik ({setup['confluence_score']}/100)",
                    "ta_reasons": setup["ta_reasons"],
                    "allocated_margin_usdt": SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE,
                    "risk_usd": SUPER_FAST_RISK_PER_TRADE_USDT,
                    "super_fast_meta": {"timeframe": "1s", "score": setup["confluence_score"]}
                }

                sig_id = save_super_fast_signal(signal_data)
                active_symbols.add(symbol)
                slots_left -= 1
                if direction == "LONG":
                    long_count += 1
                else:
                    short_count += 1

                add_super_fast_scanner_log_db(
                    symbol,
                    "APPROVED",
                    f"⚡⚡ {SUPER_FAST_LEVERAGE}x {direction} Süper FAST Mikro Scalp Açıldı! (Marjin: ${SUPER_FAST_ALLOCATED_MARGIN_PER_TRADE})",
                    f"TP: +%{setup['tp1_pct']} | SL: -%{setup['sl_pct']}"
                )

            except Exception as e:
                add_super_fast_scanner_log_db(symbol, "ERROR", f"Tarama Hatası: {str(e)[:50]}")
            finally:
                time.sleep(0.08)

    def run_forever(self):
        """Süper FAST Botun 7/24 Kesintisiz Arka Plan Motoru (1sn Takip + 5sn Tarama)."""
        self.is_running = True
        last_scan_time = 0.0

        while self.is_running:
            try:
                # 1. Hızlı Açık Pozisyon Takibi (Her saniye merdiven kârlarını kontrol et)
                resolved = self.tracker.update_open_trades()
                for r in resolved:
                    if r.get("dollar_gain", 0) < 0:
                        self.cooldown_until[r["symbol"]] = time.time() + (SUPER_FAST_POST_LOSS_COOLDOWN_MINUTES * 60)

                # 2. Saniyelik Hızlı Tarama Döngüsü (Her 5 saniyede bir)
                now = time.time()
                if now - last_scan_time >= SUPER_FAST_SCAN_INTERVAL_SECONDS:
                    self.run_cycle()
                    last_scan_time = now

                # 3. Her Saat Başı Otomatik Telegram Raporu (İşlemler, PnL, Toplam Sonuç)
                now_dt = datetime.now(timezone(timedelta(hours=3)))
                current_hour_key = now_dt.strftime("%Y-%m-%d %H")
                if current_hour_key != self.last_reported_hour and now_dt.minute <= 2:
                    try:
                        self.notifier.send_super_fast_hourly_report()
                        self.last_reported_hour = current_hour_key
                    except Exception as rep_err:
                        print(f"⚠️ [Süper FAST Saatlik Rapor Hatası]: {rep_err}")

            except Exception as err:
                print(f"⚠️ [Süper FAST Bot Döngü Hatası]: {err}")

            time.sleep(1.0)

